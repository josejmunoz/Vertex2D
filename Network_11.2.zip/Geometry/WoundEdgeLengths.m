function [Pw,Rw]=WoundEdgeLengths(Vor,lnod_vor,vor_cell,lnodW,lnodExternal,celledge)
Pw=[];
Rw=[];
if ~isempty(lnodW)
    nodW=lnodW(:,1);
    nodB=sort(lnodExternal(:,1));
    [isWedge,locW]=ismember(nodW,nodB);
    Pw=zeros(sum(isWedge),1);
    Rw=Pw;
    c=0;
    for i=1:length(nodW)
        if isWedge(i)
            c=c+1;
            vcell=vor_cell{nodW(i)};
            Pc=0;
            for j=1:length(vcell)-1   %% calculating perimeter of the cell c at the wound edge
                Pc=Pc+norm(Vor(vcell(j),:)-Vor(vcell(j+1),:));
            end
            Pw(c)=sum(sum(sqrt((Vor(lnod_vor(celledge{locW(i)},2),:)-Vor(lnod_vor(celledge{locW(i)},1),:)).^2),2)); %% length of the free edge of cell c at the wound edge
            Rw(c)=Pw(c)/Pc; %% relative legnth of the free edge to the perimeter of cell c at the wound edge
        end
    end
end
end