function [g,K]=gKPressure(FE,Lumen,N,Set,Vor,X)
% Computes residual g and JAcobian K of internal Lumen presssure
% INPUT:
% FE: connectivity of Delaunay triangles of nodal network
% Lumen{w} : structure of Lumen w:
%        Lumen{w}.lnod: connectivity of vertices 
%        Lumen{w}.Relaxed: true: vertex positions are indpendent of nodal coordinates
%        Lumen{w}.P0 : pressure of Lumen {w}
% N : Shape functions of vertices
% Vor : Vertex coordinates
% X : nodal coordinates
% OUTPUT:
% g = residual contribution
% K = Jacobian of residual wrt vertex positions (Relaxed) or nodal positions (not Relaxed)
nodes=size(X,1);
nodesV=size(Vor,1);
dim=size(X,2);
vdim=(dim+1)*dim;
xidim=dim;

if Set.sparseM
    K=sparse(1,1,0,dim*(nodes+nodesV),dim*(nodes+nodesV));
else
    K=zeros(dim*(nodes+nodesV),dim*(nodes+nodesV));
end

g=zeros(dim*(nodes+nodesV),1);
err=0;

for w=1:length(Lumen)
    nele = size(Lumen{w}.lnod,1);
    if Set.sparseM
        r=zeros(nele*2*(vdim+xidim)*2*(vdim+xidim),1);
        c=r;
        v=r;
        s=0;
    end
    for e=1:size(Lumen{w}.lnod,1)
% % Change AssignMat  for Pressure    
%     [eleGammaA,eleGammaB,eleetaA,eleetaB,elek,elekA,elekB,eleEc,eleEcA,eleEcB]=AssignMat(Ab,e,ln,Mat,Set.t);
    % One branch  only for pressures
        ve=Vor(Lumen{w}.lnod(e,1:2),:);
        m=Lumen{w}.lnod(e,:);
        % Assemble depending on relaxed/non-relaxed vertices
        if ~Lumen{w}.Relaxed % Vertex positions constrined to nodal positions
            xe1=X(FE(m(1),:),:);
            xe2=X(FE(m(2),:),:);
        else
            xe1=[];
            xe2=[];
        end
        [err,ge,Ke]=gkElemVert(err,m,N,Lumen{w}.P0,Lumen{w}.Relaxed,ve,xe1,xe2);
        if ~Lumen{w}.Relaxed % Vertex positions constrined to nodal positions
            vdim1=(dim+1)*dim;
            aux1=zeros(1,vdim);
            aux1([1 3 5])=2*FE(m(1),:)-1;
            aux1([2 4 6])=2*FE(m(1),:);
            vdim2=(dim+1)*dim;
            aux2=zeros(1,vdim);
            aux2([1 3 5])=2*FE(m(2),:)-1;
            aux2([2 4 6])=2*FE(m(2),:);
        else
            aux1=[];
            vdim1=0;
            vdim2=0;
            aux2=[];
        end
        auxxi1=dim*nodes+(dim*(m(1)-1)+1:dim*m(1));
        auxxi2=dim*nodes+(dim*(m(2)-1)+1:dim*m(2));
        auxxi=[auxxi1 auxxi2];
        aux=[aux1 aux2 auxxi]';
        g(auxxi)=g(auxxi)+ge(end-2*dim+1:end);
        if ~Lumen{w}.Relaxed % Vertex positions constrined to nodal positions
            g(aux1)=g(aux1)+ge(1:vdim1);
            g(aux2)=g(aux2)+ge(vdim1+1:vdim1+vdim2);
        end
        if Set.sparseM
            for i=1:(vdim1+vdim2+2*xidim)
                for j=1:(vdim1+vdim2+2*xidim)
                    s=s+1;
                    r(s)=aux(i);
                    c(s)=aux(j);
                    v(s)=Ke(i,j);
                end
            end
        else
            for i=1:(vdim1+vdim2+2*xidim)
                for j=1:(vdim1+vdim2+2*xidim)
                    K(aux(i),aux(j))=K(aux(i),aux(j))+Ke(i,j);
                end
            end
        end
    end
    if Set.sparseM
        K=K+sparse(r(1:s),c(1:s),v(1:s),dim*(nodes+nodesV),dim*(nodes+nodesV));
    end
end
end
%% Elemental function for vertices, with possible proejction onto nodes
function [err,ge,Ke]=gkElemVert(err,m,N,P0,Relaxed,ve,xe1,xe2)
dim=size(ve,2);
vdim=(dim+1)*dim;
xidim=dim;
[err,ge,Ke]=LineElemPressure(err,ve,P0);
dN=[-1 1 0
   -1 0 1]; %derivative of shape functions
dN1=dN;
dN2=dN;
if ~Relaxed % Vertices not relaxed: transport to nodes
    ee1=kron(N(m(1),:),eye(dim));
    eexi1=[(xe1(2,:)-xe1(1,:))' (xe1(3,:)-xe1(1,:))'];
    dim1=1:dim;
    ee2=kron(N(m(2),:),eye(dim));
    eexi2=[(xe2(2,:)-xe2(1,:))' (xe2(3,:)-xe2(1,:))'];
    dim2=dim+1:2*dim;
    ee=[ee1 zeros(dim,vdim)
        zeros(dim,vdim) ee2];
    Mp=[kron(dN1',ge(1:dim)) zeros(vdim,dim)
        zeros(vdim,dim) kron(dN2',ge(dim+1:end))];
else
    eexi1=eye(dim);
    dim1=[];
    eexi2=eye(dim);
    dim2=[];
    ee=[];
    Mp=[];
end
dim12=[dim1 dim2];
eexi=[eexi1 zeros(xidim,xidim)
    zeros(xidim,xidim) eexi2];
Kexx=ee'*Ke(dim12,dim12)*ee;
gex=ee'*ge(dim12);
if ~Relaxed
    Kexxi=ee'*Ke(dim12,:)*eexi+Mp;
    Kexix=eexi'*Ke(:,dim12)*ee+Mp';
else
    Kexxi=[];
    Kexix=[];
end
Kexixi=eexi'*Ke*eexi;
gexi=eexi'*ge;
ge=[gex;gexi];
Ke=[Kexx Kexxi;Kexix Kexixi];
end
%% Elemental function for Pressures
function [err,ge,Ke]=LineElemPressure(err,x,p0)
% Elemental subrouting for bar elements
% Output:
% g = residual vector contains pressure forces
% K = Stiffness matrix
%
% Input:
% Lumen = Lumen material properties (pressure)
% x= row vector [x1 x2] with current  positions of nodes 1 and 2

% This subroutine involves the pressure based on a line element. The line
% element connects two points y1 and y2 and has length of l12. y contains
% both y1 and y2. The pressure based on the line element is a force
% explained by g and g = p0/2*l12*n12 with n12 the normal vector.

    v12=x(2,:)-x(1,:);
    J=[ 0 -1 % Assumed boundary of lumne in clockwise direction
        1 0];

    g1 = p0/2*J*v12';
    g2 = p0/2*J*v12';
    ge = [g1;g2];

    Kxx = -p0/2*J; %Kxx = Kyx
    Kxy =  p0/2*J; %Kxy = Kyy

    Ke = [Kxx, Kxy
          Kxx, Kxy];
end
%% Assign Material properties depending on Dead-Dead, Dead-Live and ablated area membership --> Understand that lumen has own contractility
function [eleGammaA,eleGammaB,eleetaA,eleetaB,elek,elekA,elekB,eleEc,eleEcA,eleEcB]=AssignMat(Ab,e,ln,Mat,t)
    Timing=~isempty(Ab.eleVorDLt);
    if Mat.beta<eps
        Ec=Mat.Ec;
    else
        Ec=ln.S.c(e);
    end
    if Mat.betaA<eps
        EcA=Mat.EcA;
    else
        EcA=ln.A.c(e);
    end
    if Mat.betaB<eps
        EcB=Mat.EcB;
    else
        EcB=ln.B.c(e);
    end
    if ismember(e,Ab.eleVorDD) && Ab.active && Ab.Eca
        elekA=Ab.CoK*Mat.kappaA;
        elekB=Ab.CoK*Mat.kappaB;
        elek=Ab.CoK*Mat.kappa;
    elseif ismember(e,Ab.eleVorDD) && Ab.active
        elekA=Ab.CoVor*Mat.kappaA;
        elekB=Ab.CoVor*Mat.kappaB;
        elek=Ab.CoVor*Mat.kappa;
    else
        elekA=Mat.kappaA;
        elekB=Mat.kappaB;
        elek=Mat.kappa;
    end
    if ismember(e,Ab.eleVorDD) && Ab.active
        eleGammaA=Ab.CoGamm*Mat.GammaA;
        eleGammaB=Ab.CoGamm*Mat.GammaB;
        eleetaA=Ab.CoVor*Mat.etaA;
        eleetaB=Ab.CoVor*Mat.etaB;
    else
        eleGammaA=Mat.GammaA;
        eleGammaB=Mat.GammaB;
        eleetaA=Mat.etaA;
        eleetaB=Mat.etaB;
    end
    if  ismember(e,Ab.eleVorDLc) && Ab.active && Ab.Eca
        if Timing
            tc=Ab.eleVorDLt(Ab.eleVorDLc==e);
        else
            tc=0;
        end
        if ~Timing || t>tc
            if abs(Mat.beta)>eps
                eleEc=ln.S.c(e);
            else
                eleEc=Ab.Ec*Mat.Ec;
            end
            if abs(Mat.betaA)>eps
                eleEcA=ln.A.c(e);
            else
                eleEcA=Ab.Ec*Mat.EcA;
                
            end
            if abs(Mat.betaB)>eps
                eleEcB=ln.B.c(e);
            else
                eleEcB=Ab.Ec*Mat.EcB;
            end
        else
            eleEc =Ec;
            eleEcA=EcA;
            eleEcB=EcB;
        end
    elseif ismember(e,Ab.eleVorDD) && Ab.active && Ab.Eca % During active closure
        if ln.S.e(e)<Ab.LFilo
            eleEc =Ab.CoEc*Ec;
            eleEcA=Ab.CoEc*EcA;
            eleEcB=Ab.CoEc*EcB;
        else
            eleEc =0;
            eleEcA=0;
            eleEcB=0;
        end
    elseif ismember(e,Ab.eleVorDD) && Ab.active % after wounding before closure
        eleEc =0;
        eleEcA=0;
        eleEcB=0; 
    else
        eleEc =Ec;
        eleEcA=EcA;
        eleEcB=EcB;
    end
end
