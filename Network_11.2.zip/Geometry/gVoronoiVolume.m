function [gv,Kv,Sparse,V]=gVoronoiVolume(gv,Kv,Sparse,vor_cell,Vor,X,FE,N,nodes,nodesV,Set,V0,Wounded,I,nlnod)
dim=size(X,2);
ndim=size(vor_cell,1);
n=dim*(nodes+nodesV);
g=zeros(n,1);
V=0;
if sum(I)>0
    FEaux=zeros(ndim,dim+1);
    FEaux(I,:)=FE;
    FE=FEaux;
    Naux=zeros(ndim,dim+1);
    Naux(I,:)=N;
    N=Naux;
end
for i=2:ndim % Loop on faces
    V=V+0.5*det([Vor(i-1,:);Vor(i,:)]);
end
if ~Wounded
    dN=[-1 1 0
        -1 0 1];
    if Set.sparseM
        auxg=zeros(n,1);
    else
        K=zeros(dim*(nodes+nodesV),dim*(nodes+nodesV));
    end
    for i=2:ndim % Loop on faces
        if I(i)
            auxx10=reshape([dim*(FE(i,:)-1)+1;dim*FE(i,:)],1,6);
            xe1=X(FE(i,:),:);
        else
            auxx10=[];
        end
        if I(i-1)
            auxx20=reshape([dim*(FE(i-1,:)-1)+1;dim*FE(i-1,:)],1,6);
            xe2=X(FE(i-1,:),:);
        else
            auxx20=[];
        end
        auxxi1=dim*nodes+(dim*(vor_cell(i)-1)+1:dim*vor_cell(i));
        auxxi2=dim*nodes+(dim*(vor_cell(i-1)-1)+1:dim*vor_cell(i-1));
        auxx1=[auxx10 auxxi1];
        auxx2=[auxx20 auxxi2];
        if i<ndim
            if I(i+1)
                auxx30=reshape([dim*(FE(i+1,:)-1)+1;dim*FE(i+1,:)],1,6);
                xe3=X(FE(i+1,:),:);
            else
                auxx30=[];
            end
            auxxi3=dim*nodes+(dim*(vor_cell(i+1)-1)+1:dim*vor_cell(i+1));
        else
            if I(2)
                auxx30=reshape([dim*(FE(2,:)-1)+1;dim*FE(2,:)],1,6);
                xe3=X(FE(2,:),:);
            else
                auxx30=[];
            end
            auxxi3=dim*nodes+(dim*(vor_cell(2)-1)+1:dim*vor_cell(2));
        end
        auxx3=[auxx30 auxxi3];
        if I(i)
            eexi1=[(xe1(2,:)-xe1(1,:))' (xe1(3,:)-xe1(1,:))'];
        else
            eexi1=eye(dim);
        end
        if I(i-1)
            eexi2=[(xe2(2,:)-xe2(1,:))' (xe2(3,:)-xe2(1,:))'];
        else
            eexi2=eye(dim);
        end
        if i<ndim
            if I(i+1)
                eexi3=[(xe3(2,:)-xe3(1,:))' (xe3(3,:)-xe3(1,:))'];
            else
                eexi3=eye(dim);
            end
        else
            if I(2)
                eexi3=[(xe3(2,:)-xe3(1,:))' (xe3(3,:)-xe3(1,:))'];
            else
                eexi3=eye(dim);
            end
        end
        if I(i)
            ee1  =kron(N(i,:),eye(2));
        else
            ee1=[];
        end
        if I(i-1)
        ee2  =kron(N(i-1,:),eye(2));
        else
            ee2=[];
        end
        if i<ndim
            if I(i+1)
                ee3=kron(N(i+1,:),eye(2));
            else
                ee3=[];
            end
        else
            if I(2)
                ee3=kron(N(2,:),eye(2));
            else
                ee3=[];
            end
        end
        if i<ndim
            JJ=(Vor(i-1,:)-Vor(i+1,:))*[0 1;-1 0];
            b=1;
            ge=b*(JJ*[ee1 eexi1])';
            if I(i)
                Mp1=kron(dN',JJ')/V0;
            else
                Mp1=[];
            end
%            Mp1=zeros(size(Mp1));
        else
            J2=(Vor(i-1,:)-Vor(2,:))*[0 1;-1 0];
            b=1;
            ge=b*(J2*[ee1 eexi1])';
            if I(i)
                Mp1=kron(dN',J2')/V0;
            else
                Mp1=[];
            end
%            Mp1=zeros(size(Mp1));
        end
        g(auxx1)=g(auxx1)+ge;
        Mp=-([ee1 eexi1])'*[0 -1;1 0]*[ee3 eexi3]/V0;
        Mn=([ee1 eexi1])'*[0 -1;1 0]*[ee2 eexi2]/V0;
        if Set.sparseM
            fact=(0.5*(V-V0)/V0)*nlnod/6;
            Sparse=AssembleSparse(Sparse,auxx1,auxx3,Mp*fact);
            Sparse=AssembleSparse(Sparse,auxx1,auxx2,Mn*fact);
            if I(i)
            Sparse=AssembleSparse(Sparse,auxx10,auxxi1,Mp1*fact);
            Sparse=AssembleSparse(Sparse,auxxi1,auxx10,Mp1'*fact);
            end
            auxg(auxx1)=auxx1;
        else
            K(auxx1,auxx3)=K(auxx1,auxx3)+Mp;
            K(auxx1,auxx2)=K(auxx1,auxx2)+Mn;
            if I(i)
            K(auxx10,auxxi1)=K(auxx10,auxxi1)+Mp1;
            K(auxxi1,auxx10)=K(auxxi1,auxx10)+Mp1';
            end
        end
    end
    g=g/V0;
    gv=gv+(0.5*(V-V0)*g/V0)*nlnod/6;
    if Set.sparseM
        auxg(auxg==0)=[];
        Sparse=AssembleSparse(Sparse,auxg,auxg,0.25*(g(auxg))*g(auxg)'*nlnod/6);
    else
        Kv=Kv+(0.5*(V-V0)*K/V0+0.25*(g*g'))*nlnod/6;
    end
end
end
%%
function Sparse=AssembleSparse(Sparse,aux1,aux2,K)
m=length(aux1);
n=length(aux2);
for j=1:m
    for k=1:n
        Sparse.k=Sparse.k+1;
        Sparse.r(Sparse.k)=aux1(j);
        Sparse.c(Sparse.k)=aux2(k);
        Sparse.v(Sparse.k)=K(j,k);
    end
end
end
