function []=Subplots(gout,tout,u)
% Defaults for this blog post
width = 10;     % Width in inches
height = 3;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 24;      % Fontsize
lw = 2;      % LineWidth
msz = 10; % MarkerSize

fig1=figure();
pos=get(gcf,'Position');
set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
set(gca,'FontSize',fsz,'LineWidth',lw)

subplot(1,3,1)
pos=get(gcf,'Position');
set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
set(gca,'FontSize',fsz,'LineWidth',lw)
plot(tout,u,'.','MarkerSize',msz);
xlabel('time (tout)'); ylabel('displacement (u)')

subplot(1,3,2)
pos=get(gcf,'Position');
set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
set(gca,'FontSize',fsz,'LineWidth',lw)
plot(tout,gout,'.','MarkerSize',msz);
xlabel('time (tout)'); ylabel('stress (gout)')

subplot(1,3,3)
pos=get(gcf,'Position');
set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
set(gca,'FontSize',fsz,'LineWidth',lw)
plot(u,gout,'.','MarkerSize',msz);
xlabel('displacement (u)'); ylabel('stress (gout)')