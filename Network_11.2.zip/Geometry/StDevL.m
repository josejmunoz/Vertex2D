function [dLD,dLV]=StDevL(ln,X,V,lnod,lnodv)
Ldr=ln.D.n.A.r;
Lde=sqrt(sum((X(lnod(:,2),:)-X(lnod(:,1),:)).^2,2));
Lvr=ln.V.n.A.r;
Lve=sqrt(sum((V(lnodv(:,2),:)-V(lnodv(:,1),:)).^2,2));
dLD=sqrt(sum(((Lde-Ldr)./Ldr).^2))/size(lnod,1);
dLV=sqrt(sum(((Lve-Lvr)./Lvr).^2))/size(lnodv,1);
end