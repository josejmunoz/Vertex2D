function SimplePoints(X,Vor,lnod,lnod_vor)
figure;
if exist('lnod') && exist('X')
    for i=1:size(lnod,1)
        plot([X(lnod(i,1),1) X(lnod(i,2),1)],[X(lnod(i,1),2) X(lnod(i,2),2)],'k-','LineWidth',1);
        hold on
    end
end
if exist('lnod_vor') && exist('Vor')
    for i=1:size(lnod_vor,1)
        plot([Vor(lnod_vor(i,1),1) Vor(lnod_vor(i,2),1)],[Vor(lnod_vor(i,1),2) Vor(lnod_vor(i,2),2)],'-r','LineWidth',4);
        hold on
    end
    scatter(Vor(:,1),Vor(:,2),'*')
end
dx=0.07;
dy=0.07;
if exist('lnod') && exist('X')
    a=(1:size(X,1))';
    b=num2str(a);
    c=cellstr(b);
    text(X(:,1)+dx,X(:,2)+dy,c,'color','k');
    hold on
end
if exist('lnod_vor') && exist('Vor')
    a=(1:size(Vor,1))';
    b=num2str(a);
    c=cellstr(b);
    text(Vor(:,1)+dx,Vor(:,2)+dy,c,'color','b');
end
end