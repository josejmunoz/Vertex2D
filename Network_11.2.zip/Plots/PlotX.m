function PlotX(X,lnod)
figure;
for i=1:size(lnod,1)
    plot([X(lnod(i,1),1) X(lnod(i,2),1)],[X(lnod(i,1),2) X(lnod(i,2),2)],'k-','LineWidth',1);
    hold on
end
scatter(X(:,1),X(:,2),'*');
hold on 
text(X(:,1)+0.07,X(:,2)+0.07,cellstr(num2str((1:size(X,1))')),'color','b');
end