function [ener,gel,Kel,EpsElas,ln1_elas,ln1_elasB,ln1,G_tot,Gs,GMaxA,GMaxB]=MaxwellKelvinElas...
 (Mat,dim,dt,x1,x1p,x10,x20,x2,x2p,ln_elas,ln_elasB,Set)
%Two Maxwell element and a linear elastic element connected in parallel, Charras's work
kappa=Mat.kappa;
kappaA=Mat.kappaA;
kappaB=Mat.kappaB;
etaA=Mat.etaA;
etaB=Mat.etaB;
Ec=Mat.Ec;
gel=zeros(2*dim,1);
Kel=zeros(2*dim);
EpsElas=0;
ln1_elas=0;
ln1_elasB=0;
ener1=0;
ener2=0;
ener3=0;
Gs=0;
GA=0;
GB=0;
if  abs(kappa)>0 % Linear elastic
    [ener1,gel,Kel,~,EpsElas,ln1,Gs]=MaxwellLineElem(kappa,0,dt,Ec,[x10 x20],[x1 x2],[x1p x2p],ln_elas,Set);
end

if etaA<0 %Kelvin
    [ener2,ge,Ke,ln1_elas,~,GA]=DashpotLineElem(dt,dim,-etaA,[x1 x2],[x1p x2p],[x10 x20],Set.DispBased);
    ln1=ln1_elas;
    gel=gel+ge;
    Kel=Kel+Ke;
else %Maxwell
    if abs(kappaA)>0 %dashpot branch B
        [ener2,ge,Ke,ln1_elas,~,ln1,GA]=MaxwellLineElem(kappaA,etaA,dt,0,[x10 x20],[x1 x2],[x1p x2p],ln_elas,Set);
        gel=gel+ge;
        Kel=Kel+Ke;
    end
end
if etaB<0 %Kelvin
    [ener3,ge,Ke,ln1_elasB,~,ln1,GB]=DashpotLineElem(dt,dim,-etaB,[x1 x2],[x1p x2p],[x10 x20],Set.DispBased);
    gel=gel+ge;
    Kel=Kel+Ke;
else % Maxwell
    if abs(kappaB)>0   %Maxwell branch B
        [ener3,ge,Ke,ln1_elasB,~,ln1,GB]=MaxwellLineElem(kappaB,etaB,dt,0,[x10 x20],[x1 x2],[x1p x2p],ln_elasB,Set);
        gel=gel+ge;
        Kel=Kel+Ke;
    end
end
G_tot=Gs+GA+GB;
GMaxA=GA;
GMaxB=GB;
ener=ener1+ener2+ener3;
end