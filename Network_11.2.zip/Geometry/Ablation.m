function Ab=Ablation(Ab,nodV,lnod,vor_cell_ele,lnod_vor,lnodW,celledgeW)
Ab.eleDDL=[];   %%index of Delaunay elements associated to Dead-Dead connections and Dead-ALive connections
Ab.eleVorDD=[]; %%index of Voronoi(cell edge) elements associated to Dead-Dead edges (shared edge between 2 dead cells)
Ab.eleVorDL=[]; %%index of Voronoi(cell edge) elements associated to Dead-Alive edges (boundary of ablation)
Ab.eleVorDLc=[];
Ab.eleVorDLt=[];
Ab.cellAb=[];
Ab.nodAb1=[];   %%combination of ablated cells(nodes) and the cells(nodes) on the wound edge
Ab.Corona1=[];
Ab.VorDL=[];
Ab.Corona2=[];
if ~isempty(Ab.nodAb)
    Ab=SetAblated(Ab,nodV,vor_cell_ele,lnod_vor); % Set eleVorDD, eleVorDL, eleVorDLc
    Ab.eleDD=find(ismember(lnod(:,1),Ab.nodAb) & ismember(lnod(:,2),Ab.nodAb));
    Ab.eleDL=[find( ismember(lnod(:,1),Ab.nodAb) & ~ismember(lnod(:,2),Ab.nodAb))
        find(~ismember(lnod(:,1),Ab.nodAb) &  ismember(lnod(:,2),Ab.nodAb))];
    Ab.eleDDL=[Ab.eleDD;Ab.eleDL];
    Ab.nodAb1=unique([lnod(Ab.eleDDL,1);lnod(Ab.eleDDL,2)]);
    Ab.Corona1=Ab.nodAb1(~ismember(Ab.nodAb1,Ab.nodAb));
    lnod2nd= (ismember(lnod(:,1),Ab.nodAb1) & ~ismember(lnod(:,2),Ab.nodAb1)) | (ismember(lnod(:,2),Ab.nodAb1) & ~ismember(lnod(:,1),Ab.nodAb1));
    lnod2nd=lnod(lnod2nd,:);
    Ab.Corona2=unique([lnod2nd(:,1);lnod2nd(:,2)]);
    Ab.VorDL=unique([lnod_vor(Ab.eleVorDL,1);lnod_vor(Ab.eleVorDL,2)]); %%Vertices on the wound edge
elseif Ab.active && ~isempty(celledgeW)
    Ab.Corona1=lnodW(:,1);
    Ab.Corona2=unique([lnod(ismember(lnod(:,1),Ab.Corona1),2);lnod(ismember(lnod(:,2),Ab.Corona1),1)]);
    Ab.VorDL=unique([lnod_vor(celledgeW,1);lnod_vor(celledgeW,2)]);
    Ab.eleVorDL=celledgeW;
    Ab.eleVorDLc=celledgeW;
    Ab.eleVorDLt=0*celledgeW;
    Ab.nodAb=[];
end
end
%%
function Ab=SetAblated(Ab,nodV,vor_cell_ele,lnod_vor)
% Sets eleVorDL, eleVorDD, eleVorDLc, eleVorDLt
[Ab.cellAb,VertE]=SetVertE(Ab.nodAb,Ab.nodAb,lnod_vor,nodV,vor_cell_ele);
% Check time-sequence of each vertex
Timing=isfield(Ab,'nodAbt') && isfield(Ab,'nodAbTimes');
if Timing && ~isfield(Ab,'Contract')
    [Ab,VertT,Timing]=SetVertT(Ab,lnod_vor,nodV,VertE,vor_cell_ele);
    VertT=cell2mat(VertT);
end
% select dead-life (DL) and dead-dead elements (DD)
VertE=cell2mat(VertE);
VertN=zeros(size(lnod_vor,1),1);
VertNt=VertN;
for e=1:length(VertE) % Number how many times a vertex element is listed
    VertN(VertE(e))=VertN(VertE(e))+1;
    if Timing &&  ~isfield(Ab,'Contract')
        VertNt(VertE(e))=VertNt(VertE(e))+VertT(e);
    end
end
N=1:size(lnod_vor,1);
Ab.eleVorDD=N(VertN>1)';
Ab.eleVorDL=N(VertN==1)';
if Timing &&  ~isfield(Ab,'Contract')
    Ab.eleVorDLt=VertNt(VertN==1)';
else
    Ab.eleVorDLt=0*Ab.eleVorDL;
end
% Same process but on contracted cells only
if isfield(Ab,'Contract')
    [~,VertE]=SetVertE(Ab.Contract,Ab.nodAb,lnod_vor,nodV,vor_cell_ele);
    if Timing
        [Ab,VertT,Timing]=SetVertT(Ab,lnod_vor,nodV,VertE,vor_cell_ele);
        VertT=cell2mat(VertT);
    end
    VertE=cell2mat(VertE);
    VertN=zeros(size(lnod_vor,1),1);
    VertNt=VertN;
    for e=1:length(VertE)
        VertN(VertE(e))=VertN(VertE(e))+1;
        if Timing 
            VertNt(VertE(e))=VertNt(VertE(e))+VertT(e);
        end
    end
    N=1:size(lnod_vor,1);
    Ab.eleVorDLc=N(VertN==1)';
    Ab.eleVorDLc(ismember(Ab.eleVorDLc,Ab.eleVorDD))=[]; % Remove Dead-Dead vertex
    if Timing
        Ab.eleVorDLt=VertNt(VertN==1)';
    else
        Ab.eleVorDLt=0*Ab.eleVorDLc;
    end
else
    Ab.eleVorDLc=[];
end
end
%%
function [cellAbC,VertE]=SetVertE(Contract,nodAb,lnod_vor,nodV,vor_cell_ele)
% Sets list of contracted elemnts and list of contracted vertices per in each contracted cell
cellAbC=find(ismember(nodV,Contract));
Vert=cell(length(nodAb),1);
VertE=cell(length(nodAb),1);
for e=1:length(Contract) % Loop on contracted cells
    Vert{e}=vor_cell_ele{cellAbC(e)}; % List of connected vertices for each cell
    vertices=Vert{e};
    VertE{e}=zeros(size(vertices,1),1); % List of vertex elements
    for v=1:size(vertices,1)
        VertE{e}(v)=find((vertices(v,1)==lnod_vor(:,1) & vertices(v,2)==lnod_vor(:,2))...
            | (vertices(v,2)==lnod_vor(:,1) & vertices(v,1)==lnod_vor(:,2)));
    end
end
end
%%
function [Ab,VertT,Timing]=SetVertT(Ab,lnod_vor,nodV,VertE,vor_cell_ele)
% Sets list of vertex elements with timing according to Ab.nodAbt and
% Ab.nodAbTimes
VertT=cell(size(VertE)); % List of timing for each vertex element
Timing=true;
if max(max(Ab.nodAbt))>size(vor_cell_ele,1)
    ntimes=0;
    Ab=rmfield(Ab,'nodAbt');
    warning('Some of the assinged cells for timed contractility are larger than number of cells. Timing removed.');
    Timing=false;
else
    ntimes=min(size(Ab.nodAbt,2),length(Ab.nodAbTimes));
end
for a=1:length(VertE) % Loop on ablated cells
    VertT{a}=VertE{a}*0;
    lnodA=lnod_vor(VertE{a},:);
    for ea=1:size(lnodA,1)
        for t=1:ntimes % Loop on timed cells (around wound)
            for s=1:2 % 2 sides of gap
                lnodT=vor_cell_ele(nodV==Ab.nodAbt(s,t));
                if ~isempty(lnodT)
                    lnodT=lnodT{1};
                end
                for et=1:size(lnodT,1) % Loop on vertices of timed cells
                    if (lnodA(ea,1)==lnodT(et,1) && lnodA(ea,2)==lnodT(et,2)) ||...
                            (lnodA(ea,1)==lnodT(et,2) && lnodA(ea,2)==lnodT(et,1))
                        VertT{a}(ea)=Ab.nodAbTimes(t);
                    end
                end
            end
        end
    end
end
end
