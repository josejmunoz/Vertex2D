function [X,X0,x,x0,xp,dofx,cdof,vext,nodes,nodes0,nodV,gA,gD,gV,...
    FE0,FEp,N,V,Vp,Vpp,V0,V00,xip,lnodp,lnodExternalp,lnodvp,cedgep,Vol0,Vol,VolW0,ln,Ab,m,...
    Set,lnodWp,Wln]=RemoveWoundCells(X,X0,x,x0,xp,dofx,cdof,vext,nodes,nodes0,nodV,...
    gA,gD,gV,FE0,FEp,N,V,Vp,Vpp,V0,V00,xip,lnodp,lnodExternalp,lnodvp,cedgep,Vol0,...
    Vol,ln,Ab,m,Set)
lnodWp=[];
Wln  =[];
if  Ab.active
    Iedgex=ismember(lnodp(:,1),Ab.Corona1) & ismember(lnodp(:,2),Ab.Corona1) & (ismember(lnodvp(1:size(lnodp,1),1),Ab.VorDL) | ismember(lnodvp(1:size(lnodp,1),2),Ab.VorDL));
    dim =size(X,2);
    nod=nodes;
    nodw=sort(Ab.nodAb);
    Ab.nodAb=[];
    Set.Ablation=false;
    Wln=sum(ln.V.n1.A.r(Ab.eleVorDL));
    X (nodw,:)=[];
    X0(nodw,:)=[];
    nodes =nodes-length(nodw);
    nodes0=nodes0-length(nodw);
    Iv=ismember(nodV,nodw);
    Vol0(Iv)=[];
    VolW0   =sum(Vol (Iv));
    Vol (Iv)=[];
    nodV(Iv)=[];
    Ix      =[dim*nodw-1;dim*nodw];
    Ix      =Ix(:);
    x (Ix)  =[];
    x0(Ix)  =[];
    xp(Ix)  =[];
    vext(Ix)=[];
    dofx(ismember(dofx,Ix))=[];
    cdof(ismember(cdof,Ix))=[];
    nt=1:size(FEp,1);
    nl=1:size(lnodp,1);
    Ilx=ismember(lnodp(:,1),nodw) | ismember(lnodp(:,2),nodw);
    Itx=ismember(FEp(:,1),nodw) | ismember(FEp(:,2),nodw) | ismember(FEp(:,3),nodw);
    Itbx=(ismember(FEp(:,1),nodw) & ismember(FEp(:,2),nodw) & ismember(FEp(:,3),nodw)) | ...
         (ismember(FEp(:,1),nodw) & ismember(FEp(:,2),nodw) & ~ismember(FEp(:,3),nodw)) |...
         (ismember(FEp(:,1),nodw) & ~ismember(FEp(:,2),nodw) & ismember(FEp(:,3),nodw)) |...
         (~ismember(FEp(:,1),nodw) & ismember(FEp(:,2),nodw) & ismember(FEp(:,3),nodw));
    Ivb= Itx & ~Itbx;
    Ivb=nt(Ivb);
    nt0=1:size(FE0,1);
    It0x=ismember(FE0(:,1),nodw) | ismember(FE0(:,2),nodw) | ismember(FE0(:,3),nodw);
    Itb0x=(ismember(FE0(:,1),nodw) & ismember(FE0(:,2),nodw) & ismember(FE0(:,3),nodw)) | ...
         (ismember(FE0(:,1),nodw) & ismember(FE0(:,2),nodw) & ~ismember(FE0(:,3),nodw)) |...
         (ismember(FE0(:,1),nodw) & ~ismember(FE0(:,2),nodw) & ismember(FE0(:,3),nodw)) |...
         (~ismember(FE0(:,1),nodw) & ismember(FE0(:,2),nodw) & ismember(FE0(:,3),nodw));
    Ivb0=It0x & ~Itb0x;
    Ivb0=nt0(Ivb0);
    lnodaux=lnodp(Iedgex,:);
    lnodaux1=zeros(size(lnodaux,1),2);
    lnodaux1(1,:)=lnodaux(1,:);
    lnodaux(1,:)=[0 0];
    naux=zeros(size(lnodaux,1),1);
    numl=1:size(lnodaux,1);
    naux(1)=1;
    for i=1:size(lnodaux,1)-1
        b= lnodaux(:,1)==lnodaux1(i,2) | lnodaux(:,2)==lnodaux1(i,2);
        naux(i+1)=numl(b);
        if lnodaux(b,1)==lnodaux1(i,2)
            lnodaux1(i+1,:)=lnodaux(b,:);
        else
            lnodaux1(i+1,:)=lnodaux(b,[2 1]);
        end
        lnodaux(b,:)=[0 0];
    end
    lnodaux              =lnodaux1;
    lnodp(Ilx | Iedgex,:)=[];
    lnodp                =[lnodp;lnodaux];
    lnodvaux=lnodvp(Iedgex,:);
    lnodvaux=lnodvaux(naux,:);
    lnodvp(Ilx | Iedgex,:)=[];
    for i=1:size(lnodvaux,1)
        if ~ismember(lnodvaux(i,2),Ivb)
            lnodvaux(i,:)=lnodvaux(i,[2 1]);
        end
    end
    lnodvp=[lnodvp(1:(size(lnodp,1)-size(lnodaux,1)),:);lnodvaux;lnodvp((size(lnodp,1)-size(lnodaux,1)+1):end,:)];
    [ln]=RemovelnWound(ln,Ilx,Iedgex,naux);
    lnodExternalp=[lnodExternalp;lnodaux];
    lnodWp=lnodaux;
    xip=reshape(xip',dim,size(FEp,1))';
    sizetp       =size(FEp,1);
    FEp(Itx,:)   =[];
    sizet        =size(FEp,1);
    FE0(It0x,:)  =[]; 
    sizet0       =size(FE0,1);
    N(Itx,:)     =[];
    xip(Itx,:)   =[];
    Vaux         =V(Ivb,:);
    V(Itx,:)     =[];
    V            =[V(1:sizet,:);Vaux;V(sizet+1:end,:)];
    Vp           =V;
    Vpp          =V;
    Vaux         =V0(Ivb0,:);
    V0(It0x,:)   =[];
    V0           =[V0(1:sizet0,:);Vaux;V0(sizet0+1:end,:)];
    Vaux         =V00(Ivb0,:);
    V00(Itx,:)   =[];
    V00          =[V00(1:sizet0,:);Vaux;V00(sizet0+1:end,:)];
    Itbx=nt(Itbx);
    Itx =nt(Itx);
    indln=nl(Ilx);
    xip=reshape(xip',1,size(FEp,1)*dim)';
    adofx=0;
    acdof=0;
    anodV=0;
    alnodp=0;
    alnodExternalp=0;
    alnodWp=0;
    aFEp=0;
    aFE0=0;
    for i=1:length(Ix)
        a= dofx>Ix(i);
        adofx=adofx+a;
        a= cdof>Ix(i);
        acdof=acdof+a;
    end
    for i=1:length(nodw)
        a= nodV>nodw(i);
        anodV=anodV+a;
        a= lnodp>nodw(i);
        alnodp=alnodp+a;
        a= lnodExternalp>nodw(i);
        alnodExternalp=alnodExternalp+a;
        a= lnodWp>nodw(i);
        alnodWp=alnodWp+a;
        a= FEp>nodw(i);
        aFEp=aFEp+a;
        a= FE0>nodw(i);
        aFE0=aFE0+a;
    end
    dofx=dofx-adofx;
    cdof=cdof-acdof;
    nodV=nodV-anodV;
    lnodp=lnodp-alnodp;
    lnodExternalp=lnodExternalp-alnodExternalp;
    lnodWp=lnodWp-alnodWp;
    FEp=FEp-aFEp;
    FE0=FE0-aFE0;
    %%
    alnodvp=0;
    a= lnodvp<=sizetp & ~ismember(lnodvp,Ivb);
    lnodvp1=lnodvp(a);
    for i=1:length(Itx)
        aa= lnodvp1>Itx(i);
        alnodvp=alnodvp+aa;
    end
    lnodvp1=lnodvp1-alnodvp;
    b= lnodvp<=sizetp & ismember(lnodvp,Ivb);
    lnodvp2=lnodvp(b);
    lnodvp2aux=lnodvp2;
    for i=1:length(Ivb)
        bb= ismember(lnodvp2aux,Ivb(i));
        lnodvp2(bb)=sizet+i;
    end
    c= lnodvp>sizetp;
    lnodvp3=lnodvp(c);
    lnodvp3=lnodvp3-length(Itbx);
    lnodvp(a)=lnodvp1;
    lnodvp(b)=lnodvp2;
    lnodvp(c)=lnodvp3;
    %%
    for i=1:size(cedgep,1)
        acedgep=0;
        for j=1:length(indln)
            a= cedgep{i}>indln(j);
            acedgep=acedgep+a;
        end
        cedgep{i}=cedgep{i}-acedgep;
    end
    [gD]=Reorderg(gD,dim,nod,Ix,Itx,Ivb,sizet);
    [gV]=Reorderg(gV,dim,nod,Ix,Itx,Ivb,sizet);
    [gA]=Reorderg(gA,dim,nod,Ix,Itx,Ivb,sizet);
%     woundedge=lnodExternalp(end-size(lnodaux,1)+1:end,1);
end
end
function [g]=Reorderg(g,dim,nod,Ix,Itx,Ivb,sizet)
gx                    =g(1:nod*dim);
gv                    =g(nod*dim+1:end);
gx(Ix)                =[];
aux=sort([dim*Ivb-1 dim*Ivb]);
gaux                  =gv(aux);
gv([dim*Itx-1 dim*Itx]) =[];
gv=[gv(1:dim*sizet);gaux;gv(dim*sizet+1:end)];
g=[gx;gv];
end