function [X,lnodFE,lnodExternal,lnod_ext,lnodW,remnod]=BoundaryFilter(X,lnodFEp,lnodFEadd,lnodWp,inc,Set,r,Pw,Rw)
deltaR=Set.deltaR;
deltaD=Set.deltaD;
dim=size(X,2);
% Filters external elements with high aspect ratio
if (inc<eps || deltaD<0)
    lnodFE=delaunay(X(:,1),X(:,2));
    lnodW =lnodWp;
   % remnod=[];
elseif ~r
    lnodFEp=[lnodFEp;lnodFEadd];
    [lnodFE,~]=DelaunayR(X,lnodFEp,deltaD);
    [lnodW,lnodFE]=DefineWoundEdge(lnodWp,lnodFE,X,Pw,Rw,Set);
    FEaux =sort(lnodFE,2);
    FEpaux=sort(lnodFEp,2);
%     I =~ismember(FEaux,FEpaux,'rows');
%     Ip=~ismember(FEpaux,FEaux,'rows');
%     remnod=unique([lnodFE(I,1);lnodFE(I,2);lnodFE(I,3);lnodFEp(Ip,1);lnodFEp(Ip,2);lnodFEp(Ip,3)]);
else
    lnodFE=lnodFEp;
    lnodW =lnodWp;
%    remnod=[];
end
remnod=[];
%  lnodW =lnodWp;
% Filter elements with high aspect ratio
s=1;
while s>0 
    F=zeros((dim+1)*size(lnodFE,1),dim+2);
    for i=1:size(lnodFE,1)
        F(i*(dim+1)-dim:i*(dim+1),:)=[nchoosek(lnodFE(i,:),dim) i*ones(dim+1,1) (1:dim+1)']; %%%matrix of triangles (edges in 2-D) marked with
        %the index of tetrahedron (triangles in 2-D)
    end
    G=sort(F(:,1:dim),2);          %%%sorting each face ( edge in 2-D)
    H=[G F(:,dim+1:dim+2)];        %%%marking again triangles(edges in 2-D) with indices of original tetrahedron(triangle in 2-D)
    C=sortrows(H,1:dim);
    B=diff(C(:,1:dim));
    %%% finding list of repeated(in common)triangles(edges in 2-D)
    %defined by their index of original tetrahedron(triangle in 2-D)
    j=all(B==0,2); % find (internal) duplicated faces
    B_ind=[C(j,dim+1) C(j,dim+2)]; % List of internal faces: [element local_face_number]
    j=[0;j]; % B had one row less than C (returns double)
    j=logical(j); % turn j into logical (components)
    B_ind=[B_ind;C(j,dim+1) C(j,dim+2)]; % Store for the 2 elements the internal face belongs to
    %%%%%%%%%%%version1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %   A=(1:size(lnodFE,1))'; % List of elements
    %   N=[A histc(B_ind(:,1),A)]; % Number of internal faces per element
    %   N_ext=N(N(:,2)~=dim+1);   %%%finding the number of repeated triangles(edges in 2-D) of each index
    %%%%%%%%%%version2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    lnod_ext=setdiff(F(:,dim+1:dim+2),B_ind,'rows');  %external faces (edges in 2-D) [global index of element    local index of face]
    N_ext=unique(lnod_ext(:,1));
%     lnodFE_ext=lnodFE(N_ext,:);  %%%defining external tetrahedrons(triangles in 2-D), given that
%     lnodFE(N_ext,:)=[];           %tetrahedrons(triangles in 2-D) on boundary are those which does
                                  %not share all their faces(edges in 2-D)
    s=0;
    for i=1:size(N_ext,1)                 %%%filtering tetrahedrons(triangles in 2-D) with high aspect ration
        truss_ind=nchoosek(lnodFE(N_ext(i),:),2);
        truss_vec=X(truss_ind(:,1),:)-X(truss_ind(:,2),:);
        truss_norm=sqrt(sum(abs(truss_vec).^2,2));
        %         min_t=min(truss_norm);
        %         max_t=max(truss_norm);
        w=(truss_norm(2)+truss_norm(3)-truss_norm(1))*(truss_norm(3)+truss_norm(1)-truss_norm(2))*(truss_norm(1)+truss_norm(2)-truss_norm(3))/(truss_norm(1)*truss_norm(2)*truss_norm(3));
        %         if min_t/max_t<=deltaR %|| abs(2*min_t/max_t-1)<=deltaR
        if w<=deltaR && (inc<eps || deltaD<0)
            s=s+1;
            lnodFE(N_ext(i),:)=0;
        end
    end
    if s>0
        %[e,~]=find(lnodFE==0);
        %lnodFE(e,:)=[];
        lnodFE(lnodFE(:,1)==0 & lnodFE(:,2)==0 & lnodFE(:,3)==0,:)=[];
    end
    %lnodFE=[lnodFE_ext;lnodFE]; % connectivty of external + internal elements
end
%%% Find external bar elements on the boundary
lnodExternal=zeros(size(lnod_ext,1),2);
for q=1:size(lnod_ext(:,1))
    lnodExternal(q,:)=F(ismember(F(:,3:4),lnod_ext(q,:),'rows'),1:2);
    if lnod_ext(q,2)==2
        lnodExternal(q,[1 2])=lnodExternal(q,[2 1]);
    end
end
% Remove hanging nodes of X
n=size(X,1);
Xaux=1:n;
Xaux2=1:n;
k=0;
for i=1:n
    if isempty(find(lnodFE==i,1))
        Xaux(i-k:n-1-k)=Xaux(i+1-k:n-k);
        Xaux2(i+1:n)=Xaux2(i+1:n)-1;
        k=k+1;
    end
end
if k>0
    Xaux(n-k+1:n)=[];
    X=X(Xaux,:);
    if size(X,2)==2 % 2D
        lnodFE=[Xaux2(lnodFE(:,1))' Xaux2(lnodFE(:,2))' Xaux2(lnodFE(:,3))'];
        lnodExternal=[Xaux2(lnodExternal(:,1))' Xaux2(lnodExternal(:,2))'];
    else
        lnodFE=[Xaux2(lnodFE(:,1))' Xaux2(lnodFE(:,2))' Xaux2(lnodFE(:,3))' Xaux2(lnodFE(:,4))'];
        lnodExternal=[Xaux2(lnodExternal(:,1))' Xaux2(lnodExternal(:,2))' Xaux2(lnodExternal(:,3))'];
    end
end
% a=ismember(lnodExternal(:,1),lnodW) | ismember(lnodExternal(:,2),lnodW);
% lnodW=lnodExternal(a,:);
% lnodExternal(a,:)=[];
% lnod_extW=lnod_ext(a,:);
% lnod_ext(a,:)=[];
% lnod_ext=[lnod_ext;lnod_extW];
end