function Mat=UpdateMat(Mat,p,param)
k=0;
for i=1:length(p)
    %  k kA kB GA GB eA eB Ec EcA EcB Ect EcAt kV kVA kVB GVA GVB eVA eVB EcV EcVA EcVB EcVt EcVAt
    if p(i)>0
        k=k+1;
        switch i
            case 1
                Mat.D.kappa=param(k);   % Stiffness of Main Delaunay
            case 2
                Mat.D.kappaA=param(k);  % Stiffness of 2nd branch Delaunay
            case 3
                Mat.D.kappaB=param(k);  % Stiffness of 3rd branch Delaunay
            case 4
                Mat.D.GammaA=param(k);  %GammaA=-1 dashpot branch on Delaunay
            case 5
                Mat.D.GammaB=param(k);
            case 6
                Mat.D.etaA=param(k);    % >0 Maxwell Viscosity of Delaunay 1st Branch, <0 dashpot only of Delaunay
            case 7
                Mat.D.etaB=param(k);    % >0 Maxwell Viscosity of Delaunay 2nd Branch, <0 dashpot only of Delaunay
            case 8
                Mat.D.Ec=param(k);      % Contractility in Spring Delaunay
            case 9
                Mat.D.EcA=param(k);     % Contractility in A
            case 10
                Mat.D.EcB=param(k);     % Contractility in B
            case 11
                Mat.D.Ect=param(k);     % time at which Contractility in elastic branch =Set.Ec (=0, constant contractility)
            case 12
                Mat.D.EcAt=param(k);    % time at which Contractility in active branch =Set.EcA (=0, constant contractility)
            case 13
                Mat.D.beta=param(k);    % parameter for self-regulation of contractility on Delaunay elastic branch
            case 14
                Mat.V.kappa=param(k);    %kappa for voronoi vertices stiffness
            case 15
                Mat.V.kappaA=param(k);   % Stiffness for Active/Maxwell 1st Branch on Voronoi
            case 16
                Mat.V.kappaB=param(k);   % Stiffness for Active/Maxwell 2nd Branch on Voronoi
            case 17
                Mat.V.GammaA=param(k);     % Viscossity for Active 1st Branch in voronoi. =0: no viscosity
            case 18
                Mat.V.GammaB=param(k);     % Viscossity for Active 2nd Branch in voronoi. =0: no viscosity
            case 19
                Mat.V.etaA=param(k);       % >0 Maxwell Viscosity of Voronoi 1st Branch, <0 dashpot only of Voronoi
            case 20
                Mat.V.etaB=param(k);       % >0 Maxwell Viscosity of Voronoi 2nd Branch, <0 dashpot only of Voronoi
            case 21
                Mat.V.Ec=param(k);       % Contractility in Spring Voronoi
            case 22
                Mat.V.EcA=param(k);      % Constractility in Voronoi
            case 23
                Mat.V.EcB=param(k);      % Constractility in Voronoi
            case 24
                Mat.V.Ect=param(k);      % time at which Contractility in elastic branch =Set.EcVor (=0, constant contractility)
            case 25
                Mat.V.EcAt=param(k);      % time at which Contractility in active branch =Set.EcVorA (=0, constant contractility)
            case 26
                Mat.V.beta=param(k);      % parameter for self-regulation of contractility on Voronoy elastic branch
        end
    end
end
