function [t,data]=PrepareExpData(Exp2,Exp4,Exp5,Exp6)
texp2=Exp2(:,1);
Aexp2=Exp2(:,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
texp4=Exp4(:,1);
Aexp4=Exp4(:,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
texp5=Exp5(:,1);
Aexp5=Exp5(:,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
texp6=Exp6(:,1);
Aexp6=Exp6(:,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tmin=min([texp2(end);texp4(end);texp5(end);texp6(end)]);
% texp2(texp2>tmin)=[];
% texp4(texp4>tmin)=[];
% texp5(texp5>tmin)=[];
% texp6(texp6>tmin)=[];
% Aexp2(texp2>tmin)=[];
% Aexp4(texp4>tmin)=[];
% Aexp5(texp5>tmin)=[];
% Aexp6(texp6>tmin)=[];
t=sort(unique([texp2;texp4;texp5;texp6]));
data=zeros(length(t),6);
i=1;
while  t(i)<=tmin && i<=length(t)
        t1=max(texp2(texp2<=t(i)));
        A1=Aexp2(texp2==t1);
        if t(i)-t1<eps
            data(i,1)=A1;
        else
            t2=min(texp2(texp2>t(i)));
            A2=Aexp2(texp2==t2);
            data(i,1)=((A2-A1)*(t(i)-t1)/(t2-t1))+A1;
        end
        %%
        t1=max(texp4(texp4<=t(i)));
        A1=Aexp4(texp4==t1);
        if t(i)-t1<eps
            data(i,2)=A1;
        else
            t2=min(texp4(texp4>t(i)));
            A2=Aexp4(texp4==t2);
            data(i,2)=((A2-A1)*(t(i)-t1)/(t2-t1))+A1;
        end
        %%
        t1=max(texp5(texp5<=t(i)));
        A1=Aexp5(texp5==t1);
        if t(i)-t1<eps
            data(i,3)=A1;
        else
            t2=min(texp5(texp5>t(i)));
            A2=Aexp5(texp5==t2);
            data(i,3)=((A2-A1)*(t(i)-t1)/(t2-t1))+A1;
        end
        %%
        t1=max(texp6(texp6<=t(i)));
        A1=Aexp6(texp6==t1);
        if t(i)-t1<eps
            data(i,4)=A1;
        else
            t2=min(texp6(texp6>t(i)));
            A2=Aexp6(texp6==t2);
            data(i,4)=((A2-A1)*(t(i)-t1)/(t2-t1))+A1;
        end
        i=i+1;
end
t=t(1:i-1);
data=data(1:i-1,:);
data(:,5)=mean(data(:,1:4),2);
data(:,6)=std(data(:,1:4),1,2);
end
