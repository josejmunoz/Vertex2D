function PrepareResults(Set,Mat,Ab,numrem,ener,tout,gout)
N=Set.Network;
D=Set.deltaD;
EcV=Mat.V.EcA;
EcD=Mat.D.EcA;
kD=Mat.D.kappaA;
kV=Mat.V.kappaA;
gammaD=Mat.D.GammaA;
gammaV=Mat.V.GammaA;
%%% file name format : Net size_W edge C factor_Del tol_kD_kV_EcD_EcV
fname=strcat(num2str(N),'_',num2str(Ab.Ec,'%1.1f'),'_',num2str(D,'%1.1f'),'_'...
    ,num2str(kD,'%1.1f'),'_',num2str(kV,'%1.1f'),'_',num2str(gammaD,'%1.3f'),'_',...
    num2str(gammaV,'%1.3f'),'_',num2str(EcD,'%1.1f'),'_',num2str(EcV,'%1.1f'),'_',...
    num2str(Set.Vp,'%2.0f'));
if ~exist('Results','dir')
    mkdir('Results')
end
cd('Results');
if ~exist(fname,'dir')
    mkdir(fname);
end
cd ..
if exist('VTKResults','dir')
    movefile('VTKResults',strcat('Results/',fname));
end
if exist('VTKResultsWound','dir')
    movefile('VTKResultsWound',strcat('Results/',fname));
end
cd(strcat('Results/',fname));
save('Set','Set');
save('Ab','Ab');
save('nrem','numrem');
save('Mat','Mat');
save('gout','gout');
save('tout','tout');
save('ener','ener');
cd ..
cd ..
end