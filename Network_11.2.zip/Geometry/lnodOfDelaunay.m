function [lnod,nodV,ia]=lnodOfDelaunay(lnodExternal,X,lnodFE,Set)
% Builds list of bar elements
% OUTPUT
% lnod : connectivity of bar elements
% nodv : list of internal nodes (will be centers of Voronoi)
% INPUT
% lnodExternal : list of external nodes (offset if Bcells=true)
% X            : nodes coordinates (internal and external)
Bcells=Set.Bcells;
nodes=size(X,1);
dim=size(X,2);
% Finds list of external nodes
nod=1:nodes;
for i=1:size(lnodExternal,1)
    if nod(lnodExternal(i))>0
        nod(lnodExternal(i))=0;
    end
end
% Builds consecutive list of internal nodes and external
if Bcells<0
    nodV=(1:size(X,1))';
else
    k=0;
    nodV=zeros(length(find(nod>0)),1);
    for i=1:nodes
        if nod(i)>0
            k=k+1;
            nodV(k)=nod(i);
        end
    end
end
% Builds lnod
lnod=zeros(dim*size(lnodFE,1),2);
for i=1:size(lnodFE,1)
    lnod(3*i-2:3*i,:)=nchoosek(lnodFE(i,:),2);
    lnod(3*i-1,[1 2])=lnod(3*i-1,[2 1]);
end
[~,ib,ia]=unique(sort(lnod,2),'rows');
lnod=lnod(ib,:);
end