function Ab=Ablate(Ab,Set)
% Define number of ablated and contracted cells dependent on number of cells
% OUTPUT:
% Ab.nodAb = list ablated cells
% Ab.Contract = list of contracted cells (may be different form Ab.nodAb)
if Set.Ablation>0 && Set.NetworkType<1
    if Set.Network==15
        if Set.Ablation>=3
            %Ab.nodAb=   [118 119 121 122 123 134 135 136 137 138 139]; %% 15x15 tissue, neural crest
            %Ab.Contract=[118 119 121 122 123 134 135 136 137 138 139 ]; %% Cells that will contract
            if Ab.Timed
                Ab.nodAbt=   [124 107 106 105 120 103 102 117
                    156 155 154 153 152 151 150 133 ]; % Pairs of contractile cells (around wound) for time sequence of contractions (Neural problem)
                Ab.nodAbTimes=[4 5 6 7 8 9 10 11]; % Time sequence for pairs of contractile for time sequence
            end
        elseif Set.Ablation>=2
            Ab.nodAb=    [118 119 120 121 122 134 135 136 137 138 152]; %% 15x15 tissue, neural crest
            %        Ab.Contract=[118 119 120         134 135             152];
        else
            Ab.nodAb=[119 120 121 135 136 137 152]; %% 15x15 tissue
        end
    elseif Set.Network==13
        if Set.Ablation>=1.6
            Ab.nodAb=[90 91 92 104 105 106 118 119 120]; %% 13x13 tissue
        elseif Set.Ablation>=1.5
            Ab.nodAb=[76 77 90 91 92 104 105 106]; %% 13x13
        else
            Ab.nodAb=[91 92 105 106];
        end
    elseif Set.Network==12
        Ab.nodAb=[72 85 86 98 99]; % 12x12
    elseif Set.Network==10
        if Set.Ablation>1.5
            Ab.nodAb=[49 50 51 60 61 62 71 72 73];  %% 10x10 tissue
        elseif Set.Ablation>1.4
            Ab.nodAb=[60 61 62 71 72 73];
        elseif Set.Ablation>=1.3
            Ab.nodAb=[60 61 71 72];  %% 10x10 tissue
        elseif Set.Ablation>=1.2
            Ab.nodAb=[49 50 61];
        elseif Set.Ablation>0
            Ab.nodAb=61;
        end
    end
end
% Ab.nodAb=[2 5 6 64 66 81]; %% 050117.tif tissue
% Ab.nodAb=[1 2 3 60 65 67 77]; %% 221216.tif tissue
% Ab.nodAb=[2];
% Ab.nodAb=[61];
% Ab.nodAb=[4 47 6 2 3 48 53]; %%121216.tif
% Ab.nodAb=[135 145 119 3 133 5 2 125];  %% 150416.tif
%  Ab.nodAb=[2 3 4 5 64 59 70 69 75 79 87]; %% 150416m.png
if Set.Ablation>0 && ~isfield(Ab,'Contract')
    Ab.Contract=Ab.nodAb;
end
end