function [X]=correctNode(X,V,vor_cell,nodV)
x=reshape(X',dim*nodes,1);
for i=1:size(nodV)
    nv=vor_cell{nodV(i)};
    nv(end)=[];
    d=dim*(nodV(i)-1)+1:dim*nodV(i);
    A=0;
    B=0;
    for j=1:(length(nv)-1)
        a=(V(nv(j),1)*V(nv(j+1),2)-V(nv(j+1),1)*V(nv(j),2));
        A=A+a;
        B=B+(V(nv(j),:)+V(nv(j+1),:))*a;
    end
    a=V(nv(end),1)*V(nv(1),2)-V(nv(1),1)*V(nv(end),2);
    A=A+a;
    B=B+(V(nv(end),:)+V(nv(1),:))*a;
    x(d)=B/(A*3);
end
X=reshape(x',dim,nodes)';
end