function [g,K] = gKXi(dim,nodes,nodesV,Vor,Vorp,xi,xip,Set)
%GKXI Summary of this function goes here
%   Detailed explanation goes here
%xip=ones(size(xi,1),size(xi,2))/3;
if Set.Vrel
    vorp=reshape(Vorp',dim*size(Vorp,1),1);
    vor=reshape(Vor',dim*size(Vor,1),1);
    g=[zeros(nodes*dim,1);vor-vorp];
else
    g=[zeros(nodes*dim,1);xi-xip];
end
if Set.sparseM
    n=nodesV*dim;
    N=(nodes+nodesV)*dim;
    i=nodes*dim+1:N;
    v=ones(n,1);
    K=sparse(i,i,v,N,N);
else
    K=[zeros(nodes*dim,nodes*dim) zeros(nodes*dim,nodesV*dim)
        zeros(nodesV*dim,nodes*dim) eye(dim*nodesV)];
end

end

