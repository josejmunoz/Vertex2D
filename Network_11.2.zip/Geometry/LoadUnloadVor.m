function Vor=LoadUnloadVor(Vor,cdofv,cdof,vor_cell,Set,BC,Step,sizet,TL)
nodesV=size(Vor,1);
nodes=size(vor_cell,1);
dim=size(Vor,2);
v=reshape(Vor',nodesV*dim,1);
% cellnum=unique(ceil(cdof));
% cdofv_aux=zeros(sum(cellfun('length',vor_cell{cellnum})),1);
% for i=1:length(cellnum)
%     cell_aux=vor_cell{cellnum(i)};
%     cell_aux(1)=[];
%     cell_aux=cell_aux(cell_aux>sizet);
if BC.Monotonic
    v(cdofv-nodes*dim)=v(cdofv-nodes*dim)+Step.dt*BC.xStretch*TL/BC.ts;
elseif BC.Step
    %     if cell_aux*dim
    if Step.t-BC.ts<eps
        v(cdofv-nodes*dim)=v(cdofv-nodes*dim)+Step.dt*BC.xStretch*TL/BC.ts;
    elseif BC.Reverse
        v(cdofv-nodes*dim)=v(cdofv-nodes*dim)-Step.dt*BC.xStretch*TL/BC.ts;
    end
end
Vor=reshape(v',dim,nodesV)';
end