function PostSet(esc)
% Processes after running Netowrk codes
rmpath(strcat(pwd,esc,'Rheology'));
rmpath(strcat(pwd,esc,'Geometry'));
rmpath(strcat(pwd,esc,'Fitting'));
rmpath(strcat(pwd,esc,'ExpData'));
rmpath(strcat(pwd,esc,'VTK'));
fclose('all');
