function CreatvtkTriVor2D(i,X,lnod,lnodFE,Trigroup,stressVol,Ab,AbActive,wound)
if isempty(Trigroup)
    return;
end
if wound
    str0='VTKResultsWound';
else
    str0='VTKResults';
end
str2='.vtk';
str3 = num2str(i);
str4='.TriVor.';
str13=strcat(str0,str4,str3);
comp=computer;
if strcmp(comp(1:3),'PCW') % Windows machine
    newSubFolder = sprintf('%s\\%s',pwd,str0);
else
    newSubFolder = sprintf('%s/%s',pwd,str0);
end
if ~exist(newSubFolder, 'dir')
    mkdir(newSubFolder);
end
cd(newSubFolder);
nameout=strcat(str13,str2);
file=fopen(nameout,'w');
fprintf(file,'%s\n','# vtk DataFile Version 3.98');
fprintf(file,'%s\n','Delaunay_vtk');
fprintf(file,'%s\n','ASCII');
fprintf(file,'%s\n','DATASET UNSTRUCTURED_GRID');
%%%%%%%%%%%%%
if AbActive
    lnod(Ab.eleVorDD,:)=[];
    stressVol(Ab.cellAb)=[];
end
%%%%%%%%%%%%%
nodes=length(X);
fprintf(file,'%s %d %s\n','POINTS',nodes,'float');
for i=1:nodes
    fprintf(file,' %f %f %f\n',X(i,1),X(i,2),0);
end
neleFE=size(lnodFE,1);
nele=size(lnod,1);
lnodFEd=lnodFE-1;
fprintf(file,'%s %d %d\n','CELLS',neleFE+nele,neleFE*(size(lnodFE(1,:),2)+1)+nele*(size(lnod(1,:),2)+1));
for j=1:size(lnodFEd,1)
    fprintf(file,'%d %d %d %d\n',size(lnodFEd(j,:),2),lnodFEd(j,1),lnodFEd(j,2),lnodFEd(j,3));
end
lnodd=lnod-1;
for j=1:size(lnodd,1)
    fprintf(file,'%d %d %d\n',size(lnodd(j,:),2),lnodd(j,1),lnodd(j,2));
end
fprintf(file,'%s %d\n','CELL_TYPES',neleFE+nele);
for j=1:size(lnodFE,1)
    fprintf(file,'%d\n',5);
end
for j=1:size(lnod,1)
    fprintf(file,'%d\n',3);
end
fprintf(file,'%s %d \n','CELL_DATA',neleFE+nele);
fprintf(file,'%s \n','SCALARS stress float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:size(Trigroup,1)
    for t=Trigroup(i,1):Trigroup(i,2)
        fprintf(file,'%f\n',stressVol(i));
    end
end
fprintf(file,'%f\n',zeros(nele,1));
fprintf(file,'%s \n','SCALARS Cell_ID float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:size(Trigroup,1)
    for t=Trigroup(i,1):Trigroup(i,2)
        fprintf(file,'%f\n',i);
    end
end
fprintf(file,'%f\n',zeros(nele,1));
fclose(file);
cd '..'