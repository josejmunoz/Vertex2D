function [Vor,vor_cell,vor_cell_ele,lnod,lnod_vor,V,ln,celledge,edgesize,celledgeW,vor_cellW,cdofv,dofdeletev,remnod,C]=VoronoiInitial(BC,X,lnodFE,Mat,nodV,Vor,Vorpp,lnod,lnodp,lnod_vorp,lnod_ext,lnodExternal,lnodW,lnodExternalp,lnodWp,ia,mode,celledgep,Set,Vp,r,inc)
% Builds Voronoi Cells
nodes=size(X,1);
dim=size(Vor,2);
tolV=0.8;
s=[2 3;3 1;1 2]; % Not in 3D
nodesV=length(nodV);
sizet=size(lnodFE,1);
sizel=size(lnod,1);
if min(size(nodV))==0
    vor_cell=[];
    vor_cell_ele=[];
    lnod_vor=[];
    V=[];
    ln=[];
    return;
end
cdofv=[];
dofdeletev=[];
celledge=[];
edgesize=[];
celledgeW=[];
vor_cellW=[];
cc=0;
% if mode==0
V=zeros(nodesV,1);
% end
vor_cell=cell(nodesV,1);
vor_cell_ele=vor_cell;
% %%%%
% if mode==1  %% finding remodelled cells
%     I=~ismember(sort(lnod,2),sort(lnodp,2),'rows');
%     remnod=unique([lnod(I,1);lnod(I,2)]);   %% index remodelled cells
%     I=ismember(nodV,remnod);
% else
%     I=false(nodesV);
% end
% %%%%
% nodB=sort(lnodExternal(:,1));
nodB=sort(lnodExternal(:,1));
for k=1:size(nodV)
    %     r=false;
    if ismember(nodV(k),nodB)
        [vor_cell{k},cc]=BoundaryCell(nodV(k),cc,lnodFE,lnod_ext);
    else
        i=nodV(k);
        [vor_cell{k},~]=find(lnodFE==i);  %%obtaining indices of triangles (Voronoi vertices corresponding to cell i) sharing node i
        lnod_aux1=zeros(size(vor_cell{k},1),3);
        lnod_aux2=lnod_aux1;
        for j=1:size(vor_cell{k},1)
            a= lnodFE(vor_cell{k}(j),:)==i;
            lnod_aux1(j,1:2)=lnodFE(vor_cell{k}(j),s(a,:)); %%sorting Voronoi elements of cell i described counterclock-wise
        end
        lnod_aux1(:,3)=vor_cell{k};
        a=1;
        lnod_aux2(1,:)=lnod_aux1(1,:);
        lnod_aux1(1,:)=0;
        while a<size(vor_cell{k},1)
            lnod_aux2(a+1,:)=lnod_aux1(lnod_aux1(:,1:2)==lnod_aux2(a,2),:);  %%obtaining sequence of Voronoi elements of cell i respected to sequence of adjacent triangles
            lnod_aux1(lnod_aux1==lnod_aux2(a,2),:)=0;
            a=a+1;
        end
        vor_cell{k}=[lnod_aux2(:,3);lnod_aux2(1,3)];
        for j=1:size(vor_cell{k},1)-1
            vor_cell_ele{k}(j,:)=[vor_cell{k}(j) vor_cell{k}(j+1)]; %%building set of elements in Voronoi cell i (in counterclock-wise order)
            V(k)=V(k)+0.5*det([Vor(vor_cell{k}(j),:);Vor(vor_cell{k}(j+1),:)]);  %%calculating volume of cell i
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%approach 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% lnod_vor=unique(sort(cell2mat(vor_cell_ele),2),'rows');  %%Voronoi network connectivity matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%approach 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lnod_vor=zeros(sizel,2);
nele=1:length(ia);
for i=1:sizel
    if sum(ia==i)>1
        a=nele(ia==i);
        lnod_vor(i,:)=(ceil(a/((dim/2)*(dim+1))))';
    end
end
nele=1:sizel;
nele_del=nele(lnod_vor(:,1)==0);
lnod(nele_del,:)=[];
lnod_vor(nele_del,:)=[];
if cc<eps
    A=unique([lnodExternal(:,1);lnodExternal(:,2)]);
    B=sum(ismember(lnod,A),2);
    lnodaux=lnod(B==2,:);
    lnod(B==2,:)=[];
    lnod_vor(B==2,:)=[];
else
    lnodaux=[];
    lnod_vor=[lnod_vor;[lnod_ext(:,1) sizet+(1:length(nodB))']];
end
lnod=[lnod;lnodaux;lnodExternal];
C.lnod=cell(nodes,1);
for i=1:size(lnod,1)        %% cell connectivity index in the global nodal connectivity 
    ele=lnod(i,:);
    C.lnod{ele(1)}=[C.lnod{ele(1)};i];
    C.lnod{ele(2)}=[C.lnod{ele(2)};i];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if cc>0
    lnod_vor1=lnod_vor;
    [Vor,lnod_vor,vor_cell,celledge,edgesize,celledgeW,vor_cellW,remnod]=DefineExtVertex(X,Vor,Vorpp,vor_cell,lnod,lnodp,lnodExternal,lnodW,lnodExternalp,lnodWp,lnod_vor,lnod_vorp,nodB,celledgep,Set,r,Vp,inc);
    if Set.Xirel>0
        vb=lnod_vor1(sizel-length(nodB)+1:sizel,2);
        vb=vb(~ismember(sort(lnodExternal,2),sort(lnodW,2),'rows'));
        if Set.NetworkType==0 && BC.FullConstr<0
            l12=X(lnodExternal(:,2),:)-X(lnodExternal(:,1),:);
            norm12=sqrt(sum(l12.^2,2));% =vecnorm(l12,2,2);
            e12=[l12(:,1)./norm12 l12(:,2)./norm12];
            nT=e12*[0 1;-1 0];
            I= nT(:,1)<-tolV;
            vbc=vb(I);
            cdofv=nodes*dim+dim*(vbc-1)+1;
            %cdofv=reshape(cdofv',dim*length(vb),1);
            I=nT(:,1)>tolV;
            vbd=vb(I);
            if BC.CVert
                dofdeletev1=nodes*dim+dim*(vbd-1)*ones(1,dim)+ones(size(vbd,1),1)*(1:dim);
                dofdeletev1=reshape(dofdeletev1',dim*length(vbd),1);
                dofdeletev2=cdofv+(1:dim-1);
                dofdeletev2=reshape(dofdeletev2',(dim-1)*length(cdofv),1);
                dofdeletev=[dofdeletev1;dofdeletev2];
            else
                dofdeletev=nodes*dim+dim*(vbd-1)+1;
            end
        elseif BC.FullConstr>0
            aux=dim*(vb-1)+(1:dim);
            dofdeletev=nodes*dim+reshape(aux',length(vb)*dim,1);
        else
            if BC.mu<eps
                r=Set.Network;
                Vb=Vor(vb,:);
                c=[r 0];
                s=[r 2*r];
                dl1=sqrt(sum(([c(1)-Vb(:,1) c(2)-Vb(:,2)]).^2,2));
                dl2=sqrt(sum(([s(1)-Vb(:,1) s(2)-Vb(:,2)]).^2,2));
                [~,I]=min(dl1);
                [~,J]=min(dl2);
                vbI=vb(I);
                vbJ=vb(J);
                dofdeletev=nodes*dim+[2*vbI-1;2*vbI;2*vbJ-1];
            end
        end
    end
    for i=1:cc
        for j=1:size(vor_cell{nodB(i)},1)-1
            vor_cell_ele{nodB(i)}(j,:)=[vor_cell{nodB(i)}(j) vor_cell{nodB(i)}(j+1)];
            V(nodB(i))=V(nodB(i))+0.5*det([Vor(vor_cell{nodB(i)}(j),:);Vor(vor_cell{nodB(i)}(j+1),:)]);
        end
    end
end
ln.S.e=sqrt(sum((Vor(lnod_vor(:,2),:)-Vor(lnod_vor(:,1),:)).^2,2));
ln.A.r=ln.S.e;
ln.B.r=ln.S.e;
if  Mat.etaA>0
    ln.A.e=0.5*ln.A.r;
else
    ln.A.e=ln.A.r;
end
if  Mat.etaB>0
    ln.B.e=0.5*ln.B.r;
else
    ln.B.e=ln.B.r;
end
if mode==0
    % Set contractility
    ln.S.c=Mat.Ec*ones(size(ln.S.e));
    ln.A.c=Mat.EcA*ones(size(ln.A.r));
    ln.B.c=Mat.EcB*ones(size(ln.B.r));
end
end