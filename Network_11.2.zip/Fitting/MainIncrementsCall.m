function y=MainIncrementsCall(param,t)
% Interface for calling ActiveMaxwell in the manner that lsqcurvefit wants
% param = set of material parameters to be fitted
% t     =time-seps for which gout will be fitted
% y     =stress or reaction values at times t
% Load global structures Mat,Step, Set and BC
load('Fitting'); % contains Mat, Step, Set, BC , and p structures
if ~exist('p','var')
    disp('No array of parameters p is defined inside Fitting.mat');
    return;
end
n=length(param);
m=sum(p~=0);
if m~=n
    disp('Parameters in stored vector p are different from those sended to ActiveMaxellCall');
    if m>n
        k=0;
        for i=1:length(p)
            if p(i)>0
                if k==n
                    p(i)=0;
                else
                    k=k+1;
                end
            end
        end
        
    else
        param=param(1:m);
    end
end
Mat=UpdateMat(Mat,p,param);
Set.FitIter=Set.FitIter+1;
% Compute reaction for the values in param
[gout,~,tout,u,~,~]=MainIncrements(Mat,Step,Set,BC,Ab);
save('Fitting','Ab','Mat','Set','Step','BC','p');
% Retrieve values at times t of input
y=Interpolate(u,t,tout);
u=y;
y=Interpolate(gout,t,tout);
gout=y;
save('gout','gout','u');
load('Y');
if Set.Fitting
    pt=sprintf('%f ',param);
    fprintf('Iteration: %i. Norm=%e. Param=%s\n',Set.FitIter,norm(gout-Y),pt);
end
end

function y=Interpolate(gout,t,tout)
% Use linear inteprolation in order to get values of gout at time t
y=zeros(size(t));
if length(tout)==1
    y=gout(1);
    return;
end
k=1;
for i=1:length(t)
    ti=t(i);
    while tout(k)<ti && k<length(tout)
        k=k+1;
    end
    if k==1 && ti<=tout(k)
        y(i)=gout(1);
    elseif k==length(tout)
        if ti>=tout(k)
           y(i)=gout(end);
        else
            y(i)=(gout(k)-gout(k-1))/(tout(k)-tout(k-1))*(ti-tout(k-1))+gout(k-1);
        end
    else
        y(i)=(gout(k)-gout(k-1))/(tout(k)-tout(k-1))*(ti-tout(k-1))+gout(k-1);            
    end
end
end
