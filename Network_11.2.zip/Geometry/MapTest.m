function [ln,nrem,error,nodError]=MapTest(X,V,lnod,lnodp,lnodv,lnodvp,lnodext,lnodW,lnodextp,lnodWp,ln,vor_cell,nodv,N,g,gD,gV,gA,Mat,FE,Set,Ab,nrem,nodesp,Vol0,Vol,stressp,celledge,celledgep,edgesize,Wln,rr)
map=Set.Map;
disp=Set.DispBased;
split=Set.MapSplit;
reg_l=Set.Reg_l;  % Type of regularisation: when =true: regularisation with respect to the current lengths,
% when =false: regularisation with respect to the resting lengths of old elements, and with
% respect to current length of new elements.
Bcells=Set.Bcells;
MapAb=Ab.Map;
AbCoD=Ab.Co;
AbCoV=Ab.CoVor;
DDL=Ab.eleDDL;    
VDD=Ab.eleVorDD;
VDL=Ab.eleVorDL;
ele=size(lnod,1);
elev=size(lnodv,1);
lrn=ln.D.n1.A.r;
lrnv=ln.V.n1.A.r;
eCA=ln.D.n1.A.c;
eCvA=ln.V.n1.A.c;
ln.V.n.A.r=zeros(size(lnodv,1),1);
ln.V.n.B.r=ln.V.n.A.r;
kk=Mat.D.kappaA;
kkv=Mat.V.kappaA;
EcD=Mat.D.EcA;
EcV=Mat.V.EcA;
nodes=size(X,1);
dim=size(X,2);
nodesv=size(V,1);
nodVin=size(N,1);
if Mat.D.GammaA>eps
    eCA=zeros(ele,1);
end
Dcell=cell(nodes,1);
a=nodes-nodesp;
if Bcells>0 && a>=0
    g =[g(1:dim*nodesp);zeros(dim*a,1)];
    gD=[gD(1:dim*nodesp);zeros(dim*a,1)];
    gV=[gV(1:dim*nodesp);zeros(dim*a,1)];
end
g  =reshape(g(1:dim*  nodes),dim,nodes)';
gD =reshape(gD(1:dim*  nodes),dim,nodes)';
gV =reshape(gV(1:dim*  nodes),dim,nodes)';
gAv=-reshape(gA(dim* nodes+1:end),dim,nodesv)';
%gAv=zeros(size(gAv));
gA =reshape(gA(1:dim*  nodes),dim,nodes)';
gV=gV-gA;
g=g-gA;
l=sqrt(sum((X(lnod(:,2),:)-X(lnod(:,1),:)).^2,2));
nodext=lnodext(:,1);
pp =1e2;   %%Regularisation factor
ppl=0;     %%Relative regularisation factor for new elements when Set.Reg_l=false
if Mat.V.GammaA>eps
    eCvA=zeros(elev,1);
end
Vcell=cell(nodesv,1);
lv=sqrt(sum((V(lnodv(1:elev,2),:)-V(lnodv(1:elev,1),:)).^2,2));
nVor=1:nodesv;
for i=1:elev
    Vcell{lnodv(i,1)}=[Vcell{lnodv(i,1)} i];
    Vcell{lnodv(i,2)}=[Vcell{lnodv(i,2)} i];
end
for i=1:ele                                            %%Dcell contains the index of lnod conected to each node
    Dcell{lnod(i,1)}=[Dcell{lnod(i,1)} i];
    Dcell{lnod(i,2)}=[Dcell{lnod(i,2)} i];
end
k=kk*ones(1,ele);
kv=kkv*ones(1,elev);
if MapAb
    k(DDL) =AbCoD*k(DDL);
    kv(VDD)=AbCoV*kv(VDD);
end
if Set.DispBased && Set.Bcells<0
    kv(ele+1:end)=edgesize'.*kv(ele+1:end);
    if Ab.Eca
        kv(VDL)=Ab.Ec*kv(VDL);
    end
end
if map
    if MapAb
        VDLnod=unique([lnodv(VDL,1);lnodv(VDL,2)]);
    end
    A=zeros(ele+elev,ele+elev);
    b=zeros(ele+elev,1);
    for i=1:ele+elev
        if i<=ele
            e=(X(lnod(i,2),:)-X(lnod(i,1),:))/l(i);
            for p=1:2
                n=Dcell{lnod(i,p)};
                el=lnod(n,:);
                for j=1:length(n)
                    if el(j,1)~=lnod(i,p)
                        el(j,:)=[el(j,2) el(j,1)];
                    end
                end
                lvec=X(el(:,2),:)-X(el(:,1),:);
                if disp
                    bp=sum([k(n)'.*lvec(:,1) k(n)'.*lvec(:,2)],1);
                    bp1=sum([k(n)'.*(eCA(n).*lvec(:,1)) k(n)'.*(eCA(n).*lvec(:,2))],1);
                    A(i,n)=A(i,n)+((-1)^p)*k(i)*k(n).*(e*[lvec(:,1)./l(n) lvec(:,2)./l(n)]');
                    if split
                        b(i)=b(i)+((-1)^p)*k(i)*(bp-bp1+gD(lnod(i,p),:))*e';
                    else
                        b(i)=b(i)+((-1)^p)*k(i)*(bp-bp1+g(lnod(i,p),:))*e';
                    end
                else
                    bp=sum([k(n)'.*lvec(:,1)./l(n) k(n)'.*lvec(:,2)./l(n)],1);
                    bp1=sum([k(n)'.*(eCA(n).*lvec(:,1)./l(n)) k(n)'.*(eCA(n).*lvec(:,2)./l(n))],1);
                    A(i,n)=A(i,n)+((-1)^p)*k(i)*l(i)*k(n).*(e*lvec');
                    if split
                        b(i)=b(i)+((-1)^p)*k(i)*l(i)*(bp-bp1-gD(lnod(i,p),:))*e';
                    else
                        b(i)=b(i)+((-1)^p)*k(i)*l(i)*(bp-bp1-g(lnod(i,p),:))*e';
                    end
                end
            end
            if Set.Xirel<1
                for p=1:2
                    if isempty(nodext(nodext==lnod(i,p)))
                        vor_cellp=vor_cell{nodv==lnod(i,p)};
                        vor_cellp(end)=[];
                    else
                        vor_cellp= ismember(FE(:,1),lnod(i,p)) | ismember(FE(:,2),lnod(i,p)) | ismember(FE(:,3),lnod(i,p));
                        vor_cellp=nVor(vor_cellp);
                    end
                    %%%
                    vor_cellp(vor_cellp>nodVin)=[];  %%removing relaxed vertices at the boundary from set of vertices around node p
                    if MapAb
                        r=ismember(vor_cellp,VDLnod);
                        vor_cellp(r)=[];
                    end
                    %%%
                    nv=Vcell(vor_cellp);
                    Np=N(vor_cellp,:);
                    for j=1:length(vor_cellp)
                        if ~isempty(nv{j})
                            elv=lnodv(nv{j},:);
                            for m=1:length(nv{j})
                                if elv(m,1)~=vor_cellp(j)
                                    elv(m,:)=elv(m,[2 1]);
                                end
                            end
                            lvecv=V(elv(:,2),:)-V(elv(:,1),:);
                            lvecv=lvecv*Np(j,FE(vor_cellp(j),:)==lnod(i,p));
                            if disp
                                bv=sum([kv(nv{j})'.*lvecv(:,1) kv(nv{j})'.*lvecv(:,2)],1);
                                bv1=sum([kv(nv{j})'.*(eCvA(nv{j}).*lvecv(:,1)) kv(nv{j})'.*(eCvA(nv{j}).*lvecv(:,2))],1);
                                A(i,ele+nv{j})=A(i,ele+nv{j})+((-1)^p)*k(i)*kv(nv{j}).*(e*[lvecv(:,1)./lv(nv{j}) lvecv(:,2)./lv(nv{j})]');
                                if ~split
                                    b(i)=b(i)+((-1)^p)*k(i)*(bv-bv1)*e';
                                end
                            else
                                bv=sum([kv(nv{j})'.*lvecv(:,1)./lv(nv{j}) kv(nv{j})'.*lvecv(:,2)./lv(nv{j})],1);
                                bv1=sum([kv(nv{j})'.*(eCvA(nv{j}).*lvecv(:,1)./lv(nv{j})) kv(nv{j})'.*(eCvA(nv{j}).*lvecv(:,2)./lv(nv{j}))],1);
                                A(i,ele+nv{j})=A(i,ele+nv{j})+((-1)^p)*k(i)*l(i)*kv(nv{j}).*(e*lvecv');
                                if ~split
                                    b(i)=b(i)+((-1)^p)*k(i)*l(i)*(bv-bv1)*e';
                                end
                            end
                        end
                    end
                end
            end
        else
            e=(V(lnodv(i-ele,2),:)-V(lnodv(i-ele,1),:))/lv(i-ele);
            for p=1:2
                %%%%begin  including mechanical equilibrium at vertices on the wound edge (free vertices)
%                 if lnodv(i-ele,p)<=nodVin
                 r=false;
                 if lnodv(i-ele,p)>nodVin || (Set.Xirel>0 && Set.Vrel)
                     r=true;
                 end
                    %%%
                    if MapAb
                        r=ismember(lnodv(i-ele,p),VDLnod);
                    end
                    %%%
                    if r
                        nn=Vcell{lnodv(i-ele,p)};
                        ell=lnodv(nn,:);
                        for jj=1:length(nn)
                            if ell(jj,1)~=lnodv(i-ele,p)
                                ell(jj,:)=[ell(jj,2) ell(jj,1)];
                            end
                        end
                        lvecvv=V(ell(:,2),:)-V(ell(:,1),:);
                        if disp
                            bvv=sum([kv(nn)'.*lvecvv(:,1) kv(nn)'.*lvecvv(:,2)],1);
                            bvv1=sum([kv(nn)'.*(eCvA(nn).*lvecvv(:,1)) kv(nn)'.*(eCvA(nn).*lvecvv(:,2))],1);
                            A(i,nn+ele)=A(i,nn+ele)+((-1)^p)*kv(i-ele)*kv(nn).*(e*[lvecvv(:,1)./lv(nn) lvecvv(:,2)./lv(nn)]');
                            b(i)=b(i)+((-1)^p)*kv(i-ele)*(bvv-bvv1-gAv(lnodv(i-ele,p),:))*e';
                        else
                            bvv=sum([kv(nn)'.*lvecvv(:,1)./lv(nn) kv(nn)'.*lvecvv(:,2)./lv(nn)],1);
                            bvv1=sum([kv(nn)'.*(eCvA(nn).*lvecvv(:,1)./lv(nn)) kv(nn)'.*(eCvA(nn).*lvecvv(:,2)./lv(nn))],1);
                            A(i,nn+ele)=A(i,nn+ele)+((-1)^p)*kv(i-ele)*lv(i-ele)*kv(nn).*(e*lvecvv');
                            b(i)=b(i)+((-1)^p)*kv(i-ele)*lv(i-ele)*(bvv-bvv1-gAv(lnodv(i-ele,p),:))*e';
                        end
                    else
                        s=FE(lnodv(i-ele,p),:);
                        for j=1:size(s,2)
                            n=Dcell{s(j)};
                            el=lnod(n,:);
                            for m=1:length(n)
                                if el(m,1)~=s(j)
                                    el(m,:)=el(m,[2 1]);
                                end
                            end
                            lvec=X(el(:,2),:)-X(el(:,1),:);
                            if disp
                                bd=sum([k(n)'.*lvec(:,1) k(n)'.*lvec(:,2)],1);
                                bd1=sum([k(n)'.*(eCA(n).*lvec(:,1)) k(n)'.*(eCA(n).*lvec(:,2))],1);
                                A(i,n)=A(i,n)+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*k(n).*(e*[lvec(:,1)./l(n) lvec(:,2)./l(n)]');
                                if ~split
                                    b(i)=b(i)+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*(bd-bd1+g(s(j),:))*e';
                                end
                            else
                                bd=sum([k(n)'.*lvec(:,1)./l(n) k(n)'.*lvec(:,2)./l(n)],1);
                                bd1=sum([k(n)'.*(eCA(n).*lvec(:,1)./l(n)) k(n)'.*(eCA(n).*lvec(:,2)./l(n))],1);
                                A(i,n)=A(i,n)+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*lv(i-ele)*k(n).*(e*lvec');
                                if ~split
                                    b(i)=b(i)+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*lv(i-ele)*(bd-bd1-g(s(j),:))*e';
                                end
                            end
                            if isempty(nodext(nodext==s(j)))
                                vor_cellv=vor_cell{nodv==s(j)};
                                vor_cellv(end)=[];
                            else
                                vor_cellv= ismember(FE(:,1),s(j)) | ismember(FE(:,2),s(j)) | ismember(FE(:,3),s(j));
                                vor_cellv=nVor(vor_cellv);
                            end
                            %%%%
                            vor_cellv(vor_cellv>nodVin)=[];
                            if MapAb
                                r=ismember(vor_cellv,VDLnod);
                                vor_cellv(r)=[];
                            end
                            %%%%
                            nv=Vcell(vor_cellv);
                            Ne=N(vor_cellv,:);
                            for m=1:length(vor_cellv)
                                if ~isempty(nv{m})
                                    elv=lnodv(nv{m},:);
                                    for mm=1:length(nv{m})
                                        if elv(mm,1)~=vor_cellv(m)
                                            elv(mm,:)=elv(mm,[2 1]);
                                        end
                                    end
                                    lvecv=V(elv(:,2),:)-V(elv(:,1),:);
                                    lvecv=lvecv*Ne(m,FE(vor_cellv(m),:)==s(j));
                                    if disp
                                        bv=sum([kv(nv{m})'.*lvecv(:,1) kv(nv{m})'.*lvecv(:,2)],1);
                                        bv1=sum([kv(nv{m})'.*(eCvA(nv{m}).*lvecv(:,1)) kv(nv{m})'.*(eCvA(nv{m}).*lvecv(:,2))],1);
                                        A(i,ele+nv{m})=A(i,ele+nv{m})+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*kv(nv{m}).*(e*[lvecv(:,1)./lv(nv{m}) lvecv(:,2)./lv(nv{m})]');
                                        b(i)=b(i)+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*(bv-bv1)*e';
                                    else
                                        bv=sum([kv(nv{m})'.*lvecv(:,1)./lv(nv{m}) kv(nv{m})'.*lvecv(:,2)./lv(nv{m})],1);
                                        bv1=sum([kv(nv{m})'.*(eCvA(nv{m}).*lvecv(:,1)./lv(nv{m})) kv(nv{m})'.*(eCvA(nv{m}).*lvecv(:,2)./lv(nv{m}))],1);
                                        A(i,ele+nv{m})=A(i,ele+nv{m})+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*lv(i-ele)*kv(nv{m}).*(e*lvecv');
                                        b(i)=b(i)+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*lv(i-ele)*(bv-bv1)*e';
                                    end
                                end
                            end
                            if disp
                                if split
                                    b(i)=b(i)+((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*(gV(s(j),:))*e';
                                end
                            else
                                if split
                                    b(i)=b(i)-((-1)^p)*N(lnodv(i-ele,p),j)*kv(i-ele)*lv(i-ele)*(gV(s(j),:))*e';
                                end
                            end
                        end
                    end
            end
        end
    end
    % Regularisation
    aux=sort(lnod,2);
    auxp=sort(lnodp,2);
    [I,locp]=ismember(aux,auxp,'rows');
    if ele>elev
        [Iv,locpv]=ismember(aux(1:size(lnodv,1),:),auxp(1:size(lnodvp,1),:),'rows');
    else
        Iv=I;
        locpv=locp;
        Iv=[Iv;false(elev-ele,1)];
        locpv=[locpv;zeros(elev-ele,1)];
    end
    rem=~I;
    if MapAb  %% excluding wound remodellings from the total number of remodellings
        rem(Ab.eleDD)=false;
    end
    nrem=sum(rem);
    if reg_l
        laux=l;
        lvaux=lv;
        I=ones(ele,1);
        Iv=ones(elev,1);
    else
        if  ~isequal(lnodv,lnodvp)
            if disp
                laux =zeros(size(l,1),1);
                lvaux=zeros(size(lv,1),1);
            else
                laux =Inf(size(l,1),1);
                lvaux=Inf(size(lv,1),1);
            end
            laux(I)   =lrn(locp(I));
            laux(~I)  =l(~I);
            lvaux(Iv) =lrnv(locpv(Iv));
            lvaux(~Iv)=lv(~Iv);
        else
            laux=lrn;
            lvaux=lrnv;
        end
        if elev>ele
            nodB=sort(lnodext(:,1));
%             celledgeW=celledge(ismember(nodB,lnodW(:,1)));
            if rr
                lnodextp=lnodextp(1:size(lnodextp,1)-size(lnodWp,1),:);
                
%                 numedgetot=0;
%                 for i=1:size(celledgeW,1)
%                     numedgetot=numedgetot+length(celledgeW{i});
%                 end
            end
            remp=~ismember(sort(lnodp,2),sort(lnod,2),'rows');
            remnod=unique([lnod(rem,1);lnod(rem,2);lnodp(remp,1);lnodp(remp,2)]);
            nodBp=sort(lnodextp(:,1));
            [Ib,locb]=ismember(nodB,nodBp);
            II=~ismember(nodB,remnod);
            for i=1:length(nodB)
                if Ib(i) && II(i)
                    lvaux(celledge{i})=1*sum(lrnv(celledgep{locb(i)}))/length(celledge{i});
                    Iv(celledge{i})=true;
%                 elseif ~isempty(woundedge)
%                     lvaux(celledge{i})=Wln*length(celledge{i})/numedgetot;
%                     Iv(celledge{i})=true;
                end
             end
        end
    end
    lambda1=max(abs(diag(A(1:ele,1:ele))))*pp;
    lambda2=max(abs(diag(A(ele+1:end,ele+1:end))))*pp;
    A(1:ele,1:ele)        =A(1:ele,1:ele)+lambda1*(diag(I)+ppl*diag(~I));
    A(ele+1:end,ele+1:end)=A(ele+1:end,ele+1:end)+lambda2*(diag(Iv)+ppl*diag(~Iv));
    if disp
        a=laux;
        av=lvaux;
    else
        a =1./laux;
        av=1./lvaux;
    end
    a(~I)  =ppl*a(~I);
    av(~Iv)=ppl*av(~Iv);
    b(1:ele)=b(1:ele)+lambda1*a;
    b(ele+1:end)=b(ele+1:end)+lambda2*av;
    if split
        Av1=A(1:ele,1:ele);
        Av2=A(ele+1:end,ele+1:end);
        b1=b(1:ele);
        b2=b(ele+1:end);
        Av1=sparse(Av1);
        v1=Av1\b1;
        Av2=sparse(Av2);
        v2=Av2\b2;
        v=[v1;v2];
    else
        v=A\b;
    end
    if disp
        L=v;
    else
        L=1./v;
    end
    L(L<0)=0.01*abs(L(L<0));  % modification of negative lesting lengths 
    Ld=L(1:ele);
    Lv=L(ele+1:end);
    rem=find(rem);
    II=ismember(sort(lnod(rem,:),2),sort(lnodW,2),'rows');
    Ld(rem(II))=l(rem(II))/(1+EcD);   % Setting the resting length of the nodal element at the wound edge respecting the target strain; 
else
    Ld=lrn;
    Lv=lrnv(1:elev);
end
ln.D.n.A.r=Ld;
ln.V.n.A.r(1:elev)=Lv;
%%only when A branch is used
ln.D.n.B.r=ln.D.n.A.r;
ln.V.n.B.r(1:elev)=ln.V.n.A.r(1:elev);
%% computing error of the mapping minimisation
% error=g;
% nn=ele+elev;
% for i=1:nn
%     if i<=ele
%         n=lnod(i,:);
%         e=(X(n(2),:)-X(n(1),:))/l(i);
%         if disp
%             t=k(i)*(l(i)-Ld(i))*e;
%         else
%             t=k(i)*(l(i)/Ld(i)-1)*e;
%         end
%         error(n(1),:)=error(n(1),:)+t;
%         error(n(2),:)=error(n(2),:)-t;
%     else
%         j=i-ele;
%         n=lnodv(j,:);
%         e=(V(n(2),:)-V(n(1),:))/lv(j);
%         if disp
%             t=kv(j)*(lv(j)-Lv(j))*e;
%         else
%             t=kv(j)*(lv(j)/Lv(j)-1)*e;
%         end
%         if n(1)<=nodVin
%         t1=N(n(1),:)'*t;
%         error(FE(n(1),:),:)=error(FE(n(1),:),:)+t1;
%         end
%         if n(2)<=nodVin
%         t2=N(n(2),:)'*t;
%         error(FE(n(2),:),:)=error(FE(n(2),:),:)-t2;
%         end
%     end
% end
% nodError=sqrt(sum(error.^2,2));
% error=reshape(error',nodes*dim,1);
nodError=zeros(size(X));
error=zeros(size(g));
% if  Set.Bcells<0    
% nodesExt=length(nodext);
%%%%%%%%%%%%%%%%% Method 1 %%%%%%%%%%%%%%%%%%%%
% A=zeros(nodesExt,nodesExt);
% b=zeros(nodesExt,1);
% aux=zeros(nodesExt,3);
% aux(1,:)=[lnodext(1,:) 1];
% s=1:nodesExt;
% for i=2:nodesExt
%     I= lnodext(:,1)==aux(i-1,2);
%     aux(i,:)=[aux(i-1,2) lnodext(I,2) s(I)];
% end
% Lv=ln.V.n.A.r;
% for i=1:nodesExt
%     if i>1
%         nod1i=lnod(ele-nodesExt+aux(i,3),1);
%     else
%         nod1i=lnod(ele-nodesExt+aux(nodesExt,3),1); 
%     end
%     nodi =lnod(ele-nodesExt+aux(i,3),2);
%     if i<nodesExt
%        nodi1=lnod(ele-nodesExt+aux(i+1,3),2);
%     else
%        nodi1=lnod(ele-nodesExt+aux(1,3),2);   
%     end
%     c1i=vor_cell{nod1i};
%     ci =vor_cell{nodi};
%     ci1=vor_cell{nodi1};
%     d1i=length(Dcell{nod1i});
%     di =length(Dcell{nodi});
%     di1=length(Dcell{nodi1});
%     l=V(c1i(end-1),:)-V(c1i(end),:);
%     e1i1i=l/norm(l);
%     l=V(ci(di+2),:)-V(ci(di+1),:);
%     e1ii=l/norm(l);
%     l=V(c1i(2),:)-V(c1i(1),:);
%     e1iT=l/norm(l);
%     L1i=Lv(ele-nodesExt+aux(i,3));
%     T1i=norm(l)/L1i-1;
%     l=V(ci(end-1),:)-V(ci(end),:);
%     eii=l/norm(l);
%     l=V(ci1(di1+2),:)-V(ci1(di1+1),:);
%     eii1=l/norm(l);
%     l=V(ci(2),:)-V(ci(1),:);
%     eiT=l/norm(l);
%     if i<nodesExt
%        Li=Lv(ele-nodesExt+aux(i+1,3));
%     else
%        Li=Lv(ele-nodesExt+aux(1,3));
%     end
%     Ti=norm(l)/Li-1;
%     if i>1
%         A(i,i-1)=e1i1i*e1ii';
%     else
%         A(i,end)=e1i1i*e1ii';
%     end
%     A(i,i)=2;
%     if i<nodesExt
%         A(i,i+1)=eii1*eii';
%     else
%         A(i,1)=eii1*eii';
%     end
%     b(i)=-T1i*(e1iT*e1ii')-Ti*(eiT*eii');
% end
% A=sparse(A);
% st=A\b;
% [~,b]=sort(aux(:,3));
% st=st(b);
%    Lv=zeros(size(lnodv,1)-elev,1);
% [a,b]=sort(lnod(ele-nodesExt+1:end,2));
% st=st(b);
% % st1=st;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%% Method 2 %%%%%%%%%%%%%%%%%%
%  [a,~]=sort(lnod(ele-nodesExt+1:end,2));
% st2=zeros(nodesExt,1);
% for i=1:nodesExt
%     st2(i)=(Vol(a(i))-Vol0(a(i)))*Set.Vp/kkv;
% end
% st=st2;
% st=Mat.V.EcA*ones(nodesExt,1);
% % st=(st2+st1)/2;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% st=st+1;
% c=1;
% for i=1:nodesExt
%     s=length(vor_cell{a(i)})-length(Dcell{a(i)})-1;
%     lv=sqrt(sum((V(lnodv(elev+c:elev+c+s-1,2),:)-V(lnodv(elev+c:elev+c+s-1,1),:)).^2,2));
%     Lv(c:c+s-1)=lv./st(i);
%     c=c+s;
% end
% ln.V.n.A.r(elev+1:end)=Lv;
% ln.V.n.B.r(elev+1:end)=Lv;
% end
end
