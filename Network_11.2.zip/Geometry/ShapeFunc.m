function [N,xi,Vor]=ShapeFunc(N,xi,dxi,dofxi,dim,nodes,x,Vor,lnodFE,Set)
dofxi=dofxi-nodes*dim;
if Set.Vrel
    vor =reshape(Vor',dim*size(Vor,1),1);
    vor(dofxi)=vor(dofxi)+dxi;
    Vor=reshape(vor,dim,length(vor)/dim)';
    X  =reshape(x,dim,nodes)';
    dofxiIN=dofxi(dofxi<2*size(lnodFE,1)+1);
    if ~isempty(dofxiIN)
    a  =reshape(sort(dofxiIN),dim,length(dofxiIN)/dim)';
    DL =a(:,end)/dim;
        for i=1:length(DL)
        %%obtaining vertices in local coordinates respected to triangles edges
        s=[X(lnodFE(DL(i),3),2)-X(lnodFE(DL(i),1),2) X(lnodFE(DL(i),1),2)-X(lnodFE(DL(i),2),2)
           X(lnodFE(DL(i),1),1)-X(lnodFE(DL(i),3),1) X(lnodFE(DL(i),2),1)-X(lnodFE(DL(i),1),1)];
        xi(2*DL(i)-1:2*DL(i))=((Vor(DL(i),:)-X(lnodFE(DL(i),1),1:2))*(s/det(s)))';
        end
    end
else
    xi(dofxi)=xi(dofxi)+dxi;
end
    XI=reshape(xi',dim,size(N,1))';
    for i=2:dim+1
        N(:,i)=XI(:,i-1);
    end
    N(:,1)=ones(size(N,1),1)-sum(XI,2);
end