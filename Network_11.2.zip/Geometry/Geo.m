function [cdof,dim,lnodFE,dof,vext,nodes,TL,X,lnodExternal,lnod_ext,nodAb,doc]=Geo(BC,Set)
% lnodExternal = list of external nodes on original domain (no offset even if Bcells=true)
% BC.Cvert : Constrain also vertical direction (y) on nodes with imposed
%         displacement
if Set.Network==0
    X=[0 0 0;1 0 0];
    cdof=4;            %constrain degree of freedom
    dof=[];            %degree of freedom
    lnodFE=[];
    dim=3;             %nodes dimension
    vext=[0 0 0 0 0 0];%neuman boundray condition
    nodes=2;           %number of the nodes
    lnodExternal=0;
elseif Set.Network>0 %2D network
    if Set.NetworkType==0
        nx=Set.Network; % Number of intervals along horizontal direction (number of columns)
        ny=Set.Network; % Number of intervals along vertical direction (number of rows)
        X=zeros((nx+1)*(ny+1),2);
        k=0;
        for i=0:nx
            for j=0:ny
                k=k+1;
                X(k,:)=[i j];
            end
        end
        %%% add a random value to internal X
        a= (X(:,1)~=nx & X(:,1)~=0) & (X(:,2)~=ny & X(:,2)~=0);
        r=rExperimental(nx,ny); % Read experimental values
        X(a,:)=X(a,:)+r;
    else
        X=CircularDistribution(Set.Network);
    end
    %%% Single cell geometry
    %     X=[0 0;0 1;0 -1;-sqrt(3)/2 1/2;-sqrt(3)/2 -1/2;sqrt(3)/2 1/2;sqrt(3)/2 -1/2];
    [X,lnodFE,lnodExternal,lnod_ext,~,~]=BoundaryFilter(X,[],[],[],0,Set,false,[],[]);
    [dof,cdof,doc,vext] = SetLeftRight(BC,lnodExternal,X,Set);
    nodes=size(X,1);
    dim=size(X,2);
else
    Set.NetworkType=0;
    X=RealCellsVoronoi(Set.ImageFile);
    [X,lnodFE,lnodExternal,lnod_ext,~,~]=BoundaryFilter(X,[],[],[],0,Set,false,[],[]); % Filter on Delaunay
    [dof,cdof,doc,vext] = SetLeftRight(BC,lnodExternal,X,Set);
    nodes=size(X,1);
    dim=size(X,2);
end
nodAb=[];
if Set.Network~=0 && Set.Ablation>0
    %[dof,~,vext,nodAb]=SetBoundary(cdof,dof,doc,lnodExternal,vext,X,Set);
    [doc,nodAb]=SetBoundary(doc,lnodExternal,X,Set);
end
TL=max(X(:,1))-min(X(:,1));
if Set.Xirel>0 && Set.Bcells<0 && Set.Vrel
        dof=zeros(0,1);
end
end
% Read set of experimental values
function r=rExperimental(nx,ny)
% 196 epxerimental nodal positions values which may be trimmed
r=[0.4074    0.2543
    0.4529    0.2554
    0.0635    0.4088
    0.4567    0.3974
    0.3162    0.3222
    0.0488    0.1893
    0.1392    0.4058
    0.2734    0.2664
    0.4788    0.1754
    0.4824    0.4695
    0.0788    0.4380
    0.4853    0.2751
    0.4786    0.3112
    0.2427    0.2935
    0.4001    0.1039
    0.0709    0.1506
    0.2109    0.2355
    0.4579    0.1152
    0.3961    0.4222
    0.4797    0.0974
    0.3279    0.1130
    0.0179    0.0854
    0.4246    0.1138
    0.4670    0.2178
    0.3394    0.1556
    0.3789    0.4617
    0.3716    0.2151
    0.1961    0.0924
    0.3277    0.4524
    0.0856    0.4899
    0.3530    0.2194
    0.0159    0.0556
    0.1385    0.1290
    0.0231    0.2044
    0.0486    0.2974
    0.4117    0.1311
    0.3474    0.3014
    0.1585    0.3556
    0.4751    0.1109
    0.0172    0.0587
    0.2194    0.1483
    0.1908    0.1594
    0.3828    0.2121
    0.3976    0.2539
    0.0934    0.0428
    0.2449    0.1312
    0.2228    0.4005
    0.3232    0.0146
    0.3547    0.4644
    0.3773    0.3652
    0.1380    0.2443
    0.3399    0.2893
    0.3275    0.1186
    0.0813    0.2294
    0.0595    0.4815
    0.2492    0.2734
    0.4799    0.2606
    0.1702    0.1158
    0.2926    0.2444
    0.1119    0.3120
    0.3756    0.3396
    0.1275    0.1978
    0.2530    0.1837
    0.3495    0.4940
    0.4455    0.0189
    0.4796    0.4426
    0.2736    0.4566
    0.0693    0.3981
    0.0746    0.0494
    0.1288    0.1309
    0.4204    0.1677
    0.1271    0.3399
    0.4071    0.0683
    0.1218    0.3606
    0.4646    0.0534
    0.1750    0.3269
    0.0983    0.2471
    0.1255    0.3895
    0.3080    0.3575
    0.2366    0.4519
    0.1758    0.4455
    0.4154    0.1671
    0.2926    0.3494
    0.2749    0.0989
    0.4586    0.0153
    0.1429    0.3720
    0.3786    0.2500
    0.3769    0.2400
    0.1902    0.4524
    0.2839    0.3049
    0.0379    0.3088
    0.0270    0.4297
    0.2654    0.4027
    0.3896    0.2884
    0.4670    0.0915
    0.0650    0.1200
    0.2844    0.4433
    0.2347    0.0143
    0.0060    0.2450
    0.1686    0.0840
    0.0811    0.4893
    0.3971    0.3563
    0.1556    0.2502
    0.2643    0.2355
    0.0828    0.0298
    0.3010    0.3410
    0.1315    0.0212
    0.3270    0.0357
    0.3446    0.2608
    0.3741    0.0484
    0.2253    0.4091
    0.0419    0.4088
    0.1145    0.3612
    0.4567    0.0749
    0.0762    0.3298
    0.4129    0.2593
    0.2692    0.4865
    0.4981    0.3245
    0.0391    0.4002
    0.2213    0.2269
    0.0533    0.2162
    0.4809    0.4127
    0.0023    0.0417
    0.3875    0.0666
    0.4087    0.0867
    0.4343    0.1955
    0.0422    0.4157
    0.1999    0.4017
    0.1299    0.0302
    0.4000    0.1996
    0.2157    0.2634
    0.4553    0.2084
    0.0909    0.3284
    0.1319    0.3140
    0.0728    0.1460
    0.0680    0.2158
    0.4346    0.0077
    0.2899    0.4920
    0.2749    0.0836
    0.0725    0.0531
    0.4265    0.1862
    0.3110    0.0991
    0.1755    0.2448
    0.2566    0.1697
    0.2009    0.4758
    0.0380    0.4602
    0.1200    0.0263
    0.0617    0.3689
    0.0920    0.1346
    0.1200    0.2114
    0.2086    0.2739
    0.0248    0.4714
    0.4514    0.2089
    0.4724    0.4915
    0.2454    0.1507
    0.2446    0.3505
    0.1689    0.3332
    0.4500    0.2696
    0.1846    0.3491
    0.0556    0.3333
    0.3901    0.0891
    0.1949    0.0640
    0.1208    0.4995
    0.2020    0.0856
    0.0482    0.0163
    0.0660    0.2806
    0.4710    0.4409
    0.4781    0.3346
    0.2876    0.0952
    0.0299    0.1845
    0.1174    0.2304
    0.1766    0.4908
    0.4106    0.0782
    0.0077    0.4278
    0.0215    0.3224
    0.0845    0.1881
    0.3246    0.0955
    0.3659    0.2141
    0.3239    0.2410
    0.2255    0.0603
    0.2735    0.2948
    0.1482    0.1131
    0.3723    0.1923
    0.0945    0.2915
    0.3434    0.1259
    0.0918    0.1452
    0.1842    0.3085
    0.3128    0.1326
    0.3901    0.4122
    0.0406    0.4913
    0.4647    0.3651
    0.3879    0.1719
    0.2434    0.2920
    0.2179    0.0539
    0.2234    0.4532
    0.1532    0.4398];
% Adapt to size
r=r(1:(nx-1)*(ny-1),:);
end