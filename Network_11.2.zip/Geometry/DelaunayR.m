function [T,iter] = DelaunayR( X,T,delta)
%% DELAUNAYR : Regulated Dalunay
% Computes Delaunay triangulation from previous coordinates X and
% connectivity T.
% Minimal usage:
%  T=DelaunayR(X)
% INPUT
% X=nodal coordinates. X(in,:)=[x y z] coord of node in.
% T=initial connectivity from which aspect ratios improved. 
%   If not present, uses Matlab delaunay connectivity.
% function.
% delta= Relative improvement in aspect ratio when building Delaunay. 
%       delta=0, Standard Delaunay. 
%       delta>0, Aspects ratios >= (delta+1)*AspectRatioDelaunay are allowed
% OUTPUT
% T = resulting connectivity
% iter = number of iterations (loops on all mesh for improving flips in connecticity)
%
% Generate list of sides
if ~exist('T','var')
    T=delaunay(X);
end
if ~exist('delta','var')
    delta=0;
end
nelem=size(T,1);
ns=size(T,2); % Number of sides (faces). 2D=3, 3D=4
dim=size(X,2);
ne=3*(dim-1); % Number of segments in 3D=6
Sides=zeros(nelem,ns); % Neighbouring element per side
SidesElem=zeros(nelem,ns); % Side number per element. Numebering: 1:nInternal 1:External
SidesInt=zeros(nelem*ns,4); % List of Internal Sides. [elem1 elem2 side1 side2]
SidesExt=zeros(nelem*ns,4); % List of external sides. [elem1 0     side1 0    ]
SidesL=zeros(nelem,ne); % List of length per segment
if dim==2
    S=[ 2 3
        3 1
        1 2];
    sx=[ 1 2 3 1 2]; % extended indexing of sides
else
    S=[1 2
        2 3
        3 1
        1 4
        2 4
        3 4];
    sx=[ 1 2 3 4 1 2 3]; % extended indexing of sides
end
% Build list of sides / elem
for e=1:nelem
    for s=1:ne
        SidesL(e,s)=norm(X(T(e,S(s,1)),:)-X(T(e,S(s,2)),:));
    end
end
% Build list of connected sides
Is=0; % internal
Es=0; % external
for e=1:nelem
    for s=1:ns
        nfound=Sides(e,s)==0;
        f=1;
        while nfound && f<=nelem
            if f==e
                f=f+1;
                continue;
            end
            for t=1:ns % Loop on adjacent element
                if max(abs(sort(T(e,sx(s+1:s+dim)))-sort(T(f,sx(t+1:t+dim)))))==0
                    Sides(e,s)=f;
                    Sides(f,t)=e;
                    Is=Is+1;
                    SidesInt(Is,:)=[e f s t];
                    SidesElem(e,s)=Is;
                    SidesElem(f,t)=Is;
                    nfound=false;
                    break;
                end
            end
            f=f+1;
        end
        if nfound % Mark as external
            Es=Es+1;
            SidesExt(Es,1:3)=[e 0 s];
            SidesElem(e,s)=-Es;
        end
    end
end
SidesIntExt=[SidesInt(1:Is,:)
    SidesExt(1:Es,:)];
SidesElem(SidesElem<0)=-SidesElem(SidesElem<0)+Is; % Add external at the end
% Loops on whole mesh
nchanges=1;
iter=0;
T0=T;
while nchanges
    iter=iter+1;
    nchanges=false;
    for e=1:nelem
        for s=1:ns
            f=Sides(e,s);
            if f>0 % Not external
                % Check whether flip is favourable
                ks=SidesElem(e,s);
                if SidesIntExt(ks,1)==e % Not in 3D
                    se=SidesIntExt(ks,3); % =s
                    sf=SidesIntExt(ks,4);
                else
                    se=SidesIntExt(ks,4);
                    sf=SidesIntExt(ks,3); % =se
                end
                l1=SidesL(e,:); % Original triangles. Elem e
                l2=SidesL(f,:); % Original triangles. Elem f
                LN=norm(X(T(e,se),:)-X(T(f,sf),:)); % New length at crossing line
                L1=[SidesL(e,sx(se+1)) LN SidesL(f,sx(sf+2))]; % Flipped triangles (Not in 3D)
                L2=[SidesL(e,sx(se+2)) SidesL(f,sx(sf+1)) LN];
                T1=[T(e,sx(se+2)) T(e,se) T(f,sf)];
                T2=[T(e,sx(se+1)) T(f,sf) T(e,se)];
                w1=AspectRatioL(l1); % AspectRatioP(X(T(e,:),:)); %max(l1)/min(l1);
                w2=AspectRatioL(l2); % AspectRatioP(X(T(f,:),:)); %max(l2)/min(l2);
                W1=AspectRatioL(L1); % AspectRatioP(X(T(T1,:),:));
                W2=AspectRatioL(L2); % AspectRatioP(X(T(T2,:),:));
                if max(w1,w2)>max(W1,W2)*(1+delta) && Convex([T1(1:2) T2(1:2)], X) % FLIP ACCORDING TO AVOID MAXIMUM ASPECT RATIO (MODIFY IF NECESSARY)
                    T(e,:)=T1;
                    T(f,:)=T2;
                    % Update side lengths
                    auxe=SidesL(e,:);
                    SidesL(e,:)=[LN SidesL(f,sx(sf+2)) SidesL(e,sx(se+1))];
                    SidesL(f,:)=[LN auxe(1,sx(se+2))   SidesL(f,sx(sf+1))];
                    fi=Sides(e,sx(se+1));
                    if fi>0, SidesL(fi,Sides(fi,:)==e)=SidesL(e,3);end
                    fi=Sides(e,sx(se+2));
                    if fi>0, SidesL(fi,Sides(fi,:)==e)=SidesL(f,2);end
                    fi=Sides(f,sx(sf+1));
                    if fi>0, SidesL(fi,Sides(fi,:)==f)=SidesL(f,3);end
                    fi=Sides(f,sx(sf+2));
                    if fi>0, SidesL(fi,Sides(fi,:)==f)=SidesL(e,2);end
                    % Update List of sides
                    si=SidesElem(e,se);
                    SidesIntExt(si,:)=[e f 1 1];
                    si=SidesElem(e,sx(se+1));
                    fi=Sides(e,sx(se+1));
                    SidesIntExt(si,:)=[e fi 3 GetSideNum(e,fi,SidesIntExt(si,:))];
                    si=SidesElem(f,sx(sf+2));
                    fi=Sides(f,sx(sf+2));
                    SidesIntExt(si,:)=[e fi 2 GetSideNum(f,fi,SidesIntExt(si,:))];
                    si=SidesElem(e,sx(se+2));
                    fi=Sides(e,sx(se+2));
                    SidesIntExt(si,:)=[f fi 2 GetSideNum(e,fi,SidesIntExt(si,:))];
                    si=SidesElem(f,sx(sf+1));
                    fi=Sides(f,sx(sf+1));
                    SidesIntExt(si,:)=[f fi 3 GetSideNum(f,fi,SidesIntExt(si,:))];
                    auxe=SidesElem(e,:); % Update SidesElem (adjacent elements)
                    SidesElem(e,:)=[SidesElem(e,se) SidesElem(f,sx(sf+2)) SidesElem(e,sx(se+1))];
                    SidesElem(f,:)=[auxe(1,se)      auxe(1,sx(se+2))      SidesElem(f,sx(sf+1))];
                    Sides(e,:)=GetElemNum(e,SidesIntExt(SidesElem(e,:),1:2)); % Get adjacent elements
                    Sides(f,:)=GetElemNum(f,SidesIntExt(SidesElem(f,:),1:2));
                    fi=Sides(e,2);
                    if fi>0, Sides(fi,Sides(fi,:)==f)=e;end
                    fi=Sides(e,3);
                    if fi>0,Sides(fi,Sides(fi,:)==e)=e;end
                    fi=Sides(f,2);
                    if fi>0,Sides(fi,Sides(fi,:)==e)=f;end
                    fi=Sides(f,3);
                    if fi>0,Sides(fi,Sides(fi,:)==f)=f;end
                    nchanges=nchanges+1;
                end
            end
        end
    end
end
end
%%
function w=AspectRatioL(l)
%%
% l= vector of lengths
% w=aspect ratio as circumradius/inradius
dim=length(l)-1;
if dim==2
    w=0.5*(l(1)+l(2)-l(3))*(l(1)+l(3)-l(2))*(l(3)+l(2)-l(1))/l(1)/l(2)/l(3);
end
w=1/w;
end
%%
function w=AspectRatioP(Xe)
%%
% l= vector of lengths
% w=aspect ratio as Perimeter/Area (in 3D, Area/Volume)
dim=size(Xe,2);
if dim==2
    y12=norm(Xe(2,:)-Xe(1,:));
    y13=norm(Xe(3,:)-Xe(1,:));
    y23=norm(Xe(3,:)-Xe(2,:));
else
    y12=Xe(3);
    y13=Xe(2);
    y23=Xe(1);
end
P=y12+y13+y23;
%     Area=norm(cross(y12,y13))/2;
Area=sqrt(P*(P/2-y12)*(P/2-y13)*(P/2-y23)/2);
w=P^2/Area;
end
%%
function f=GetElemNum(e,SidesElem)
% GetSide number of adjacent element f.
ns=size(SidesElem,1);
f=zeros(ns,1);
for i=1:ns
    if e==SidesElem(i,1)
        f(i)=SidesElem(i,2);
    elseif e==SidesElem(i,2)
        f(i)=SidesElem(i,1);
    else
        error('Adjacent element %i not found in list %i %i',e,SidesElem(i,:));
    end
end
end
%%
function s=GetSideNum(e,f,SidesIntExt)
% GetSide number of adjacent element f.
if e==SidesIntExt(1) && f==SidesIntExt(2)
    s=SidesIntExt(4);
elseif e==SidesIntExt(2) && f==SidesIntExt(1)
    s=SidesIntExt(3);
else
    error('Adjacent elements %i and %i  not found in %i %i %i %i',e,f,SidesIntExt);
end
end
%% 
function I=Convex(T,X)
% Check if set of points in T form a convex polytope
n=length(T);
T(end+1:end+2)=[T(1) T(2)]; % Force connected loop
I=true;
for i=1:n
    x1=X(T(i),:);
    x2=X(T(i+1),:);
    x3=X(T(i+2),:);
    x12=[x2-x1 0];
    x23=[x3-x2 0];
    v=cross(x12,x23);
    if v(3)<0
        I=false;
        break;
    end
end
end
