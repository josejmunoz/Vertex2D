function [nodesV,ln,lnod,lnodFE,lnod_vor,Lumen,N,stress,Vor,Vor0,Vorp,vor_cell,xi,xip]=SplitVertex(ln,lnod,lnodFE,lnod_vor,Lumen,N,stress,Vor,Vor0,Vorp,vor_cell,xi,xip)
nodesV=size(Vor,1);
dim=size(Vor,2);
for w=1:length(Lumen)
    if length(Lumen{1}.lnod0)>0
        Lumen{1}.lnod=Lumen{1}.lnod0;
        break;
    end
    for i=1:length(Lumen{w}.V)
        if Lumen{w}.V(i)==0
            break;
        end
        % Create 2 new vertices, same coordintes as Lumen{w}.V
        V1=Lumen{w}.V;
        V2=nodesV+1;
        V3=nodesV+2;
        nodesV=nodesV+2;
        Vor=[Vor
            Vor(V1,:)
            Vor(V1,:)];
        Vor0=[Vor0
            Vor0(V1,:)
            Vor0(V1,:)];
        Vorp=[Vorp
            Vorp(V1,:)
            Vorp(V1,:)];
        % Update shape functions
        N=[N
            N(V1,:)
            N(V1,:)];
        xi=[xi
            xi((V1-1)*dim+1:V1*dim)
            xi((V1-1)*dim+1:V1*dim)];
        xip=[xip
            xip((V1-1)*dim+1:V1*dim)
            xip((V1-1)*dim+1:V1*dim)];
        lnodFE=[lnodFE
            lnodFE(V1,:)
            lnodFE(V1,:)];
        % Search bar elements connected to this vertex
        I1=find(lnod_vor(:,1)-V1==0);
        I2=find(lnod_vor(:,2)-V1==0);
        lnod_vor(I2,:)=lnod_vor(I2,2:-1:1); % Always vertex at first node
        lnodN=[lnod_vor(I1,:)
            lnod_vor(I2,:)];
        I=[I1;I2];
        v=Vor(lnodN(:,2),:); % Second nodes forming triangle
        % Make sure is in clockwise direction
        vT=cross([v(2,:)-v(1,:) 0],[v(3,:)-v(2,:) 0]);
        if vT(3)>0
            lnodN=[lnodN(:,1)
                lnodN(:,3)
                lnodN(:,2)];
            v=[v(1,:)
                v(3,:)
                v(2,:)];
            I=[I(1) I(3) I(2)];
        end
        % Crete 6 new bar elements
        v123=lnodN(:,2);
        lnod_vor(I(3),1)=V2;
        lnod_vor=[lnod_vor
            v123(2) V2
            % V2 v123(3) % This is the previous existing element
            v123(3) V3
            V3 v123(1)];
        % Update vor_cell (list of vertices)
        nc=0;
        In=zeros(1,3);
        for c=1:length(vor_cell)
            lnodc=vor_cell{c};
            for vi=1:length(lnodc)
                if vor_cell{c}(vi)==V1
                    nc=nc+1;
                    In(nc)=c;
                    if min(abs(v123(2)-lnodc))==0 && min(abs(v123(3)-lnodc))==0 
                        vor_cell{c}(vi)=V2;
                    elseif min(abs(v123(3)-lnodc))==0 && min(abs(v123(1)-lnodc))==0 
                        vor_cell{c}(vi)=V3;
                    end
                    if nc==3
                        break;
                    end
                end
            end
            if nc==3
                break;
            end
        end
        % Build hexagon of bars in Lumen
        Lumen{w}.lnod=[v123(1) V1
        V1 v123(2)
        v123(2) V2
        V2 v123(3) 
        v123(3) V3
        V3 v123(1)];
        % Remove nodal elements in lnod surrounding vertex V
        IN1=find((lnod(:,1)==In(1) & lnod(:,2)==In(2)) | ...
                 (lnod(:,1)==In(2) & lnod(:,2)==In(1)));
        IN2=find((lnod(:,1)==In(1) & lnod(:,2)==In(3)) | ...
                 (lnod(:,1)==In(3) & lnod(:,2)==In(1)));
        IN3=find((lnod(:,1)==In(3) & lnod(:,2)==In(2)) | ...
                 (lnod(:,1)==In(2) & lnod(:,2)==In(3)));
        In=1:size(lnod,1);
        lnod([IN1 IN2 IN3],:)=[];
        In([IN1 IN2 IN3])=[];
        % Update rest length
        I=[1:length(ln.V.n1.S.e) I(2) I(3) I(1)];
        ln.V.n1=CopyLn(ln.V.n1,I);
        ln.V.n=CopyLn(ln.V.n,I);
        ln.D.n1=CopyLn(ln.D.n1,In);
        ln.D.n=CopyLn(ln.D.n,In);
        % Update stress
        I=[1:length(stress.V.n1.T) I(2) I(3) I(1)];
        stress.V.n1=CopyStress(stress.V.n1,I);
        stress.D.n1=CopyStress(stress.D.n1,In);
    end
end
end
%%-------------------------------------------------------------------------
function stressB=CopyStress(stressA,I)
% Copies stress data on Spring branch, branch A and B into stressA:  lA=lB
stressB.T=stressA.T(I);
stressB.A=stressA.A(I);
stressB.B=stressA.B(I);
stressB.S=stressA.S(I);
end
%%-------------------------------------------------------------------------
function lA=CopyLn(lB,I)
% Copies rest length data lB into lA:  lA=lB
% Adds 4 new elements coitained in I(2), I(3), I(1) forming the star
lA.S.e=lB.S.e(I);
lA.A.e=lB.A.e(I);
lA.B.e=lB.B.e(I);
lA.A.r=lB.A.r(I);
lA.B.r=lB.B.r(I);
lA.S.c=lB.S.c(I);
lA.A.c=lB.A.c(I);
lA.B.c=lB.B.c(I);
end

