function [X,lnodExternal,lnodFE,lron,nodes,nodesI,nodes0]=UpdatelnodFE(Xin,lnodExternal,lnodFE,nodes,Set)
% Builds lnodFE. Adds offset and updates londExternal if Bcells=true
% INPUT
% nodes = total number of nodes (internal and external)
% lnodExternal = list of external nodes from which offset is built if Bcells=true
% OUTPUT
% nodesI = number of internal nodes
% nodes0 = number of nodes in original Delaunay (without offset)
% lnodFE = Delaunauy trinagulation for the whole set of nodes (off-set and non-offet)
%
if Set.Bcells==1 % Create off-set
    nodes0=size(Xin,1);
    nodesI=nodes0;    
    [X,X_off]=AddOffset(Xin,lnodExternal);
    nodes=size(X,1);
else
    nodes0=nodes;
    if Set.Bcells==-1
        nodesI=nodes0;
    else
        nodesI=nodes-size(lnodExternal,1); % Not in 3D
    end
    X=Xin;
    lron=[];
end
if Set.Bcells==1 %Filter Offset
    lnodFE=delaunay(X(:,1),X(:,2)); %% triangulation on the whole set of the nodes (original + off-set)
    if size(X,2)==2 % 2D
        neleOff=find(lnodFE(:,1)>nodesI & ...
            lnodFE(:,2)>nodesI & ...
            lnodFE(:,3)>nodesI);
        for i=1:size(neleOff,1)
            if ismember([lnodFE(neleOff(i),1) lnodFE(neleOff(i),2)],lnodExternal,'rows') || ismember([lnodFE(neleOff(i),2) lnodFE(neleOff(i),3)],lnodExternal,'rows') || ismember([lnodFE(neleOff(i),3) lnodFE(neleOff(i),1)],lnodExternal,'rows')
                neleOff(i)=0;
            end
        end
        neleOff(neleOff<eps)=[];
    else % 3D
        neleOff=find(lnodFE(:,1)>nodesI & ...
            lnodFE(:,2)>nodesI & ...
            lnodFE(:,3)>nodesI & ...
            lnodFE(:,4)>nodesI);
    end
    
    lnodOff=lnodFE(neleOff,:);
    lnodFE(neleOff,:)=[]; %% cancelling triangulation on pure set of off-set nodes
    % Remove unused hanging offset nodes
    p=1:size(X,1);
    j=0;
    XRem=zeros(size(X,1),1);
    for e=1:size(neleOff,1)
        for i=1:size(lnodFE,2)
            if isempty(find(lnodOff(e,i)==lnodFE,1))
                if p(lnodOff(e,i))>0
                    p(lnodOff(e,i))=0;
                    j=j+1;
                    XRem(j)=lnodOff(e,i);
                end
            end
        end
    end
    if j>0
        X(XRem(1:j),:)=[];
        j=0;
        for i=1:length(p)
            if p(i)>0
                j=j+1;
                p(i)=j;
            end
        end
        lnodFE=p(lnodFE); % Use new numeration in offset nodes
    end
    % Rebuild connectivity
    j=1;
    k=1;
    lnodFE_total_aux=zeros(size(lnodFE,1),3);
    for i=1:size(lnodFE,1)
        if lnodFE(i,1)>nodesI || lnodFE(i,2)>nodesI || lnodFE(i,3)>nodesI
            lnodFE_total_aux(end-j+1,:)=lnodFE(i,:);
            j=j+1;
        else
            lnodFE_total_aux(k,:)=lnodFE(i,:);  %%making elements(connectivities) of original nodes
            k=k+1;
        end
    end
    lnodFE_off=lnodFE_total_aux(k:end,:);  %% Delaunay triangulation of off-set nodes
    lnod_off=zeros(3*size(lnodFE_off,1),2);
    for i=1:size(lnodFE_off,1)
        lnod_off(3*i-2:3*i,:)=nchoosek(lnodFE_off(i,:),2);
        lnod_off(3*i-1,[1 2])=lnod_off(3*i-1,[2 1]);  %% Keeping lnod_off expression counter-clockwise
    end
    lnod_off(lnod_off(:,1)<=nodesI & lnod_off(:,2)<=nodesI,:)=[];  %% cancelling original boundary elements from set of off-set elements (connectivities)
    [~,I]=unique(sort(lnod_off,2),'rows');
    lnod_off=lnod_off(I,:);
    % Rebuild lnodExternal
    lnodExternal=zeros(size(lnod_off,1),2);
    k=0;
    for i=1:size(lnod_off,1)
        in=lnod_off(i,:)>nodesI;
        if min(in)>0
            k=k+1;
            lnodExternal(k,:)=lnod_off(i,:);
        end
    end
    lnodExternal(k+1:end,:)=[];
    %lnodExternal=sort(lnodExternal,2);
    % Reference length for offset elements
    lron=zeros(size(lnod_off,1),1);
    for i=1:length(lron)
        lron(i)=norm(X(lnod_off(i,1),:)-X(lnod_off(i,2),:));
    end
    nodes=size(X,1);
end
end