function PlotDelaunayDelta
Warea_delta=false;
Rigidity_delta=false;
Warea_eps=false;
Rigidity_eps=false;
Warea_epsw=false;
Rigidity_epsw=false;
Ener_delta_epsw=true;
CndKappaDValue=false;
Ener_delta_eps=false;
Ener_delta_epsD=false;
Dev_delta_epsw=false;
Ener_delta_Vp=false;
close all;
cd('ResultsYanlan');
if Warea_delta    
    flist=dir('D15_*');
    nfile=size(flist,1);
    L=cell(nfile,1);
    Dval=cell(nfile,1);
    a=11;
    % Arate=zeros(nfile,1);
    ctime=zeros(nfile,1);
    for i=1:nfile
        cd(flist(i).name);
        load('tout');
        tout(1)=[];
        load('Ab');
        Ab.Vw=Ab.Vw(Ab.Vw>eps);
        tout=tout(Ab.Vw>eps);
        ctime(i)=tout(end)-tout(Ab.Vw==max(Ab.Vw));
        % Arate(i)=(max(Ab.Vw)-Ab.Vw(end))/(tout(end)-tout(Ab.Vw==max(Ab.Vw)));
        plot(tout(a:end),Ab.Vw(a:end),'-o','LineWidth',1,'MarkerSize',2);
        hold on
        Dval{i}=flist(i).name(5:7);
        L{i}=strcat('\delta','=',Dval{i});
        cd ..
    end
    xlabel('\bf{time-step}','FontSize',12);
    ylabel('\bf{Wound Area}','FontSize',12);
    h=legend(L{:},'Location','Northeast');
    set(h,'FontSize',10);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    title('Wound Area Evolution-\delta');
    print('WoundArea-delta','-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Rigidity_delta
    flist=dir('D15_*');
    nfile=size(flist,1);
    nremsum=zeros(nfile,1);
    for i=1:nfile
        cd(flist(i).name);
        load('nrem');
        nremsum(i)=sum(numrem);
        cd ..
    end
    % load('tout');
    figure
    a=plot(1:nfile,nremsum,'b--o','LineWidth',2,'MarkerSize',4);
    % L{i}=strcat('\delta','=',flist(i).name(4:6));
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{number of remodellings}','FontSize',12);
    %h=legend(L{:},'Location','Northeast');
    %set(h,'FontSize',10);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    ax1=gca;
    set(ax1,'YColor','b');
    ax2=axes('Position',ax1.Position,'YAxisLocation','right','Color','none'...
        ,'YColor','r','XTick',[],'XTickLabel',[]);
    hold on
    b=plot(1:nfile,ctime,'r-^','LineWidth',2,'MarkerSize',4);
    ylabel('\bf{closure time}','FontSize',12);
    h=legend([a;b],{'total number of remodellings','closure time'},'Location','NorthEast');
    title('Rigidity-\delta');
    print('Rigidity-delta','-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Warea_eps
    flist=dir('E15_*');
    nfile=size(flist,1);
    L=cell(nfile,1);
    Eval=cell(nfile,1);
    a=11;
    figure
    for i=1:nfile
        cd(flist(i).name);
        load('tout');
        load('Ab');
        tout=tout(a+1:end);
        Ab.Vw=Ab.Vw(a:end);
        plot(tout(Ab.Vw>0.6),Ab.Vw(Ab.Vw>0.6),'-o','LineWidth',1,'MarkerSize',2);
        hold on
        Eval{i}=flist(i).name(9:11);
        L{i}=strcat('\epsilon^c','=',Eval{i});
        cd ..
    end
    xlabel('\bf{time-step}','FontSize',12);
    ylabel('\bf{Wound Area}','FontSize',12);
    h=legend(L{:},'Location','Northeast');
    set(h,'FontSize',10);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    title('Wound Area Evolution-\epsilon^c');
    print('WoundArea-eps','-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Rigidity_eps
    flist=dir('E15_*');
    nfile=size(flist,1);
    nremsum=zeros(nfile,1);
    for i=1:nfile
        cd(flist(i).name);
        load('nrem');
        nremsum(i)=sum(numrem(Ab.Vw>0.6));
        cd ..
    end
    % load('tout');
    figure
    plot(1:nfile,nremsum,'-o','LineWidth',2,'MarkerSize',4);
    % L{i}=strcat('\delta','=',flist(i).name(4:6));
    xlabel('\bf{\epsilon^c}','FontSize',12);
    ylabel('\bf{number of remodellings}','FontSize',12);
    %h=legend(L{:},'Location','Northeast');
    %set(h,'FontSize',10);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    set(gca,'XTickLabel',Eval);
    set(gca,'XTick',1:size(Eval,1));
    title('Rigidity-\epsilon^c');
    print('Rigidity-eps','-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Warea_epsw
    flist=dir('Ew15_*');
    nfile=size(flist,1);
    L=cell(nfile,1);
    Ewval=cell(nfile,1);
    a=11;
    figure
    for i=1:nfile
        cd(flist(i).name);
        load('tout');
        load('Ab');
        tout=tout(a+1:end);
        Ab.Vw=Ab.Vw(a:end);
        plot(tout(Ab.Vw>0.6),Ab.Vw(Ab.Vw>0.6),'-o','LineWidth',1,'MarkerSize',2);
        hold on
        Ewval{i}=flist(i).name(14:16);
        L{i}=strcat('\epsilon^c_w','=',Ewval{i},'\epsilon^c');
        cd ..
    end
    xlabel('\bf{time-step}','FontSize',12);
    ylabel('\bf{Wound Area}','FontSize',12);
    h=legend(L{:},'Location','Northeast');
    set(h,'FontSize',10);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    title('Wound Area Evolution-\epsilon^c_w');
    print('WoundArea-epsw','-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Rigidity_epsw
    flist=dir('Ew15_*');
    nfile=size(flist,1);
    nremsum=zeros(nfile,1);
    for i=1:nfile
        cd(flist(i).name);
        load('nrem');
        nremsum(i)=sum(numrem(Ab.Vw>0.6));
        cd ..
    end
    % load('tout');
    figure
    plot(1:nfile,nremsum,'-o','LineWidth',2,'MarkerSize',4);
    % L{i}=strcat('\delta','=',flist(i).name(4:6));
    xlabel('\bf{\epsilon^c_w}','FontSize',12);
    ylabel('\bf{number of remodellings}','FontSize',12);
    %h=legend(L{:},'Location','Northeast');
    %set(h,'FontSize',10);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    set(gca,'XTickLabel',strcat(Ewval,'\epsilon^c'));
    set(gca,'XTick',1:size(Ewval,1));
    title('Rigidity-\epsilon^c_w');
    print('Rigidity-epsw','-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Ener_delta_epsw
    figure;
    %flist=dir('En15_*');
    flist1=dir('En15*3.5_0.1');
    flist2=dir('En15_0.1*_0.1');
    p=size(flist1,1);
    q=size(flist2,1);
    %nfile=p*q;
    Dval=zeros(p,1);
    Eval=zeros(q,1);
    enval=zeros(q,p);
    % arateval=enval;
    ctime=enval;
    Nrem=enval;
    for i=1:p
        Dval(i)=str2num(flist1(i).name(6:8));
    end
    for i=1:q
        Eval(i)=str2num(flist2(i).name(14:16));
    end
    for i=1:p
        for j=1:q
            cd(strcat('En15_',num2str(Dval(i),'%2.1f'),'_0.7_',num2str(Eval(j),'%2.1f'),'_0.1'));
            load('Mat');
            load('ener');
            load('Ab');
            load('tout');
            load('nrem');
            t1=find(Ab.Vw==max(Ab.Vw));
            Ab.Vw(1:t1-1)=[];
            tout(1:t1-1)=[];
            ener(1:t1-1,:)=[];
            numrem(1:t1-1)=[];
            %    Abaux=Ab.Vw(Ab.Vw>eps);
             %    Abmat(j,i)=Abaux(end);
                 en=sum(ener(Ab.Vw>1,1:2),2);
            %     en=ener(Ab.Vw>1,5);
            %     en=ener(Ab.Vw>1,2);
            %    en=ener(Ab.Vw>1,1);
            %     en=ener(Ab.Vw>1,3);
            toutaux=tout(Ab.Vw>1);
            ctime(end-j+1,i)=toutaux(end)-toutaux(1);
            enval(end-j+1,i)=sum(en(2:end).*diff(toutaux))/ctime(end-j+1,i);
            Ab.Vw=Ab.Vw(Ab.Vw>eps);
            %     arateval(j,i)=(max(Ab.Vw)-Ab.Vw(end))/(tout(end)-tout(Ab.Vw==max(Ab.Vw)));
            Nrem(end-j+1,i)=sum(numrem);
            cd ..
        end
    end
    imagesc(enval);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_w}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1)),'\epsilon^c'));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
        1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(enval(:),'%4.3f')));
    title(strcat('Total work contour / time, \kappa_D=',num2str(Mat.D.kappaA)));
    print(strcat('Total_work_contour_per_t_KD=',num2str(Mat.D.kappaA)),'-dpdf');
    figure;
    imagesc(ctime);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_w}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1)),'\epsilon^c'));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % set(h,'YDir','reverse');
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
        1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(ctime(:),'%3.2f')));
    title(strcat('closure time contour, \kappa_D=',num2str(Mat.D.kappaA)));
    print(strcat('closure_time_contour_KD=',num2str(Mat.D.kappaA)),'-dpdf');
    %%%%%%%%%%%%%%%
    figure;
    imagesc(Nrem);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_w}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1)),'\epsilon^c'));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % set(h,'YDir','reverse');
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
          1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(Nrem(:))));
    title(strcat('Number of remodellings contour, \kappa_D=',num2str(Mat.D.kappaA)));
    print(strcat('number_of_remodellings_KD=',num2str(Mat.D.kappaA)),'-dpdf');
    %%%%%%%%%%%%%%%%%
    if CndKappaDValue
        figure;
        %flist=dir('En15_*');
        flist1=dir('En415*3.5');
        flist2=dir('En415_0.1*');
        p=size(flist1,1);
        q=size(flist2,1);
        %nfile=p*q;
        Dval=zeros(p,1);
        Eval=zeros(q,1);
        enval=zeros(q,p);
        % arateval=enval;
        ctime=enval;
        Nrem=enval;
        for i=1:p
            Dval(i)=str2num(flist1(i).name(7:9));
        end
        for i=1:q
            Eval(i)=str2num(flist2(i).name(15:17));
        end
        for i=1:p
            for j=1:q
                cd(strcat('En415_',num2str(Dval(i),'%2.1f'),'_0.7_',num2str(Eval(j),'%2.1f')));
                load('ener');
                load('Ab');
                load('tout');
                load('nrem');
                %    Abaux=Ab.Vw(Ab.Vw>eps);
                %    Abmat(j,i)=Abaux(end);
                %    en=sum(ener(Ab.Vw>1,1:2),2);
                %     en=ener(Ab.Vw>1,5);
                     en=ener(Ab.Vw>1,2);
                %     en=ener(Ab.Vw>1,1);
                %     en=ener(Ab.Vw>1,3);
                enval(end-j+1,i)=sum(en(2:end).*diff(tout(Ab.Vw>1)));
                Ab.Vw=Ab.Vw(Ab.Vw>eps);
                tout=tout(Ab.Vw>eps);
                %     arateval(j,i)=(max(Ab.Vw)-Ab.Vw(end))/(tout(end)-tout(Ab.Vw==max(Ab.Vw)));
                ctime(end-j+1,i)=tout(end)-tout(Ab.Vw==max(Ab.Vw));
                Nrem(end-j+1,i)=sum(numrem);
                cd ..
            end
        end
        imagesc(enval);
        %surfc(enval);
        xlabel('\bf{\delta}','FontSize',12);
        ylabel('\bf{\epsilon^c_w}','FontSize',12);
        set(gcf,'units','inches');
        set(gcf,'Position',[0 0 6 4.5]);
        set(gcf, 'PaperPosition', [0 0 6 4.5]);
        set(gcf,'PaperSize',[6 4.5]);
        set(gca,'box','off');
        % set(gca,'XAxisLocation','top');
        set(gca,'XTickLabel',Dval);
        set(gca,'XTick',1:size(Dval,1));
        set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1)),'\epsilon^c'));
        set(gca,'YTick',1:size(Eval,1));
        colorbar;
        h=colormap;
        colormap(flipud(h));
        % a=(1:size(X,1))';
        % b=num2str(a);
        % c=cellstr(b);
        text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
            1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(enval(:),'%4.3f')));
        title('Total work contour (Ver), \kappa_D=1');
        print('Total_work_contour_Ver_KD=1','-dpdf');
        figure;
        imagesc(ctime);
        xlabel('\bf{\delta}','FontSize',12);
        ylabel('\bf{\epsilon^c_w}','FontSize',12);
        set(gcf,'units','inches');
        set(gcf,'Position',[0 0 6 4.5]);
        set(gcf, 'PaperPosition', [0 0 6 4.5]);
        set(gcf,'PaperSize',[6 4.5]);
        set(gca,'box','off');
        % set(gca,'XAxisLocation','top');
        set(gca,'XTickLabel',Dval);
        set(gca,'XTick',1:size(Dval,1));
        set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1)),'\epsilon^c'));
        set(gca,'YTick',1:size(Eval,1));
        colorbar;
        h=colormap;
        colormap(flipud(h));
        % set(h,'YDir','reverse');
        % a=(1:size(X,1))';
        % b=num2str(a);
        % c=cellstr(b);
        text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
            1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(ctime(:),'%3.2f')));
        title('closure time contour, \kappa_D=1');
        print('closure_time_contour_KD=1','-dpdf');
        %%%%%%%%%%%
        figure;
        imagesc(Nrem);
        xlabel('\bf{\delta}','FontSize',12);
        ylabel('\bf{\epsilon^c_w}','FontSize',12);
        set(gcf,'units','inches');
        set(gcf,'Position',[0 0 6 4.5]);
        set(gcf, 'PaperPosition', [0 0 6 4.5]);
        set(gcf,'PaperSize',[6 4.5]);
        set(gca,'box','off');
        % set(gca,'XAxisLocation','top');
        set(gca,'XTickLabel',Dval);
        set(gca,'XTick',1:size(Dval,1));
        set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1)),'\epsilon^c'));
        set(gca,'YTick',1:size(Eval,1));
        colorbar;
        h=colormap;
        colormap(flipud(h));
        % set(h,'YDir','reverse');
        % a=(1:size(X,1))';
        % b=num2str(a);
        % c=cellstr(b);
        text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
            1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(Nrem(:))));
        title('Number of remodellings contour, \kappa_D=1');
        print('number_of_remodellings_KD=1','-dpdf');

    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Ener_delta_eps
    figure;
    %flist=dir('En15_*');
    flist1=dir('En215*0.6_5.0');
    flist2=dir('En215_0.1*');
    p=size(flist1,1);
    q=size(flist2,1);
    %nfile=p*q;
    Dval=zeros(p,1);
    Eval=zeros(q,1);
    enval=zeros(q,p);
    % arateval=enval;
    ctime=enval;
    Abmat=enval;
    for i=1:p
        Dval(i)=str2num(flist1(i).name(7:9));
    end
    for i=1:q
        Eval(i)=str2num(flist2(i).name(11:13));
    end
    for i=1:p
        for j=1:q
            cd(strcat('En215_',num2str(Dval(i),'%2.1f'),'_',num2str(Eval(j),'%2.1f'),'_5.0'));
            load('ener');
            load('Ab');
            load('tout');
            %    Abaux=Ab.Vw(Ab.Vw>eps);
            %    Abmat(j,i)=Abaux(end);
            en=sum(ener(Ab.Vw>1,1:2),2);
            %     en=ener(Ab.Vw>1,5);
            %     en=ener(Ab.Vw>1,2);
            %     en=ener(Ab.Vw>1,1);
            %     en=ener(Ab.Vw>1,3);
            enval(end-j+1,i)=sum(en(2:end).*diff(tout(Ab.Vw>1)));
            Ab.Vw=Ab.Vw(Ab.Vw>eps);
            tout=tout(Ab.Vw>eps);
            %     arateval(j,i)=(max(Ab.Vw)-Ab.Vw(end))/(tout(end)-tout(Ab.Vw==max(Ab.Vw)));
            ctime(end-j+1,i)=tout(end)-tout(Ab.Vw==max(Ab.Vw));
            cd ..
        end
    end
    imagesc(enval);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_v}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1))));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
        1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(enval(:),'%4.3f')));
    title('Total work contour - \epsilon^c_v');
    print('Total_work_contour_epsilonCV','-dpdf');
    figure;
    imagesc(ctime);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_v}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1))));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % set(h,'YDir','reverse');
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
        1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(ctime(:),'%3.2f')));
    title('closure time contour - \epsilon^c_v');
    print('closure_time_contour_epsilonCV','-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Ener_delta_epsD
    figure;
    %flist=dir('En15_*');
    flist1=dir('En315*_0.5');
    flist2=dir('En315_0.1*');
    p=size(flist1,1);
    q=size(flist2,1);
    %nfile=p*q;
    Dval=zeros(p,1);
    Eval=zeros(q,1);
    enval=zeros(q,p);
    % arateval=enval;
    ctime=enval;
    Abmat=enval;
    for i=1:p
        Dval(i)=str2num(flist1(i).name(7:9));
    end
    for i=1:q
        Eval(i)=str2num(flist2(i).name(19:21));
    end
    for i=1:p
        for j=1:q
            cd(strcat('En315_',num2str(Dval(i),'%2.1f'),'_0.7','_5.0_',num2str(Eval(j),'%2.1f')));
            load('ener');
            load('Ab');
            load('tout');
            %    Abaux=Ab.Vw(Ab.Vw>eps);
            %    Abmat(j,i)=Abaux(end);
            en=sum(ener(Ab.Vw>1,1:2),2);
            %     en=ener(Ab.Vw>1,5);
            %     en=ener(Ab.Vw>1,2);
            %     en=ener(Ab.Vw>1,1);
            %     en=ener(Ab.Vw>1,3);
            enval(end-j+1,i)=sum(en(2:end).*diff(tout(Ab.Vw>1)));
            Ab.Vw=Ab.Vw(Ab.Vw>eps);
            tout=tout(Ab.Vw>eps);
            %     arateval(j,i)=(max(Ab.Vw)-Ab.Vw(end))/(tout(end)-tout(Ab.Vw==max(Ab.Vw)));
            ctime(end-j+1,i)=tout(end)-tout(Ab.Vw==max(Ab.Vw));
            cd ..
        end
    end
    imagesc(enval);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_D}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1))));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
        1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(enval(:),'%4.3f')));
    title('Total work contour - \epsilon^c_D');
    print('Total_work_contour_epsilonCD','-dpdf');
    figure;
    imagesc(ctime);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_D}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1))));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % set(h,'YDir','reverse');
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
        1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(ctime(:),'%3.2f')));
    title('closure time contour - \epsilon^c_D');
    print('closure_time_contour_epsilonCD','-dpdf');
end
%%%%%%%%%%%%%%%%
if Dev_delta_epsw
    figure;
    %flist=dir('En15_*');
    flist1=dir('En15*3.5');
    flist2=dir('En15_0.1*');
    p=size(flist1,1);
    q=size(flist2,1);
    %nfile=p*q;
    Dval=zeros(p,1);
    Eval=zeros(q,1);
    Devd=zeros(q,p);
    Devv=zeros(q,p);
    % arateval=enval;
    ctime=Devd;
    Nrem=Devd;
    for i=1:p
        Dval(i)=str2num(flist1(i).name(6:8));
    end
    for i=1:q
        Eval(i)=str2num(flist2(i).name(14:16));
    end
    for i=1:p
        for j=1:q
            cd(strcat('En15_',num2str(Dval(i),'%2.1f'),'_0.7_',num2str(Eval(j),'%2.1f')));
            load('dLD');
            load('dLV');
            load('Ab');
            load('tout');
            load('nrem');
            dLDaux=dLD(Ab.Vw>1);
            dLVaux=dLV(Ab.Vw>1);
            toutaux=tout(Ab.Vw>1);
            Devd(end-j+1,i)=sum(dLDaux(2:end).*diff(toutaux))/toutaux(end);
            Devv(end-j+1,i)=sum(dLVaux(2:end).*diff(toutaux))/toutaux(end);
            Ab.Vw=Ab.Vw(Ab.Vw>eps);
            tout=tout(Ab.Vw>eps);
            %     arateval(j,i)=(max(Ab.Vw)-Ab.Vw(end))/(tout(end)-tout(Ab.Vw==max(Ab.Vw)));
            ctime(end-j+1,i)=tout(end)-tout(Ab.Vw==max(Ab.Vw));
            Nrem(end-j+1,i)=sum(numrem);
            cd ..
        end
    end
    imagesc(Devd);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_w}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1)),'\epsilon^c'));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
        1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(Devd(:),'%4.3f')));
    title('Delaunay Strain Deviation per time-step, \kappa_D=0.2');
    print('Delaunay_Strain_Deviation_KD=0.2','-dpdf');
    figure;
    imagesc(Devv);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{\epsilon^c_w}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1)),'\epsilon^c'));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4 5 5 5 5 5]-0.25,[1 2 3 4 5 ...
        1 2 3 4 5 1 2 3 4 5 1 2 3 4 5 1 2 3 4 5],cellstr(num2str(Devv(:),'%4.3f')));
    title('Vertex Strain Deviation per time-step, \kappa_D=0.2');
    print('Vertex_Strain_Deviation_KD=0.2','-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Ener_delta_Vp
    figure;
    %flist=dir('En15_*');
    flist1=dir('En515*_0.2');
    flist2=dir('En515_0.1*');
    p=size(flist1,1);
    q=size(flist2,1);
    %nfile=p*q;
    Dval=zeros(p,1);
    Eval=zeros(q,1);
    enval=zeros(q,p);
    % arateval=enval;
    ctime=enval;
    Nrem=enval;
    Abmat=enval;
    for i=1:p
        Dval(i)=str2num(flist1(i).name(7:9));
    end
    for i=1:q
        Eval(i)=str2num(flist2(i).name(19:21));
    end
    for i=1:p
        for j=1:q
            cd(strcat('En515_',num2str(Dval(i),'%2.1f'),'_0.7','_5.0_',num2str(Eval(j),'%2.1f')));
            load('ener');
            load('Ab');
            load('tout');
            load('nrem');
            %    Abaux=Ab.Vw(Ab.Vw>eps);
            %    Abmat(j,i)=Abaux(end);
                 en=sum(ener(Ab.Vw>1,1:2),2);
            %     en=ener(Ab.Vw>1,5);
            %     en=ener(Ab.Vw>1,2);
            %     en=ener(Ab.Vw>1,1);
            %     en=ener(Ab.Vw>1,3);
            toutaux=tout(Ab.Vw>1);
            enval(end-j+1,i)=sum(en(2:end).*diff(toutaux))/toutaux(end);
            Ab.Vw=Ab.Vw(Ab.Vw>eps);
            %     arateval(j,i)=(max(Ab.Vw)-Ab.Vw(end))/(tout(end)-tout(Ab.Vw==max(Ab.Vw)));
            ctime(end-j+1,i)=toutaux(end)-toutaux(Ab.Vw==max(Ab.Vw));
            Nrem(end-j+1,i)=sum(numrem);
            cd ..
        end
    end
    imagesc(enval);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{Set.V_p}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1))));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 1 2 2 2 2 2 2 3 3 3 3 3 3 4 4 4 4 4 4 5 5 5 5 5 5]-0.25,[1 2 3 4 5 6 ...
        1 2 3 4 5 6 1 2 3 4 5 6 1 2 3 4 5 6 1 2 3 4 5 6],cellstr(num2str(enval(:),'%4.1f')));
    title('Total work contour / time - Set.V_p');
    print('Total_work_contour_per_t_SetVp','-dpdf');
    figure;
    imagesc(ctime);
    xlabel('\bf{\delta}','FontSize',12);
    ylabel('\bf{Set.V_p}','FontSize',12);
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:size(Dval,1));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1))));
    set(gca,'YTick',1:size(Eval,1));
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % set(h,'YDir','reverse');
    % a=(1:size(X,1))';
    % b=num2str(a);
    % c=cellstr(b);
    text([1 1 1 1 1 1 2 2 2 2 2 2 3 3 3 3 3 3 4 4 4 4 4 4 5 5 5 5 5 5]-0.25,[1 2 3 4 5 6 ...
        1 2 3 4 5 6 1 2 3 4 5 6 1 2 3 4 5 6 1 2 3 4 5 6],cellstr(num2str(ctime(:),'%3.2f')));
    title('closure time contour - Set.V_p');
    print('closure_time_contour_SetVp','-dpdf');
    %%%%%%%
    figure;
        imagesc(Nrem);
        xlabel('\bf{\delta}','FontSize',12);
        ylabel('\bf{Set.V_p}','FontSize',12);
        set(gcf,'units','inches');
        set(gcf,'Position',[0 0 6 4.5]);
        set(gcf, 'PaperPosition', [0 0 6 4.5]);
        set(gcf,'PaperSize',[6 4.5]);
        set(gca,'box','off');
        % set(gca,'XAxisLocation','top');
        set(gca,'XTickLabel',Dval);
        set(gca,'XTick',1:size(Dval,1));
        set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1))));
        set(gca,'YTick',1:size(Eval,1));
        colorbar;
        h=colormap;
        colormap(flipud(h));
        % set(h,'YDir','reverse');
        % a=(1:size(X,1))';
        % b=num2str(a);
        % c=cellstr(b);
        text([1 1 1 1 1 1 2 2 2 2 2 2 3 3 3 3 3 3 4 4 4 4 4 4 5 5 5 5 5 5]-0.25,[1 2 3 4 5 6 ...
            1 2 3 4 5 6 1 2 3 4 5 6 1 2 3 4 5 6 1 2 3 4 5 6],cellstr(num2str(Nrem(:))));
        title('Number of remodellings contour - Set.V_p');
        print('number_of_remodellings_SetVp','-dpdf');
end
cd ..
end