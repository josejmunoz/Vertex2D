function [ener,gel,Kel,ln1,Eps,G]=DashpotLineElem(dt,dim,eta,x,xp,x0,DispBased)
% DispBased: Displacement based
if ~exist('DispBased','var')
    DispBased=false;
end
ln1=norm(x(1:dim)-x(dim+1:2*dim));
ln=norm(xp(1:dim)-xp(dim+1:2*dim));
l0=norm(x0(1:dim)-x0(dim+1:2*dim));
x12(1:dim,1)=x(1:dim)-x(dim+1:2*dim);
x12(dim+1:2*dim,1)=-x12(1:dim,1);
x12=x12/ln1;
gamma =zeros(2*dim,2*dim);
gamma(1:dim,1:dim)=eye(dim);
gamma(1:dim,dim+1:2*dim)=-eye(dim);
gamma(dim+1:2*dim,1:dim)=-eye(dim);
gamma(dim+1:2*dim,dim+1:2*dim)=eye(dim);
dotEps=(ln1-ln)/(dt*l0);
Kel=(eta/(dt*l0))*(ln/ln1*(x12)*x12'+(ln1-ln)/ln1*gamma);
Eps=(ln1-l0)/l0;
if DispBased
    dotEps=dotEps*l0;
    Kel=Kel*l0;
    Eps=Eps*l0;
end
gel=eta*dotEps*x12;
ener=0;
G=gel(1:dim)'*x12(1:dim);
end