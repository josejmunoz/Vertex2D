function [X,X0,x,x0,xp,dofx,cdof,vext,nodes,nodes0,nodV,g_v,gD,gV,g_xi,...
    FE0,FEp,FEadd,N,Vp,V0,V00,xip,lnodp,lnodvp,Vol0,ln,Ab]=Remove1cell(X,X0,x,x0,...
    xp,dofx,cdof,vext,nodes,nodes0,nodV,g_v,gD,gV,g_xi,FE0,FEp,N,Vp,V0,...
    V00,xip,lnodp,lnodvp,vor_cell,Vol0,Vol,ln,Ab,m,Set)
remove_cell=false;
FEadd=[];
if (Set.Remodel && Set.Ablation) && length(Ab.nodAb)>2
[Vmin,Ic]=min(Vol(Ab.cellAb));
if  Ab.Vwc-Ab.Vw(m)>=0.5*Vmin
    remove_cell=true;
    Ab.Vwc=Ab.Vw(m);
    dim=size(X,2);
    %%finding index of smallest cell within the wound
    Ix=nodV(Ab.cellAb(Ic));
    %                               %%removing the node
    X(Ix,:) =[];
    X0(Ix,:)=[];
    x(dim*(Ix-1)+1:dim*Ix) =[];
    x0(dim*(Ix-1)+1:dim*Ix)=[];
    xp(dim*(Ix-1)+1:dim*Ix)=[];
    di=ismember(dofx,dim*(Ix-1)+1:dim*Ix);
    dofx(di)=[];
    dofx(dofx>dim*Ix)=dofx(dofx>dim*Ix)-dim;   
    ci=ismember(cdof,dim*(Ix-1)+1:dim*Ix);
    cdof(ci)=[];
    cdof(cdof>dim*Ix)=cdof(cdof>dim*Ix)-dim;
    vext(dim*(Ix-1)+1:dim*Ix)=[];
    %                               %%modification of number of nodes
    nodes=nodes-1;
    nodes0=nodes0-1;
    nodV(Ab.cellAb(Ic))=[];
    a= nodV>nodV(Ab.cellAb(Ic));
    nodV(a)=nodV(a)-1;
    %                               %%modification or residual terms
    g_v(dim*(Ix-1)+1:dim*Ix) =[];
    gD(dim*(Ix-1)+1:dim*Ix)  =[];
    gV(dim*(Ix-1)+1:dim*Ix)  =[];
    if length(g_xi)>1
        g_xi(dim*(Ix-1)+1:dim*Ix)=[];
    end
    %                               %%removing triangles and vertices including
    %                               the remover node
    a= FE0(:,1)==Ix | FE0(:,2)==Ix | FE0(:,3)==Ix;
    FE0(a,:)=[];
    FE0(FE0>Ix)=FE0(FE0>Ix)-1;
    V0(a,:)=[];
    V00=V0;
    indV=vor_cell{Ab.cellAb(Ic)};
    xip([indV*dim-1 indV*dim])=[];
    FEc=FEp(indV,:);
    FEp(indV,:)=[];
%     lnodc_ext=zeros(size(FEc,1),2);
%     for i=1:size(FEc,1)
%         tri=FEc(i,:);
%         lnodc_ext(i,:)=tri(tri~=Ix);
%     end
%     lnodc_ext(lnodc_ext>Ix)=lnodc_ext(lnodc_ext>Ix)-1;
    Ixadd=sort([lnodp(lnodp(:,1)==Ix,2);lnodp(lnodp(:,2)==Ix,1)]);
    Ixadd(Ixadd>Ix)=Ixadd(Ixadd>Ix)-1;
    FEadd=delaunay(X(Ixadd,:));
    FEadd=Ixadd(FEadd);
    FEp(FEp>Ix)=FEp(FEp>Ix)-1;
    Vp(indV,:)=[];
    N(indV,:)=[];
    %                               %%removing and reindexing nodal and vertex
    %                                elements including removed node
    a= ismember(lnodvp(:,1),indV) & ismember(lnodvp(:,2),indV);
    b= (ismember(lnodvp(:,1),indV) & ~ismember(lnodvp(:,2),indV)) | ...
        (~ismember(lnodvp(:,1),indV) & ismember(lnodvp(:,2),indV));
    lnodvp(a | b,:)=[];
    aux=lnodp(b,:);
    lnodp(a | b,:)=[];
    lnodp=[lnodp;aux];
    lnodp(lnodp>Ix)=lnodp(lnodp>Ix)-1;
    indV=sort(indV,'descend');
    for i=1:length(indV)
        auxi=lnodvp>indV(i);
        lnodvp(auxi)=lnodvp(auxi)-1;
    end
    %                                %%removing the removed cell from the rest
    %                                of the wounded cells/ reindexing wound
    %                                cells
    Ab.nodAb(Ab.nodAb==Ix)=[];
    Ab.nodAb(Ab.nodAb>Ix)=Ab.nodAb(Ab.nodAb>Ix)-1;
    Ab.Contract=Ab.nodAb;
    %                                 %%removing and reindexing nodal and
    %                                 vertex elements lengths
    aux=ln.D.n.A.r(b,:);
    ln.D.n.A.r(a | b) =[];
    ln.D.n.A.r=[ln.D.n.A.r;aux];
    %
    aux=ln.D.n.A.e(b,:);
    ln.D.n.A.e(a | b) =[];
    ln.D.n.A.e=[ln.D.n.A.e;aux];
    %
    aux=ln.D.n.A.c(b,:);
    ln.D.n.A.c(a | b) =[];
    ln.D.n.A.c=[ln.D.n.A.c;aux];
    %
    aux=ln.D.n.B.r(b,:);
    ln.D.n.B.r(a | b) =[];
    ln.D.n.B.r=[ln.D.n.B.r;aux];
    %
    aux=ln.D.n.B.e(b,:);
    ln.D.n.B.e(a | b) =[];
    ln.D.n.B.e=[ln.D.n.B.e;aux];
    %
    aux=ln.D.n.B.c(b,:);
    ln.D.n.B.c(a | b) =[];
    ln.D.n.B.c=[ln.D.n.B.c;aux];
    %
    aux=ln.D.n.S.e(b,:);
    ln.D.n.S.e(a | b) =[];
    ln.D.n.S.e=[ln.D.n.S.e;aux];
    %
    aux=ln.D.n.S.c(b,:);
    ln.D.n.S.c(a | b) =[];
    ln.D.n.S.c=[ln.D.n.S.c;aux];
    %
    aux=ln.D.n1.A.r(b,:);
    ln.D.n1.A.r(a | b)=[];
    ln.D.n1.A.r=[ln.D.n1.A.r;aux];
    %
    aux=ln.D.n1.A.e(b,:);
    ln.D.n1.A.e(a | b)=[];
    ln.D.n1.A.e=[ln.D.n1.A.e;aux];
    %
    aux=ln.D.n1.A.c(b,:);
    ln.D.n1.A.c(a | b)=[];
    ln.D.n1.A.c=[ln.D.n1.A.c;aux];
    %
    aux=ln.D.n1.B.r(b,:);
    ln.D.n1.B.r(a | b)=[];
    ln.D.n1.B.r=[ln.D.n1.B.r;aux];
    %
    aux=ln.D.n1.B.e(b,:);
    ln.D.n1.B.e(a | b)=[];
    ln.D.n1.B.e=[ln.D.n1.B.e;aux];
    %
    aux=ln.D.n1.B.c(b,:);
    ln.D.n1.B.c(a | b)=[];
    ln.D.n1.B.c=[ln.D.n1.B.c;aux];
    %
    aux=ln.D.n1.S.e(b,:);
    ln.D.n1.S.e(a | b)=[];
    ln.D.n1.S.e=[ln.D.n1.S.e;aux];
    %
    aux=ln.D.n1.S.c(b,:);
    ln.D.n1.S.c(a | b)=[];
    ln.D.n1.S.c=[ln.D.n1.S.c;aux];
    %
    ln.V.n.A.r(a | b) =[];
    ln.V.n.A.e(a | b) =[];
    ln.V.n.A.c(a | b) =[];
    ln.V.n.B.r(a | b) =[];
    ln.V.n.B.e(a | b) =[];
    ln.V.n.B.c(a | b) =[];
    ln.V.n.S.e(a | b) =[];
    ln.V.n.S.c(a | b) =[];
    ln.V.n1.A.r(a | b)=[];
    ln.V.n1.A.e(a | b)=[];
    ln.V.n1.A.c(a | b)=[];
    ln.V.n1.B.r(a | b)=[];
    ln.V.n1.B.e(a | b)=[];
    ln.V.n1.B.c(a | b)=[];
    ln.V.n1.S.e(a | b)=[];
    ln.V.n1.S.c(a | b)=[];
    %                                    %%removing removed cell's ideal volume
    %                                     fro the list cells ideal volumes
    Vol0(Ab.cellAb(Ic))=[];
end
end
end