function [ener,gel,Kel,ln1_elas,Eps,ln1,G]=MaxwellLineElem(kappa,eta,dt,Ec,x0,x,xp,ln_elas,Set)
% If eta =0, purely elastic element
poly=false;
if isfield(Set,'poly_elas')
    poly=Set.poly_elas;
end
dim=floor(length(x)/2);
ln1=norm(x(1:dim)-x(dim+1:2*dim));
l0=norm(x0(1:dim)-x0(dim+1:2*dim));
l0_elas=0.5*l0;
l0_visc=l0-l0_elas;
ln=norm(xp(1:dim)-xp(dim+1:2*dim));
ln_visc=ln-ln_elas;
x12(1:dim,1)=x(1:dim)-x(dim+1:2*dim);
x12(dim+1:2*dim,1)=-x12(1:dim,1);
x12=x12/ln1;
gamma =zeros(2*dim,2*dim);
gamma(1:dim,1:dim)=eye(dim);
gamma(1:dim,dim+1:2*dim)=-eye(dim);
gamma(dim+1:2*dim,1:dim)=-eye(dim);
gamma(dim+1:2*dim,dim+1:2*dim)=eye(dim);
if Set.DispBased
    Ec=Ec/l0; %g and K will be mulitplied by l0
end
if abs(eta)>0
    a=1/(kappa/l0+eta/(dt*l0));
    ln1_elas=a*(kappa*(l0_elas/l0)+(eta/(dt*l0))*(ln1-ln_visc)); % dot _eps_ e+k/eta*eps_e=dot eps
    ln1_visc=ln1-ln1_elas;
    Eps_elas=(ln1_elas-l0_elas)/l0;
    Eps_elasE=Eps_elas;
    Eps_visc=(ln1_visc-l0_visc)/l0;
    Eps=Eps_elas+Eps_visc;
    fact=(eta/(dt*l0))*a;
else
    ln1_elas=ln1;
    l0_elas=l0;
    Eps_elasE=(ln1_elas-l0_elas)/l0; % For elastic energy computation (no contractility)
    Eps_elas=Eps_elasE+Ec; % Include contractility in purely elastic element
    Eps=Eps_elas;
    fact=1;
end
if poly
    gel=kappa*Eps_elas^2*x12;
    G=kappa*Eps_elas^2;
    Kel=(2*kappa*Eps_elas*fact/l0-G/ln1)*(x12)*x12' + G/ln1*gamma;
    ener=kappa/3*Eps_elasE^3;
elseif Set.enerM==0
    gel=kappa*Eps_elas*x12;
    G=kappa*Eps_elas;
    Kel=(kappa*fact/l0-G/ln1)*(x12)*x12' + G/ln1*gamma;
    ener=0.5*kappa*Eps_elasE^2;
elseif Set.enerM==1
    gel=kappa*Eps_elas*fact/l0*x12;
    Kel=kappa*((fact/l0)^2-Eps_elas*fact/l0/ln1)*(x12)*x12' + kappa*Eps_elas*fact/l0/ln1*gamma;
    ener=0.5*kappa*Eps_elasE^2;
elseif Set.enerM==2
    geA=kappa*Eps_elas*fact/l0*x12;
    gel=ln1*kappa*Eps_elas*fact/l0*x12+0.5*Eps_elas^2*x12;
    Kel=kappa*((fact/l0)^2-Eps_elas*fact/l0/ln1)*(x12)*x12' + kappa*Eps_elas*fact/l0/ln1*gamma;
    Kel=ln1*Kel+geA*x12'+x12*geA'+0.5*kappa*Eps_elas^2/ln1*(gamma-(x12)*x12');
    ener=0.5*kappa*Eps_elasE^2*ln1;
end
G=gel(1:dim)'*x12(1:dim);
if Set.DispBased
    if poly 
        gel=gel*l0^2;
        G=G*l0^2;
        Kel=Kel*l0^2;
        ener=ener*l0^3;
    else
        gel=gel*l0;
        G=G*l0;
        Kel=Kel*l0;
        ener=ener*l0^2;
    end
end