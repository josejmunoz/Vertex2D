
function [Ab,BC,err,esc,Lumen,Mat,Set,Step]=PreSet(Ab,BC,Lumen,Mat,Set,Step)
% Defines default values for material and analysis paremeters
% Sets also Internal Settings
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Default Material values
if ~isfield(Mat,'D')
    Mat.D.kappa=0.0;
end
if ~isfield(Mat.D,'kappa')
    Mat.D.kappa =0.0;  % Stiffness of Main Delaunay
end
if ~isfield(Mat.D,'kappaA')
    Mat.D.kappaA=0.0;  % Stiffness of 2nd branch Delaunay
end
if ~isfield(Mat.D,'kappaB')
    Mat.D.kappaB=0.0;  % Stiffness of 3rd branch Delaunay
end
if ~isfield(Mat.D,'GammaA')
    Mat.D.GammaA=0.0;  % GammaA=-1 dashpot branch on Delaunay
end
if ~isfield(Mat.D,'GammaB')
    Mat.D.GammaB=0.0;
end
if ~isfield(Mat.D,'etaA')
    Mat.D.etaA  =0.0;  %   >0 Maxwell Viscosity of Delaunay 1st Branch, <0 dashpot only of Delaunay
end
if ~isfield(Mat.D,'etaB')
    Mat.D.etaB  =0.0;  %   >0 Maxwell Viscosity of Delaunay 2nd Branch, <0 dashpot only of Delaunay
end
if ~isfield(Mat.D,'Ec')
    Mat.D.Ec    =0.0;  % Contractility in Spring Delaunay
end
if ~isfield(Mat.D,'EcA')
    Mat.D.EcA   =0.0;  % Contractility in A1
end
if ~isfield(Mat.D,'EcB')
    Mat.D.EcB   =0.0;  % Contractility in B
end
if ~isfield(Mat.D,'Ect')
    Mat.D.Ect   =0.0;  % time at which Contractility in elastic branch =D.Ec (=0, constant contractility)
end
if ~isfield(Mat.D,'EcAt')
    Mat.D.EcAt  =0.0;  % time at which Contractility in active branch =D.EcA (=0, constant contractility)
end
if ~isfield(Mat.D,'EcBt')
    Mat.D.EcBt  =0.0;  % time at which Contractility in active branch =D.EcB (=0, constant contractility)
end
if ~isfield(Mat.D,'beta')
    Mat.D.beta  =0.0;  % factor for self regulated contractility on Delaunay, d eps_c /dt=beta*(sigma-sigmaT)
    % If beta<=0, same contractility on all elements
end
if ~isfield(Mat.D,'betaA')
    Mat.D.betaA =0.0;  % factor for self regulated contractility on Delaunay A, d eps_c /dt=beta*(sigma-sigmaT)
end
if ~isfield(Mat.D,'betaB')
    Mat.D.betaB =0.0;  % factor for self regulated contractility on Delaunay B, d eps_c /dt=beta*(sigma-sigmaT)
end
if ~isfield(Mat.D,'Bcells')
    Mat.D.Bcells=1.0;  % Factor multiplying boundary cells when Set.Bcells=true
end
if ~isfield(Mat.D,'Delay')
    Mat.D.Delay =0.0;  % Delay on evolution law of vertex network
end
% Vertices/Voronoi. Maxwell on Voronoi is considered whenever,
if ~isfield(Mat,'V')
    Mat.V.kappa=0;
end
%  abs(etaVA)>eps || abs(etaVB)>eps
if ~isfield(Mat.V,'kappa')
    Mat.V.kappa =0.0;  %kappa for voronoi vertices stiffness
end
if ~isfield(Mat.V,'kappaA')
    Mat.V.kappaA=0.0;  % Stiffness for Active/Maxwell 1st Branch on Voronoi
end
if ~isfield(Mat.V,'kappaB')
    Mat.V.kappaB=0.0;  % Stiffness for Active/Maxwell 2nd Branch on Voronoi
end
if ~isfield(Mat.V,'GammaA')
    Mat.V.GammaA=0.0;  % Viscossity for Active 1st Branch in voronoi. =0: no viscosity
end
if ~isfield(Mat.V,'GammaB')
    Mat.V.GammaB=0.0;  % Viscossity for Active 2nd Branch in voronoi. =0: no viscosity
end
if ~isfield(Mat.V,'etaA')
    Mat.V.etaA  =0.0;  %   >0 Maxwell Viscosity of Voronoi 1st Branch, <0 dashpot only of Voronoi
end
if ~isfield(Mat.V,'etaB')
    Mat.V.etaB  =0.0;  %   >0 Maxwell Viscosity of Voronoi 2nd Branch, <0 dashpot only of Voronoi
end
if ~isfield(Mat.V,'Ec')
    Mat.V.Ec    =0.0;  % Contractility in Spring Voronoi
end
if ~isfield(Mat.V,'EcA')
    Mat.V.EcA   =0.0;  % Contractility in Voronoi
end
if ~isfield(Mat.V,'EcB')
    Mat.V.EcB   =0.0;  % Contractility in Voronoi
end
if ~isfield(Mat.V,'Ect')
    Mat.V.Ect   =0.0;  % time at which Contractility in elastic branch =V.Ec (=0, constant contractility)
end
if ~isfield(Mat.V,'EcAt')
    Mat.V.EcAt  =0.0;  % time at which Contractility in active branch =V.EcA (=0, constant contractility)
end
if ~isfield(Mat.V,'EcBt')
    Mat.V.EcBt  =0.0;  % time at which Contractility in active branch =V.EcB (=0, constant contractility)
end
if ~isfield(Mat.V,'beta')
    Mat.V.beta  =0.0;  % factor for self regulated contractility on Voronoi, d eps_c /dt=beta*(sigma-sigmaT)
    % If beta<=0, same contractility on all elements
end
if ~isfield(Mat.V,'betaA')
    Mat.V.betaA =0.0;  % factor for self regulated contractility on Vertices A, d eps_c /dt=beta*(sigma-sigmaT)
end
if ~isfield(Mat.V,'betaB')
    Mat.V.betaB =0.0;  % factor for self regulated contractility on Vertices B, d eps_c /dt=beta*(sigma-sigmaT)
end
if ~isfield(Mat.V,'Delay')
    Mat.V.Delay =0.0;  % Delay on evolution law of vertex network
end
% Lumen formation
% When Lumen.V is set, this vertex is set to split.
% When Lumen.lnod0 is set, these vertex bar elements have an applied pressure
% If none of them is set, vertex is chosen in UpdateGeoLumen. 
if ~exist('Lumen','var')
    Lumen = cell(0,0); % If different from 0 should contain
else
    for w=1:length(Lumen)
        if ~isfield(Lumen{w},'lnod0')
            Lumen{w}.lnod0=[]; % % false: vertices of lumen depend on those of nodes.
                                    % true: vertices of lumen are relaxed (independent positions)
        end
        if ~isfield(Lumen{w},'Relaxed')
            Lumen{w}.Relaxed=Set.Xirel; % 0 (false): vertices of lumen depend on those of nodes.
                            % 1 (true): vertices of lumen are relaxed (independent positions)
        end
        if ~isfield(Lumen{w},'P0')
            Lumen{w}.P0=1; % Internal pressure
        end
        if ~isfield(Lumen{w},'V')
            Lumen{w}.V=0; % Vertex to be splited. If =0, no splitting, Lumen made from vertices in Lumen{w}.lnod0, or accordingto criteria in UpdateLumenGeo
        end
    end
end

% Linear Contractility 
Mat.D.Ec0=Mat.D.Ec;
Mat.V.Ec0=Mat.V.Ec;
Mat.D.Ec0A=Mat.D.EcA;
Mat.V.Ec0A=Mat.V.EcA;
Mat.D.Ec0B=Mat.D.EcB;
Mat.V.Ec0B=Mat.V.EcB;
% Volume constraint
if ~isfield(Set,'Vp')
    Set.Vp=0;
end
% Displacement based elasticity
if ~isfield(Set,'DispBased')
    Set.DispBased=false;
end
if ~isfield(Set, 'enerM')
    Set.enerM=0;
            %=0: elstic force is k*eps^2 along bar directon 
            %=1: elastic force is the derivative of the specific elastic energy wrt x
            %(TRUE minimisation)
            %=2: elastic force is the derivative of the elemental elastic energy wrt x
            %(TRUE minimisation, total energy takes into account current length)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Network toplogy and rheology
if ~isfield(Set,'Network')
    Set.Network=5; % if NetworkType=0, Geometry is made of a grid with Network x Network
                   % if NetworkType=1, Geometry is made of a circular grid
                   % of Network radius
                   % Network =0: 1 element
                   % Network <0: Experimental real cells
end
if ~isfield(Set,'NetworkType')
    Set.NetworkType=0; % =0: Square network, =1: Circular network
end
if ~isfield(Set,'ImageFile')
    Set.ImageFile='150416m.png'; % File with cell images when network<0
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Ablation      %%%%%%%%%%%%%%%%% 
if ~isfield(Set,'Ablation')
    Set.Ablation =0;  %1.5   % =0: no tissue ablation, >0: tissue ablation with redius "Ablation"(in cell mean size units)
end
if ~exist('Ab','var')
    Ab.tAb=0;
end
if ~isfield(Ab,'tAb')
    Ab.tAb=0;         % Time of applying Ablation
end
if ~isfield(Ab,'tEc')
    Ab.tEc=30;           % Time between ablation (tAb) and applying wound ring contractility =Ab.tEc*dt
end
if ~isfield(Set,'Vrel')
    Set.Vrel=true;      % Vertex relaxation. true=vertex relaxation, =false xi relaxation.
end
if ~isfield(Ab,'Co')
    Ab.Co       =1e-4;    % coefficient applied on ablated cells Delaunay elements (Dead-Dead and Dead-Alive)
end
if ~isfield(Ab,'CoVor')
    Ab.CoVor    =5e-6;    % coefficient applied on stiffness and eta of ablated vertex elements (Dead-Dead)
end
if ~isfield(Ab,'CoGamm')
    Ab.CoGamm   =50;    % coefficient applied on gamma of ablated vertex elements (Dead-Dead)
end
if ~isfield(Ab,'Ec')
    Ab.Ec       =5.0;     % Factor for contractility at wound edge during closure =Ab.Ec*V.Ec (spring branch), Ab.Ec*V.EcA (branch A)
end
if ~isfield(Ab,'CoEc')
    Ab.CoEc       =5.0;     % coefficient applied on contractility of ablated vertex elements (Dead-Dead). Only during active closure, and if length of element below Ab.LFilo. (Filopodia effect)
end
if ~isfield(Ab,'CoK')
    Ab.CoK=5e-6; % coefficient applied on stiffness of ablated vertex elements (Dead-Dead). Only during active closure. (Filopodia effect)
end
if ~isfield(Ab,'TargetArea')
    Ab.TargetArea=0.0; % Limit area for stopping wound healing problem. If TargetArea=0, no stopping for stopping
end
if ~isfield(Ab,'Timed')
    Ab.Timed=0; % Timed: progressive closure accoridng to nodAbt and nodAbTimes
end
if ~isfield(Step,'factorW')
    Step.factorW=5.0; % Facotr mulitplying time-step in increments before ablation 
end
if ~isfield(Ab,'LFilo')
    Ab.LFilo=1.0; % Length Filopodia, below which contractility may be activated.
end
%%%%%%%%%%%%% Boundary Condition %%%%%%%%%%%%%%%
if ~isfield(BC,'Monotonic')
    BC.Monotonic =false;% true=linear (monotonic), false=linear + constant/reverse
end
if ~isfield(BC,'Reverse')
    BC.Reverse   =false;% Monotonic=false: true=adds reverse displacement, false=constant
end
if ~isfield(BC,'ts')
    BC.ts        =0.0;  % Monotonic=false: duration of linear stretching
                        % Monotonic=true: time when xStrech is achieved. May be
                        % a vector
end
if ~isfield(BC,'xStretch')
    BC.xStretch   =0.0;  % Monotonic=false: Maximum load/displacement in stretching
                        % Monotonic=true: stretching at t=BC.ts. May be a
                        % vector, with length(BC.xStretch)=length(BC.ts)
end
if ~isfield(BC,'FullConstr')
    BC.FullConstr=1; % =0: constrain left and right side of tissue only,
                        % =1: fully constrain triangular elements in contact with external boundary
end
if ~isfield(BC,'CVert')
    BC.CVert=true;            % =true: Constrain also vertical direction (y) on right nodes with imposed displacement
end
if  ~isfield(BC,'mu')
    BC.mu       =0; % viscous coefficient wrt to substrate on boundary nodes whne they are free
                    % When different from 0, reasonable value:
                    % BC.mu       =2.0*(Mat.V.kappa+Mat.V.kappaA+Mat.V.kappaB); 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fitting
if ~isfield(Set,'Fitting')
    Set.Fitting=false;  % true= fit material parameters
end
if ~isfield(Set,'File')
    Set.File='Network4x4_K02_VK1_VKA1_veA1_VEc05'; % File with data [gout, tout] that must be fitted
        % Some possiblities:
        % Network4x4_VK1_VEc05,
        % Network4x4_K1_Ec05
        % Network4x4_K02_VK1_VKA1_vgA1_VEc05
        % Network4x4_K02_VK1_VKA1_veA1
        % Network4x4_K02_VK1_VKA1_veA1_VEc05
        % OneElem_k1
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Interpolation Constraints
if ~isfield(Set,'Xirel')
    Set.Xirel    =-1;   % Type of xi-relaxation, =1: total xi-relaxation, =-1: wound ring xi-relaxation, =0: no xi-relaxation
end
if ~isfield(Set,'lambda')
    Set.lambda   =1.0*(Mat.V.kappa+Mat.V.kappaA+Mat.V.kappaB); % xi/V-relaxation penalisation factor
end
if ~isfield(Set,'poly_elas')
    Set.poly_elas=false;  % exponential/polynomial elasticity
if ~isfield(Set,'alpha')
    Set.alpha=40;       % discritisation factor of cells free edges  
end
if ~isfield(Set,'tess')
    Set.tess     =false;  % Type of tessellation, true=Voronoi tessellation, False=barycentric tessellation
end
if ~isfield(Set,'Bcells')
    Set.Bcells   =0;   % =-1: no off-set; boundary cells obtained by circle approach
                       % = 0: no off-set; no boundary cells built
                       % = 1: off-set built; boundary cells built on off-set
end
if ~isfield(Set,'deltaD')
    Set.deltaD   =0.3;    % =-1 : Matlab standard Delaunay triangulation
end                       % = 0 : graded Delaunay triangulation with delta=0
                          % > 0 : graded Delaunay triangulation with delta>0
if ~isfield(Set,'Remodel')                      
    Set.Remodel =true;   % =true: Remodel (update connectivity at each increment), =false: connectivity is constant
end
if ~isfield(Set,'Map')
    Set.Map      =true;  % =true: L (resting length) obtained by equilibrium preserving mapping, =False: L presented by element evolution law
end
if ~isfield(Set,'MapSplit')
    Set.MapSplit =true;  % =true: splits map minimisation into Delaunay and Vertex. false=monolithic mapping (Delaunay and Vertex forces together)
end
if ~isfield(Set,'Reg_l')
    Set.Reg_l    =false;   % =true: mapping regularisation with respect to current length. =false: regularisation with respect to previous active lengths
end
%%%%%%%%%%%%%%%% Profiler, Logfile, Output, Print %%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~isfield(Set,'LogFile')
    Set.LogFile='Network.log'; % If Set.LogFile='', no logfile written
end
if ~isfield(Set,'Results')
    Set.Results=0; % 0=No specific plot
                   % 1=Results for Yanlan Experiments
                   % 2=Results for Delay Experiments
end
if ~isfield(Set,'Profiler')
    Set.Profiler=false;
end
if ~isfield(Set,'Print')
    Set.Print=0;   % 0=Iterative/incremental results not printed
                   % 1=Iterative/incremental results printed
end
%%%%%%%%%%%%%%%% Folder Settings %%%%%%%%%%%%%%%%%%%%%%%%%%%
comp        =computer;
BC.Step     =~BC.Monotonic;
%%%%%%%%%%%%%%%% Internal Setting Mat %%%%%%%%%%%%%%%%%%%%%%
if ~isfield(Set,'sparseM')
    Set.sparseM=true;
end
if ~isfield(Set,'NumJac')
    Set.NumJac=false;           % =true: Numerical K_o, =false: Analytical K_o
end
if ~isfield(Set,'VTK')
    Set.VTK=true;              % =true: write VTK files
end
%%%%%%%%%%%%%%%% Internal Setting Geometry %%%%%%%%%%%%%%%%%
if ~isfield(Set,'deltaR')
    Set.deltaR=0.5;    %treshhold of in-radius/circum-radius of Delaunay triangles on the boundary
end
%%%%%%%%%%%%%%%% Internal Setting time stepping %%%%%%%%%%%%
Step.dt=Step.dt0;          % Current time-step
Step.dts=Step.dt0;      % Initial time-step during t<Step.ts
if Set.Ablation>0
    A=ceil(Ab.tAb/(Step.dt*Step.factorW));
    Step.nincr=ceil((Step.tend-A*Step.dt*Step.factorW)/Step.dt)+A;
else
    Step.nincr=ceil(Step.tend/Step.dt)+1;
end
%Step.nincr=floor((Step.tend-Ab.tAb-Step.dt*Step.factorW)/Step.dt+(Ab.tAb+Step.dt*Step.factorW)/(Step.dt*Step.factorW));
Step.maxiter=10;
Step.num_sh_Max=7;          % Maximum Step halvings
Step.num_sh=0;
Step.tol=1e-9;             % tolerance
Step.theta=0.5;             % For Kelvin or pure viscous theta=1.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(comp(1:3),'PCW') % Windows machine
    esc='\';
else
    esc='/';
end
err=0;
if ~exist(strcat(pwd,esc,'Rheology'),'dir')
    disp('Run program from folder where Main is located');
    err=1;
    return;
end
if ~isempty(Set.LogFile)
    if exist(Set.LogFile,'file')
        diary off;
        delete(Set.LogFile);
    end
    diary(Set.LogFile);
end
addpath(strcat(pwd,esc,'Plots'));
addpath(strcat(pwd,esc,'Rheology'));
addpath(strcat(pwd,esc,'Geometry'));
addpath(strcat(pwd,esc,'Fitting'));
addpath(strcat(pwd,esc,'ExpData'));
addpath(strcat(pwd,esc,'Init'));
addpath(strcat(pwd,esc,'Lumen'));
if ~exist(strcat(pwd,esc,'VTKResults'),'dir')
    P=path;
    if strfind(P,strcat(pwd,esc,'VTKResults'))>0
        rmpath(strcat(pwd,esc,'VTKResults'));
    end
    mkdir(strcat(pwd,esc,'VTKResults'))
end
if ~exist(strcat(pwd,esc,'VTKResultsWound'),'dir') && Set.Ablation>0
    mkdir(strcat(pwd,esc,'VTKResultsWound'))
    cd(strcat(pwd,esc,'VTKResultsWound'));
    delete *.*; % Delete previous VTK files
    cd ..;
end
addpath(strcat(pwd,esc,'VTK'));
cd(strcat(pwd,esc,'VTKResults'));
if ~Set.Fitting
    delete *.*; % Delete previous VTK files
end
cd ..;
if Set.Fitting
    Set.VTK=false;
    Set.print=0;
    Set.FitIter0=20;  % (approximated) Max number of iterations (calls to function)
    Set.FitIter=0;    % Counter for number of iterations during fitting. Do not change.
end
% Checks
if abs(Set.Vp)<eps && Set.Ablation
    warning('Small volume constrain has been added (2*%e) for computing volume\n',eps);
    Set.Vp=2*eps;
end
if (Mat.D.Delay>0 || Mat.V.Delay>0) && Set.Remodel
    disp('Delayed rest length evolution law is not implemented with remodelling. Remodelling has been removed.');
    Set.Remodel=false;
end
if 2*Set.Ablation > Set.Network && Set.Network >=0
    warning('Ablation larger than network size. No ablation is analysed\n');
    Set.Ablation=0;
    Ab.tAb=Step.tend;
end
if Set.Bcells==1  && Set.Remodel
    Set.Bcells  =0;
    disp('Remodelling with off-set (boundary cells) not implemented. Off-set removed.');
elseif Set.Bcells<0
    Set.Vrel=true;
end
% Lumen Check. No remodelling implemented
if length(Lumen)>0 && Set.Remodel==true
    warning('Remodelling in Lumen not implemented yet. Set.Remodel set to false');
    Set.Remodel=false;
end
end