function [g,K]=gKb(x,xp,Vor,Vorp,dim,nodes,nodesV,Set,nodV,lnod,lnodExternal,lnodW,lnod_vor)
%%% viscous/elastic term on boundary nodes/vertices displacement
if Set.Xirel<0
     if Set.Bcells>-1
        nod=1:nodes;
        nod(nodV)=[]; 
        nodB=nod;
     else
         nodB=lnodExternal(~ismember(lnodExternal(:,1),lnodW(:,1)),1)';
     end
    if dim==2
        dofB=[2*nodB-1 2*nodB];
    else
        dofB=[3*nodB-2 3*nodB-1 3*nodB];
    end
    dx     =x-xp;
    xb=dofB;
else
    dV=Vor-Vorp;
    dx=reshape(dV',size(Vor,1)*dim,1);
    sizel=size(lnod,1);
    Vb=lnod_vor(sizel-size(lnodExternal,1)+1:sizel,2);
    vbdel=ismember(lnodExternal(:,1),lnodW(:,1));      %% index of wound vertices to be removed 
    Vb(vbdel)=[];
    xb=dim*(Vb-1)+(1:dim);
    xb=reshape(xb',size(xb,1)*dim,1);
    dofB=nodes*dim+xb;
end
g      =zeros(dim*(nodes+nodesV),1);
g(dofB)=dx(xb);
n      =length(dofB);
if Set.sparseM
    N=(nodes+nodesV)*dim;
    i=dofB;
    v=ones(n,1);
    K=sparse(i,i,v,N,N);
else
    K=[zeros(nodes*dim,nodes*dim)  zeros(nodes*dim,nodesV*dim)
       zeros(nodesV*dim,nodes*dim) zeros(dim*nodesV)];
    K(dofB,dofB)=eye(n);
end