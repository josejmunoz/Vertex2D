function [centroid]=RealCellsVoronoi(imname)
% Import File
%----------------------------
comp=computer;
if strcmp(comp(1:3),'PCW') % Windows machine
    esc='\';
else
    esc='/';
end
impath=strcat('.',esc);%path to image

% imname='Rob.png';%image file name

img=imread([impath,imname]);%import image
dimg=double(img);%transform it in double
bdimg=zeros(size(dimg,1),size(dimg,2));
for c=1:3
    bdimg=bdimg+dimg(:,:,1);%sum RGB components
end
lbdimg=logical(bdimg);%all colours to 1, all black to zero
lbdimg=lbdimg+0;%logical to double

% Find cell boundaries and centroids
%-------------------------------------------
lbdimg=lbdimg(2:end-1,2:end-1);%trim border
[img_coord(:,1),img_coord(:,2)]=find(lbdimg==1);%find image coordinates
[B,L,N,A] = bwboundaries(lbdimg);%find boundaries of the cells
% figure, imshow(lbdimg); hold on;%display image


centroid=zeros(length(B),2);%store centroid coordinates
for k=1:length(B)
    boundary = B{k};
    centroid(k,1)=mean(boundary(:,2));%find centroid coordinates - x
    centroid(k,2)=mean(boundary(:,1));%find centroid coordinates - y
    
%     plot(boundary(:,2), boundary(:,1),'Color','w','LineWidth',2); %plot boundaries
%     plot(centroid(k,1), centroid(k,2),'.','Color','w');%plot centroids
%     hold on
end
% Voronoi tesselation
%-----------------------
[vx,vy]=voronoi(centroid(2:end,1),centroid(2:end,2));%voronoi tesselation - store vertex coordinates

% plot(vx,vy,'Color','b','LineWidth',2);%plot voronoi tesselation
% hold on

% Delaunay tesselation
%-----------------------
tri=delaunay(centroid(2:end,1),centroid(2:end,2));%calculate delaunay from voronoi
% trimesh(tri,centroid(2:end,1),centroid(2:end,2),'Color','r','LineWidth',2);% plot delaunay tesselation
centroid=centroid(2:end,:)/10;
% centroid=[centroid zeros(size(centroid(:,1),1),1)];
end