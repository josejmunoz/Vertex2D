function [K,g]=KgEcL(across,alpha,beta,dt,Ec,Ec0,Ec1,gamma,kappa,ln,ln1,lr,lr1,t,theta)
% Sets residual and Jacobian of 2 dimensional p=(L,eps_c) variable system 
% with resting length (L) and contractility (eps_c) satisfying 
% corresponding evolution equations
% g=g_p
% K=K_{pp}, only corresponding with coudpling p-p
% REFERENCE
% Jose Munoz, UCL_Theory, May 2016
%
Ecmax=1.5;
    lnt=(1-theta)*ln+theta*ln1;
    lrnt=(1-theta)*lr+theta*lr1;
    Ecnt=(1-theta)*Ec+theta*Ec1;
    g=[lr1-lr-dt*gamma*(lnt-(1+Ecnt)*lrnt)
        Ec1-Ec-dt*beta*kappa*(Ec0+1-lnt/lrnt)^alpha];
    K=[1+dt*gamma*theta*(1+Ecnt)        dt*gamma*theta*lrnt
        -dt*beta*theta*alpha*(Ec0+1-lnt/lrnt)^(alpha-1)*kappa*lnt/lrnt^2   1];    
    if t>=1 && across
       g(2)= Ec1-min(Ec,Ecmax)-dt*beta*kappa*(Ec0)^alpha;
       K(2,:)= [0   1];    
    end

end