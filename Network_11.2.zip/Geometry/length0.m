function [ener,ln,Eps_tot,gout,u,tout,numrem,xierror,map_error,nodError,Ab,DevLd,DevLv]=length0(Ab,lnod,Mat,nincr,X,Vol)
% Initialises Delaunay variables:
% ln  : Delaunay lengths at time t_n
nele=size(lnod,1);
tout=zeros(nincr,1);
Eps_tot=zeros(nincr,nele);
gout=zeros(nincr,1);
numrem=gout;
xierror=gout;
map_error=gout;
nodError=zeros(size(X,1),1);
ener=zeros(nincr,5);
u=zeros(nincr,1);
Ab.V_tot=zeros(nincr,1);
Ab.Vnoc=zeros(nincr,1);
Ab.Vc1=zeros(nincr,1);
Ab.Vc2=zeros(nincr,1);
Ab.Vw=zeros(nincr,1);
Ab.Pw=zeros(nincr,1);
Ab.Vwc=sum(Vol(Ab.cellAb));
DevLd=zeros(nincr,1);
DevLv=zeros(nincr,1);
ln.S.e=Lengths(lnod,X);
ln.A.r=ln.S.e;
ln.B.r=ln.S.e;
if  Mat.etaA>0
    ln.A.e=0.5*ln.S.e;
else
    ln.A.e=ln.S.e;
end
if  Mat.etaB>0
    ln.B.e=0.5*ln.S.e;
else
    ln.B.e=ln.S.e;
end
% Set contractility
ln.S.c=Mat.Ec*ones(size(ln.S.e));
ln.A.c=Mat.EcA*ones(size(ln.A.r));
ln.B.c=Mat.EcB*ones(size(ln.B.r));
end