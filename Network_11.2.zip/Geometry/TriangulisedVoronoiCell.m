function [TriVorCell,Trigroup]=TriangulisedVoronoiCell(vor_cell,cellAb,Ab)
%%%%%%%%%%%
if Ab
    vor_cell(cellAb,:)=[];
end
if isempty(vor_cell)
    TriVorCell=[];
    Trigroup=[];
else
    %%%%%%%%%%%
    TriVorCell=zeros(sum(cellfun(@numel,vor_cell))-3*numel(vor_cell),3);
    a=1;
    Trigroup=zeros(size(vor_cell,1),3);
    for i=1:size(vor_cell,1)
        cell=vor_cell{i}(1:end-1);
        n=numel(cell)-2;
        tri=[ones(n,1) (2:n+1)' (3:n+2)'];
        b=a+n-1;
        TriVorCell(a:b,:)=cell(tri);
        Trigroup(i,:)=[a b i]; %[index of first tiangle    index of last triangle   index of Voronoi cell];
        a=b+1;
    end
    %%%To cancel repetitive triangles (occuring only in concave cell shapes, only possible when Voronoi Tessellation with no remodelling)
    %TriVorCell=unique(sort(TriVorCell,2),'rows');
end
end