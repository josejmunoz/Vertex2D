function CreatvtkVor2D(i,V_real0,V_real,stress,b_real,dim,Ab,AbActive,wound,ln)
if wound
    str0='VTKResultsWound';
    stress.T=stress.T([Ab.eleVorDD;Ab.eleVorDL]);
    stress.S=stress.S([Ab.eleVorDD;Ab.eleVorDL]);
    stress.A=stress.A([Ab.eleVorDD;Ab.eleVorDL]);
    stress.B=stress.B([Ab.eleVorDD;Ab.eleVorDL]);
    ln.A.r=ln.A.r([Ab.eleVorDD;Ab.eleVorDL]);
    ln.A.c=ln.A.c([Ab.eleVorDD;Ab.eleVorDL]);
    ln.S.c=ln.S.c([Ab.eleVorDD;Ab.eleVorDL]);
    ln.S.e=ln.S.e([Ab.eleVorDD;Ab.eleVorDL]);
else
    str0='VTKResults';
end
str2='.vtk';
str3 = num2str(i);
str4='.Vor.';
str13=strcat(str0,str4,str3);
comp=computer;
if strcmp(comp(1:3),'PCW') % Windows machine
    newSubFolder = sprintf('%s\\%s',pwd,str0);
else
    newSubFolder = sprintf('%s/%s',pwd,str0);
end
if ~exist(newSubFolder, 'dir')
    mkdir(newSubFolder);
end
cd(newSubFolder);
nameout=strcat(str13,str2);
%%%%%%%%%%%
if AbActive
    b_real(Ab.eleVorDD,:)=[];
    stress.T(Ab.eleVorDD)=[];
    stress.A(Ab.eleVorDD)=[];
    stress.B(Ab.eleVorDD)=[];
    stress.S(Ab.eleVorDD)=[];
    ln.A.r(Ab.eleVorDD)=[];
    ln.A.c(Ab.eleVorDD)=[];
    ln.S.c(Ab.eleVorDD)=[];
    ln.S.e(Ab.eleVorDD)=[];
end
%%%%%%%%%%%
nodesold=size(V_real,1);
nele=size(b_real,1);
file=fopen(nameout,'w');
fprintf(file,'%s\n','# vtk DataFile Version 3.98');
fprintf(file,'%s\n','Voronoi_vtk');
fprintf(file,'%s\n','ASCII');
fprintf(file,'%s\n','DATASET UNSTRUCTURED_GRID');
fprintf(file,'%s %d %s\n','POINTS',nodesold,'float');
for j=1:size(V_real,1)
    fprintf(file,'%f     %f      %f\n',V_real(j,:),0);
end
b_real=b_real-1;
fprintf(file,'%s %d  %d\n','CELLS',size(b_real,1),size(b_real,1)*3);
for h=1:size(b_real,1)
    fprintf(file,'%d %d %d\n',size(b_real(h,:),2),b_real(h,1),b_real(h,2));
end
fprintf(file,'%s %d\n','CELL_TYPES',size(b_real,1));
for j=1:size(b_real,1)
    fprintf(file,'%d\n',3);
end
%%%%%%%Results%%%%%%%%%%
fprintf(file,'%s %d\n','POINT_DATA',nodesold);
fprintf(file,'%s \n','VECTORS  Displacements float');
for k=1:nodesold
    if dim==2
        fprintf(file,'%f   %f   %f\n',V_real(k,1)-V_real0(k,1),V_real(k,2)-V_real0(k,2),0);
    else
        fprintf(file,'%f   %f   %f \n',x(3*k-2)-x0(3*k-2),x(3*k-1)-x0(3*k-1),x(3*k)-x0(3*k));
    end
end
fprintf(file,'%s %d \n','CELL_DATA',nele);
fprintf(file,'%s \n','SCALARS stressVorTot float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(stress.T)
    fprintf(file,'%f\n',stress.T(i));
end
fprintf(file,'%s \n','SCALARS stressVorA float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(stress.A)
    fprintf(file,'%f\n',stress.A(i));
end
fprintf(file,'%s \n','SCALARS stressVorB float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(stress.B)
    fprintf(file,'%f\n',stress.B(i));
end
fprintf(file,'%s \n','SCALARS stressVorS float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(stress.S)
    fprintf(file,'%f\n',stress.S(i));
end
fprintf(file,'%s \n','SCALARS VContractilityA float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
if ~isempty(ln)
    for i=1:length(ln.A.c)
        fprintf(file,'%f\n',ln.A.c(i));
    end
    fprintf(file,'%s \n','SCALARS VRelRestingLengthA float ');
    fprintf(file,'%s \n','LOOKUP_TABLE default');
    for i=1:min(length(ln.A.r),length(ln.S.e))
        fprintf(file,'%f\n',ln.A.r(i)/ln.S.e(i));
    end
    fprintf(file,'%s \n','SCALARS VContractilityS float ');
    fprintf(file,'%s \n','LOOKUP_TABLE default');
    for i=1:length(ln.S.c)
        fprintf(file,'%f\n',ln.S.c(i));
    end
end
fclose(file);
cd '..'
end
