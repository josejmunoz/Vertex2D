function PlotE
load('Enomap');
load('Efull');
load('Esplit');
load('nfull');
load('nsplit');
figure
plot(1:size(Enomap,1),Enomap(:,1),'k-o',1:size(Enomap,1),Efull(:,1),'r-o',1:size(Enomap,1),Esplit(:,1),'b-o',...
    1:size(Enomap,1),Enomap(:,2),'k-*',1:size(Enomap,1),Efull(:,2),'r-*',1:size(Enomap,1),Esplit(:,2),'b-*',...
    1:size(Enomap,1),nfull,'ro',1:size(Enomap,1),nsplit,'b*','LineWidth',2);
xlabel('time-step');
ylabel('reaction/number of remodellings');
legend('nomapD','fullmapD','splitmapD','nomapV','fullmapV','splitmapV','n of remodelling-full','n of remodellings-split','Location','northwest')
end