function [ld,ln,Vor,Vorp]= UpdateLn(ld, ln,lnod,lnod_vor,Mat,mode,Vor_stiff,Network,X,Vor,Vorp )
%Updates length parameters and Voronoi after convergence or failure of convergence
if mode==1 % Converged increment
    ln.D.n=CopyLn(ln.D.n,ln.D.n1);
    if Vor_stiff && Network~=0
        ln.V.n=CopyLn(ln.V.n,ln.V.n1);
        Vorp=Vor;
    end
    % Update rest length of vertices at delay time
    if Mat.V.nDelayA>0 
        l=Lengths(lnod_vor,Vor);
        for e=1:length(ld{1}.V)
            for t=size(ld,1):-1:2
                ld{t}.V(e).L=ld{t-1}.V(e).L;
                ld{t}.V(e).l=ld{t-1}.V(e).l;
            end
            ld{1}.V(e).L=ln.V.n1.A.r(e);
            ld{1}.V(e).l=l(e);
        end
    end
    % Update rest length of Delaunay at delay time
    if Mat.D.nDelayA>0 
        l=Lengths(lnod,X);
        for e=1:length(ld{1}.D)
            for t=size(ld,1):-1:2
                Ld{t}.D(e).L=Ld{t-1}.D(e).L;
                ld{t}.D(e).l=ld{t-1}.D(e).l;
            end
            ld{1}.D(e).L=ln.D.n1.A.r(e);
            ld{1}.D(e).l=l(e);
        end
    end
elseif mode==2
    ln.D.n1=CopyLn(ln.D.n1,ln.D.n);
    if Vor_stiff && Network~=0
        ln.V.n1=CopyLn(ln.V.n1,ln.V.n);
        Vor=Vorp;
    end
end
end
% Copy values
function lA=CopyLn(lA,lB)
% Copies lB into lA:  lA=lB
        lA.S.e=lB.S.e;
        lA.A.e=lB.A.e;
        lA.B.e=lB.B.e;
        lA.A.r=lB.A.r;
        lA.B.r=lB.B.r;
        lA.A.c=lB.A.c;
        lA.B.c=lB.B.c;
        lA.S.c=lB.S.c;
end


