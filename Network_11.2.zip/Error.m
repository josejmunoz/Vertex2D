function [erD,erV]=Error(lnod,lnodv,lnodFE,lnodExternal,ln,X,V)
td=zeros(size(X,1),size(X,2));
tv=zeros(size(V,1),size(V,2));
normtd=zeros(size(X,1),1);
normtv=zeros(size(V,1),1);
lnd=ln.D.n.A.r;
lnv=ln.V.n.A.r;
a1=lnodExternal(:,1);
a2= ismember(lnodFE(:,1),a1) | ismember(lnodFE(:,2),a1) | ismember(lnodFE(:,3),a1);
a1=unique([lnodFE(a2,1);lnodFE(a2,2);lnodFE(a2,3)]);
for i=1:size(lnodv,1)
    if i<=size(lnod,1)
    l=norm(X(lnod(i,2),:)-X(lnod(i,1),:));
    e=(X(lnod(i,2),:)-X(lnod(i,1),:))/l;
    t=(l/lnd(i)-1)*e;
%     t=sD(i)*e;
    td(lnod(i,2),:)=td(lnod(i,2),:)+t;
    td(lnod(i,1),:)=td(lnod(i,1),:)-t;
    nt=norm(t);
    normtd([lnod(i,1) lnod(i,2)])=normtd([lnod(i,1) lnod(i,2)])+[nt;nt];
    end
    l=norm(V(lnodv(i,2),:)-V(lnodv(i,1),:));
    e=(V(lnodv(i,2),:)-V(lnodv(i,1),:))/l;
    t=(l/lnv(i)-1)*e;
%     t=sV(i)*e;
    tv(lnodv(i,2),:)=tv(lnodv(i,2),:)+t;
    tv(lnodv(i,1),:)=tv(lnodv(i,1),:)-t;
    nt=norm(t);
    normtv([lnodv(i,1) lnodv(i,2)])=normtv([lnodv(i,1) lnodv(i,2)])+[nt;nt];
end
tv(a2,:)=[];
td(a1,:)=[];
normtv(a2)=[];
normtd(a1)=[];
erD=sum((sqrt(sum(td.^2,2)))./normtd);
erV=sum((sqrt(sum(tv.^2,2)))./normtv);
end