function Mat = SetContractility( Mat,t)
%Set values of contractile Strain for linear contractility
if Mat.D.beta<eps
    if Mat.D.Ect>eps
        Mat.D.Ec=t*Mat.D.Ec0/Mat.D.Ect;
    end
end
if Mat.D.betaA<eps
    if Mat.D.EcAt>eps
        Mat.D.EcA=t*Mat.D.Ec0A/Mat.D.EcAt;
    end
end
if Mat.D.betaB<eps
    if Mat.D.EcBt>eps
        Mat.D.EcB=t*Mat.D.Ec0B/Mat.D.EcBt;
    end
end
if Mat.V.beta<eps
    if Mat.V.Ect>eps
        Mat.V.Ec=t*Mat.V.Ec0/Mat.V.Ect;
    end
end
if Mat.V.betaA<eps
    if Mat.V.EcAt>eps
        Mat.V.EcA=t*Mat.V.Ec0A/Mat.V.EcAt;
    end
end
if Mat.V.betaB<eps
    if Mat.V.EcBt>eps
        Mat.V.EcB=t*Mat.V.Ec0B/Mat.V.EcBt;
    end
end
end

