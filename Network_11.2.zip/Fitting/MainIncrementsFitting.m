function [Mat,gout,u,fminres,Fval,exitflag,output,time]=MainIncrementsFitting(Mat,Step,Set,BC,p,LBi,UBi,File,Ab)
%  p = array indicating material parameters to fit.
%      p(i)=0  -> do not fit material parameter i
%      p(i)~=0 -> fit material parameter i
%      Ordering of material parameters according to:
%      Delaunay:                               Vertices:
%      k kA kB GA GB eA eB Ec EcA EcB Ect EcAt k kA kB GA GB eA eB Ec EcA EcB Ect EcAt
% File =Expdata_stress_control
%      =CharrasData_ECadGFP
%      =OneElem_k1 Data for one element with k=1, other =0
%      = Network4x4_VK1_VEc05: 4x4 network with D.k =0.5, V.k=1.0, V.Ec=0.5
fprintf('Fitting material parameters for experimental data in file %s\n',File);
[Y,time]=ReadData(File); % experimental data
save('Y','Y');
save('Fitting','Mat','Set','Step','BC','p','Ab');
[pguess,LB,UB]=RetreiveMat(Mat,p,LBi,UBi);
options = optimset('lsqcurvefit');
%options.Display='iter';
% options = optimset(options,'Algorithm','levenberg-marquardt') % With no bound constraints
options = optimset(options,'MaxIter',floor(Set.FitIter0/6)); % Number of function calls ~ 5*number of iterations in optim options
% options = optimset('Algorithm','trust-region-reflective')
[param,fminres,Fval,exitflag,output] = lsqcurvefit(@MainIncrementCall,pguess,time,Y,LB,UB,options);
% Update Mat with optimal values:
Mat=UpdateMat(Mat,p,param);
if exitflag==1
    fprintf('Optimum has been fitted in %d iterations. Residual=%e \n',output.iterations,fminres);
    fprintf('Delaunay material:\n');
    disp(Mat.D);
    fprintf('Vertex material:\n');
    disp(Mat.V);
else
    fprintf('No optimum could be fitted in %d iterations\n',output.iterations);
end
load('gout');
delete('Fitting.mat');
delete('gout.mat');
delete('Y.mat');


