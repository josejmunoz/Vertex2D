function [ld,Mat]=DelayInit(ln,lnod,lnodv,Mat,X,Y,Step)
% Initiailsed delayed lengths
% INPUT:
% lnod = connectivity of nodal lengths
% Cv   = connectivity of vertex lengths
% X    = nodal positions
% Y    = vertex positions
% Set  = structure with settings (see SetDefaults)
% OUTPUT:
% Mat = Material structure (see SetDefaults)
% ld = set of previous resting lengths
%   ld{end}.V(e).L = rest lengths of Vertex element e at time (t-Delay)
%   ld{end}.V(e).l = current lengths of Vertex element e at time (t-Delay)
%   ld{end}.D(e).l = rest lengths of Delaunay element e time (t-Delay)
%   ld{end}.D(e).l = current lengths of Delaunay element e at time (t-Delay)
%
% Only Delay in Branch A
Mat.D.nDelay=0;
Mat.D.nDelayB=0;
Mat.V.nDelay=0;
Mat.V.nDelayB=0;
% Voronoi
if max(Mat.V.Delay,Mat.D.Delay)>0
    Mat.D.nDelayA=ceil(Mat.D.Delay/Step.dt0);
    Mat.V.nDelayA=ceil(Mat.V.Delay/Step.dt0);
    ld=cell(max(Mat.D.nDelayA,Mat.V.nDelayA),1); % Delayed time-steps
else
    Mat.D.nDelayA=0;
    Mat.V.nDelayA=0;
    ld=cell(1);
end
l=Lengths(lnodv,Y);
if Mat.V.Delay>0 
    for e=1:size(lnodv,1)
        ld{1}.V(e).l=l(e);
        ld{1}.V(e).L=ln.V.n1.A.r(e);
        for i=2:Mat.V.nDelayA
            ld{i}.V(e).L=ld{i-1}.V(e).L;
            ld{i}.V(e).l=ld{i-1}.V(e).l;
        end
    end
    Mat.V.DEnd=Mat.V.nDelayA;
else
    for e=1:size(lnodv,1)
        ld{1}.V(e).L=ln.V.n1.A.r(e);
        ld{1}.V(e).l=l(e);
    end
    Mat.V.DEnd=1;
end
% Delaunay
l=Lengths(lnod,X);
if Mat.D.Delay>0
    for e=1:size(lnod,1)
        ld{1}.D(e).L=ln.D.n1.A.r(e);
        ld{1}.D(e).l=l(e);
        for i=2:Mat.D.nDelayA
            ld{i}.D(e).L=ld{i-1}.D(e).L;
            ld{i}.D(e).l=ld{i-1}.D(e).l;
        end
    end
    Mat.D.DEnd=Mat.D.nDelayA;
else
    for e=1:size(lnod,1)
        ld{1}.D(e).L=ln.D.n1.A.r(e);
        ld{1}.D(e).l=l(e);
    end
    Mat.D.DEnd=1;
end


