function  [x,X,Fext]=LoadUnload(cdof,X,x0,vext,TL,Step,BC)
t=Step.t;
ts=BC.ts;
Ls=BC.xStretch;
Monotonic=BC.Monotonic;
Step=BC.Step;
Reverse=BC.Reverse;
nodes=size(X,1);
dim=size(X,2);
x=reshape(X',nodes*dim,1)';
if Monotonic
    x(cdof)=x0(cdof)+t/ts*Ls*TL;
    Fext=vext*t/ts*Ls;
elseif Step
    %%%% Charras load %%%%%%%
    if t-ts<eps
        x(cdof)=x0(cdof)+t/ts*Ls*TL;
        Fext=vext*t/ts*Ls;
    elseif Reverse
        x(cdof)=x0(cdof)+(2-t/ts)*Ls*TL;
        Fext=vext*(2-t/ts)*Ls;
    else
%         if Ab.Eca
%            cdof1=reshape([2*Ab.nodAb1-1 2*Ab.nodAb1]',1,38)';
%            for i=1:length(Ab.nodAb1)
%                x(cdof1(2*i-1:2*i))=...
%                    sum(V(vor_cell{nodV==Ab.nodAb1(i)}(1:end-1),:))/(length(vor_cell{nodV==Ab.nodAb1(i)})-1);
%            end
%            
%         else
        x(cdof)=x(cdof);
        Fext=vext*Ls;
%         end
    end
end
X=reshape(x',dim,nodes)';
end