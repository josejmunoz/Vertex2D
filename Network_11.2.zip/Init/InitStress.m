function [stress,stressVol] = InitStress( n,Network,nodesI,nv)
%Initialises elemental stresses (scalars)
stress.D.n1.S=zeros(n,1);
stress.D.n1.T=stress.D.n1.S;
stress.D.n1.A=stress.D.n1.S;
stress.D.n1.B=stress.D.n1.S;
if Network~=0
    stress.V.n1.T=zeros(nv,1);
    stress.V.n1.A=stress.V.n1.T;
    stress.V.n1.B=stress.V.n1.T;
    stress.V.n1.S=stress.V.n1.T;
    stressVol=zeros(nodesI,1);
else
    stressVol=[];
end
end

