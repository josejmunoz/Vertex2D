function [ln]=RemovelnWound(ln,Ilx,Iedgex,naux)
%%% Reordering ln.D
[ln.D.n.A.r] =RemovelnDWound(ln.D.n.A.r,Ilx,Iedgex,naux);
[ln.D.n.A.e] =RemovelnDWound(ln.D.n.A.e,Ilx,Iedgex,naux);
[ln.D.n.A.c] =RemovelnDWound(ln.D.n.A.c,Ilx,Iedgex,naux);
[ln.D.n.B.r] =RemovelnDWound(ln.D.n.B.r,Ilx,Iedgex,naux);
[ln.D.n.B.e] =RemovelnDWound(ln.D.n.B.e,Ilx,Iedgex,naux);
[ln.D.n.B.c] =RemovelnDWound(ln.D.n.B.c,Ilx,Iedgex,naux);
[ln.D.n.S.e] =RemovelnDWound(ln.D.n.S.e,Ilx,Iedgex,naux);
[ln.D.n.S.c] =RemovelnDWound(ln.D.n.S.c,Ilx,Iedgex,naux);
[ln.D.n.A.r] =RemovelnDWound(ln.D.n.A.r,Ilx,Iedgex,naux);
[ln.D.n1.A.e]=RemovelnDWound(ln.D.n1.A.e,Ilx,Iedgex,naux);
[ln.D.n1.A.c]=RemovelnDWound(ln.D.n1.A.c,Ilx,Iedgex,naux);
[ln.D.n1.B.r]=RemovelnDWound(ln.D.n1.B.r,Ilx,Iedgex,naux);
[ln.D.n1.B.e]=RemovelnDWound(ln.D.n1.B.e,Ilx,Iedgex,naux);
[ln.D.n1.B.c]=RemovelnDWound(ln.D.n1.B.c,Ilx,Iedgex,naux);
[ln.D.n1.S.e]=RemovelnDWound(ln.D.n1.S.e,Ilx,Iedgex,naux);
[ln.D.n1.S.c]=RemovelnDWound(ln.D.n1.S.c,Ilx,Iedgex,naux);
sizelnD=length(ln.D.n.A.r);
sizenaux=length(naux);
%%% Reordering ln.V
[ln.V.n.A.r] =RemovelnVWound(ln.V.n.A.r,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n.A.e] =RemovelnVWound(ln.V.n.A.e,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n.A.c] =RemovelnVWound(ln.V.n.A.c,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n.B.r] =RemovelnVWound(ln.V.n.B.r,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n.B.e] =RemovelnVWound(ln.V.n.B.e,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n.B.c] =RemovelnVWound(ln.V.n.B.c,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n.S.e] =RemovelnVWound(ln.V.n.S.e,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n.S.c] =RemovelnVWound(ln.V.n.S.c,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n1.A.r]=RemovelnVWound(ln.V.n1.A.r,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n1.A.e]=RemovelnVWound(ln.V.n1.A.e,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n1.A.c]=RemovelnVWound(ln.V.n1.A.c,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n1.B.r]=RemovelnVWound(ln.V.n1.B.r,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n1.B.e]=RemovelnVWound(ln.V.n1.B.e,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n1.B.c]=RemovelnVWound(ln.V.n1.B.c,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n1.S.e]=RemovelnVWound(ln.V.n1.S.e,Ilx,Iedgex,naux,sizelnD,sizenaux);
[ln.V.n1.S.c]=RemovelnVWound(ln.V.n1.S.c,Ilx,Iedgex,naux,sizelnD,sizenaux);
end
function [lnD]=RemovelnDWound(lnD,Ilx,Iedgex,naux)
    lnaux                   =lnD(Iedgex);
    lnaux                   =lnaux(naux);
    lnD(Ilx | Iedgex)       =[];
    lnD                     =[lnD;lnaux];
end
function [lnV]=RemovelnVWound(lnV,Ilx,Iedgex,naux,sizelnD,sizenaux);
    lnaux                   =lnV(Iedgex);
    lnaux                   =lnaux(naux);
    lnV(Ilx | Iedgex)       =[];
    lnV                     =[lnV(1:(sizelnD-sizenaux),:);lnaux;lnV((sizelnD-sizenaux+1):end,:)];
end