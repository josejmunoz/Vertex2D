function X=CircularDistribution(r)
%r is the radious of the circle
nr =round(pi*(2*r/3-1));       %number of boundary points
c  =[r r];               %centre of the circle
phi=(sqrt(5)+1)/2;       %golden ratio
n  =round(pi*(r^2)/4);   %number of nodes
X=zeros(n,2);
for k=1:n
    rr=Radius(k,n,nr,r);
    a=2*pi*k/phi^2;
    X(k,:)=c+rr*[cos(a) sin(a)];
end
end
function rr=Radius(k,n,nr,r)
if k>n-nr
    rr=r;   %put node on the boundary
else
    rr=r*sqrt(k-1/2)/sqrt(n-(nr+1)/2);     % apply square root
end
end