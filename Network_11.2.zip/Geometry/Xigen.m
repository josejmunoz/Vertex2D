function [xi,xip,N,V,Vp,Vol0,Vol]=Xigen(xi,xip,N,X,Xn,V,Vp,FE,lnodv,Ab,I,Wvele,Set,Vol0,remnod,nodV,vor_cell)
I=~I;   %% index of new triangles (vertices)
VDL=Ab.VorDL;   %% vertices on the wound edge
DD=Ab.eleVorDD; %% index of the dead-dead boundary elements
DL=Ab.eleVorDL; %% index of the dead-live boundary elements
CDL=lnodv(DL,:);   %% boundary elements on the wound edge
if Set.AblationType<1
    V =V(1:size(FE,1),:);
    Vp=Vp(1:size(FE,1),:);
end
if Set.AblationType>0
    I=true(length(VDL),1);
else
    I=logical(I(VDL)); %% logical index of new vertices on the wound edge
end
if sum(I)>0
    w=Wvele;
    
    %%%%%%%%%                                  %%%%%%%%%
    %%%%%%%%% Free vertex alignment approach 1 %%%%%%%%%
    %     VDL=VDL(I);   %% index of new vertices on the wound edge
    %     %     II=ismember(VDL,lnodv(DD,:));   %% logical index of new free vertices on the wound edge (dead-live vertices connected to dead-dead vertices)
    %     %     if sum(II)>0
    %     %         VDL=VDL(II);
    %     for i=1:length(VDL)
    %         I=ismember(lnodDL,VDL(i));  %% logical index of wound edge elements containing free vertices
    %         lnodaux=lnodDL(logical(sum(I,2)),:);
    %         v=zeros(2,1);
    %         for j=1:2
    %             if lnodaux(j,1)==VDL(i)
    %                 v(j)=lnodaux(j,2);
    %             else
    %                 v(j)=lnodaux(j,1);
    %             end
    %         end
    %         V12=V(v(2),:)-V(v(1),:);
    %         e12=V12/norm(V12);
    %         Vd=V(VDL(i),:)-V(v(1),:);
    %         Vt=sum(e12.*Vd)*e12;
    %         if ~ismember(VDL(i),lnodv(DD,:));
    %             Vt=Vd;
    %             %             Vt=(Vt+Vd)/2;
    %         end
    %         V(VDL(i),:)=V(v(1),:)+Vt;
    %         Td=FE(VDL(i),:);
    %         xi(2*VDL(i)-1:2*VDL(i))=[X(Td(3),2)-X(Td(1),2) -X(Td(3),1)+X(Td(1),1);-X(Td(2),2)+X(Td(1),2) X(Td(2),1)-X(Td(1),1)]*(V(VDL(i),:)-X(Td(1),:))'...
    %             /((X(Td(2),1)-X(Td(1),1))*(X(Td(3),2)-X(Td(1),2))-(X(Td(3),1)-X(Td(1),1))*(X(Td(2),2)-X(Td(1),2)));
    %         xip(2*VDL(i)-1:2*VDL(i))=xi(2*VDL(i)-1:2*VDL(i));
    %         N(VDL(i),:)=[1-xi(2*VDL(i)-1)-xi(2*VDL(i)) xi(2*VDL(i)-1) xi(2*VDL(i))];
    %         Vp(VDL(i),:)=sum([N(VDL(i),1)*Xn(Td(1),:);N(VDL(i),2)*Xn(Td(2),:);N(VDL(i),3)*Xn(Td(3),:)]);
    %     end
    %     end
    
    
    
    %%%%%%%%                                  %%%%%%%%
    %%%%%%%% Free vertex alignment approach 2 %%%%%%%%
    CDLaux=zeros(size(CDL,1),2);
    CDLaux(1,:)=CDL(1,:);
    CDL(1,:)=[];
    for i=2:size(CDLaux,1)
        CDLaux(i,1)=CDLaux(i-1,2);
        I1=CDL(:,1)==CDLaux(i,1);
        if logical(sum(I1))
            CDLaux(i,2)=CDL(I1,2);
            CDL(I1,:)=[];
        else
            I2=CDL(:,2)==CDLaux(i,1);
            CDLaux(i,2)=CDL(I2,1);
            CDL(I2,:)=[];
        end
    end
    CDL=CDLaux;
    VDL=VDL(I); %% new boundary vertices
    J=~ismember(VDL,lnodv(DD,:));  %% index of new boundary vertices connected to healthy vertices 
    VDLJ=VDL(J);
    if ~isempty(VDLJ)
        for i=1:length(VDLJ)
            C=V(VDLJ(i),:);
            h=zeros(2*size(Wvele,1),1);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            II=false(size(Wvele,1),1);
            Vc=zeros(length(II),2);
            for j=1:size(Wvele,1)
                A=Wvele(j,1:2);
                B=Wvele(j,3:4);
                h(2*j-1)=norm(C-A);
                h(2*j)=norm(C-B);
                if sum((C-A).*(B-A))>0 && sum((C-B).*(A-B))>0
                    II(j)=true;
                    m=(B(2)-A(2))/(B(1)-A(1));
                    Vc(j,:)=[C(2)-A(2)-m*(C(1)-A(1)) C(1)-A(1)-(C(2)-A(2))/m]/(m+1/m);
                end
            end
            if sum(II)>0
                Vc=Vc(II,:);
                if min(h)<min(sqrt(sum(Vc.^2,2))) %% if min distance to a previous vertex is less than distance to all previous vertex elements 
                    [~,H]=min(h);
                    V(VDLJ(i),:)=Wvele(fix(H/2)+rem(H,2),2*(2-rem(H,2))-1:2*(2-rem(H,2)));
                else
                    [~,JJ]=min(sqrt(sum(Vc.^2,2)));
                    V(VDLJ(i),:)=C+Vc(JJ,:);
                end
            else
                [~,H]=min(h);
                V(VDLJ(i),:)=Wvele(fix(H/2)+rem(H,2),2*(2-rem(H,2))-1:2*(2-rem(H,2)));
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            %    h=abs(((w(:,3)-w(:,1)).*(C(2)-w(:,2))-(C(1)-w(:,1)).*(w(:,4)-w(:,2))))./sqrt(sum([(w(:,3)-w(:,1)).^2 (w(:,4)-w(:,2)).^2],2));
            %     [~,JJ]=min(h);
            %     m=(w(JJ,4)-w(JJ,3))/(w(JJ,2)-w(JJ,1));
            %     V(VDLJ(i),:)=[C(1)/m+C(2)+m*w(JJ,1)-w(JJ,2) C(1)+m*C(2)-w(JJ,1)+w(JJ,2)/m]/(m+1/m);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
    end
    Iout=find(~ismember(CDL(:,1),lnodv(DD,:)));
    if Iout(1)>1
        CDL=[CDL;CDL(1:Iout(1)-1,:)];
        CDL(1:Iout(1)-1,:)=[];
        Iout=Iout-Iout(1)+1;
    end
    for i=1:length(Iout)-1
        A=V(CDL(Iout(i),1),:);
        B=V(CDL(Iout(i+1),1),:);
        if Iout(i+1)-Iout(i)>1
            for j=Iout(i)+1:Iout(i+1)-1
                C=V(CDL(j,1),:);
                V(CDL(j,1),:)=A+sum((B-A).*(C-A))*(B-A)/norm(B-A)^2;
            end
        end
    end
    if Iout(end)<size(CDL,1)
        A=V(CDL(Iout(end),1),:);
        B=V(CDL(Iout(1),1),:);
        for j=Iout(end)+1:size(CDL,1)
            C=V(CDL(j,1),:);
            V(CDL(j,1),:)=A+sum((B-A).*(C-A))*(B-A)/(norm(B-A))^2;
        end
    end
    VDL=CDL(:,1);
    if Set.AblationType<1 
        for i=1:length(VDL)
            Td=FE(VDL(i),:);
             xi(2*VDL(i)-1:2*VDL(i))=[X(Td(3),2)-X(Td(1),2) -X(Td(3),1)+X(Td(1),1);-X(Td(2),2)+X(Td(1),2) X(Td(2),1)-X(Td(1),1)]*(V(VDL(i),:)-X(Td(1),:))'...
             /((X(Td(2),1)-X(Td(1),1))*(X(Td(3),2)-X(Td(1),2))-(X(Td(3),1)-X(Td(1),1))*(X(Td(2),2)-X(Td(1),2)));
            xip(2*VDL(i)-1:2*VDL(i))=xi(2*VDL(i)-1:2*VDL(i));
            N(VDL(i),:)=[1-xi(2*VDL(i)-1)-xi(2*VDL(i)) xi(2*VDL(i)-1) xi(2*VDL(i))];
            Vp(VDL(i),:)=sum([N(VDL(i),1)*Xn(Td(1),:);N(VDL(i),2)*Xn(Td(2),:);N(VDL(i),3)*Xn(Td(3),:)]);
        end
    end
    Vol=zeros(length(nodV),1);
    for k=1:size(nodV)
        for j=1:size(vor_cell{k},1)-1
            Vol(k)=Vol(k)+0.5*det([V(vor_cell{k}(j),:);V(vor_cell{k}(j+1),:)]);  %%calculating volume of cell i
        end
    end
    I=ismember(nodV,remnod); 
    if sum(I)>0
        Vol0(I)=Vol(I);
    end
end
%%%%%%%%                                 %%%%%%%%
%%%%%%%% perimeter minimisation approach %%%%%%%%

% %     VDL=Ab.VorDL;
% %     JJ=find(ismember(VDL,lnodv(DD,:)));
% %     dof=[2*JJ-1 2*JJ];
% %     dof=reshape(dof',2*length(JJ),1);
% %     l=sqrt(sum(((V(CDL(:,2),:)-V(CDL(:,1),:)).^2),2));
% %     g=zeros(2*length(VDL),1);
% %     K=zeros(2*length(VDL),2*length(VDL));
% %     for i=1:length(VDL)
% %         J=find(CDL(:,1)==VDL(i) | CDL(:,2)==VDL(i));
% %         laux=l(J);
% %         for n=1:2
% %             if CDL(J(n),1)==VDL(i)
% %                 m=find(VDL==CDL(J(n),2));
% %             else
% %                 m=find(VDL==CDL(J(n),1));
% %             end
% %             aux=V(VDL(i),:)-V(VDL(m),:);
% %             gaux=aux/laux(n);
% %             g(2*i-1:2*i)=g(2*i-1:2*i)+gaux';
% %             kaux=eye(2)/laux(n)-(aux'*aux/(laux(n)^3));
% %             K(2*i-1:2*i,2*i-1:2*i)=K(2*i-1:2*i,2*i-1:2*i)+kaux;
% %             K(2*m-1:2*m,2*i-1:2*i)=-kaux;
% %         end
% %     end
% %     while norm(g(dof))>1e-10
% %         Kdof=sparse(K(dof,dof));
% %         dV=-Kdof\g(dof);
% %         dV=reshape(dV,2,length(VDL(JJ)))';
% %         V(VDL(JJ),:)=V(VDL(JJ),:)+dV;
% %         l=sqrt(sum(((V(CDL(:,2),:)-V(CDL(:,1),:)).^2),2));
% %         g=zeros(2*length(VDL),1);
% %         K=zeros(2*length(VDL),2*length(VDL));
% %         for i=1:length(VDL)
% %             J=find(CDL(:,1)==VDL(i) | CDL(:,2)==VDL(i));
% %             laux=l(J);
% %             for n=1:2
% %                 if CDL(J(n),1)==VDL(i)
% %                     m=find(VDL==CDL(J(n),2));
% %                 else
% %                     m=find(VDL==CDL(J(n),1));
% %                 end
% %                 aux=V(VDL(i),:)-V(VDL(m),:);
% %                 gaux=aux/laux(n);
% %                 g(2*i-1:2*i)=g(2*i-1:2*i)+gaux';
% %                 kaux=eye(2)/laux(n)-(aux'*aux/(laux(n)^3));
% %                 K(2*i-1:2*i,2*i-1:2*i)=K(2*i-1:2*i,2*i-1:2*i)+kaux;
% %                 K(2*i-1:2*i,2*m-1:2*m)=-kaux;
% %             end
% %         end
% %     end
% %     VDL=VDL(JJ);
% %     for i=length(JJ)
% %
% %         Td=FE(VDL(i),:);
% %         xi(2*VDL(i)-1:2*VDL(i))=[X(Td(3),2)-X(Td(1),2) -X(Td(3),1)+X(Td(1),1);-X(Td(2),2)+X(Td(1),2) X(Td(2),1)-X(Td(1),1)]*(V(VDL(i),:)-X(Td(1),:))'...
% %             /((X(Td(2),1)-X(Td(1),1))*(X(Td(3),2)-X(Td(1),2))-(X(Td(3),1)-X(Td(1),1))*(X(Td(2),2)-X(Td(1),2)));
% %         xip(2*VDL(i)-1:2*VDL(i))=xi(2*VDL(i)-1:2*VDL(i));
% %         N(VDL(i),:)=[1-xi(2*VDL(i)-1)-xi(2*VDL(i)) xi(2*VDL(i)-1) xi(2*VDL(i))];
% %         Vp(VDL(i),:)=sum([N(VDL(i),1)*Xn(Td(1),:);N(VDL(i),2)*Xn(Td(2),:);N(VDL(i),3)*Xn(Td(3),:)]);
% %     end
end