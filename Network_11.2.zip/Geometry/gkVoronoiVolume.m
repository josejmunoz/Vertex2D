function [eVol,g_v,K_v,V_total,V,stressVol]=gkVoronoiVolume(X,FE,N,Vor,vor_cell,vor_cellW,lnod,V0,VW0,nodes,Ab,Set,C)
vor_cell=[vor_cell;vor_cellW];
V0=[V0;VW0];
dim=size(X,2);
nodesV=size(Vor,1);
n=dim*(nodes+nodesV);
g_v=zeros(n,1);
nodesi=size(vor_cell,1);
sizet=size(FE,1);
nlnod=cellfun('length',C.lnod);
if ~isempty(vor_cellW)
    nlnod=[nlnod;6];
end
%nlnod=ones(size(nlnod))*6;
if Set.Bcells<0
    nodesVb=sizet+1:nodesV;
else
    nodesVb=[];
end
if Set.sparseM
   % (aux1,auxx3)+(aux10,auxi1)+(aux1,aux2)+(auxxi1,aux10)+(aux1,aux1)
   % (last one in ge*ge')
   ns=2*(dim*(dim+1)+dim)^2+2*dim^2*(dim+1)+(dim*(dim+1)+dim)^2; %total assembled components per vertex in cell 
   ns=nodesi*10*ns; % Assumed 10 edges/cell maximum
   Sparse.r=zeros(ns,1); % rows
   Sparse.c=zeros(ns,1); % cols
   Sparse.v=zeros(ns,1); % values
   Sparse.k=0; % counter
   K_v=0; 
else
    Sparse.k=0;
    K_v=zeros(n,n);
end
V=zeros(nodesi,1);
stressVol=V;
eVol=0;
if Set.Vrel && Ab.active
       VDL=unique([lnod(Ab.eleVorDL,1);lnod(Ab.eleVorDL,2)]);
else
       VDL=[];
end
for i=1:nodesi % Loop on cells
    Wounded=Ab.active && ismember(i,Ab.cellAb);
    if Set.Xirel>0 && Set.Vrel
        I=false(length(vor_cell{i}));
    else
        I= vor_cell{i}<=sizet & ~(ismember(vor_cell{i},VDL) & Set.Vrel) ;
    end
    [g_v,K_v,Sparse,V(i)]=gVoronoiVolume(g_v,K_v,Sparse,vor_cell{i},Vor(vor_cell{i},:),X,FE(vor_cell{i}(I),:),N(vor_cell{i}(I),:),nodes,nodesV,Set,V0(i),Wounded,I,nlnod(i));
    eVol=eVol+0.5*(V(i)-V0(i))^2/V0(i)^2;
    stressVol(i)=(V(i)-V0(i))/V0(i);
end
if Set.sparseM
    K_v=sparse(K_v)+sparse(Sparse.r(1:Sparse.k),Sparse.c(1:Sparse.k),Sparse.v(1:Sparse.k),dim*(nodes+nodesV),dim*(nodes+nodesV));
end
V_total=sum(V);
end