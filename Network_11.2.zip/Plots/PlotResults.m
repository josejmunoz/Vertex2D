EDEV=false;
vertex=false;
k_V_var=true;
k_D_var=true;
Dvalcompare=false;
ener_time=true;   %ener_time= ~ener_area
plot_remodel=false;  %plots number of remodellings and adds a second axis to the right of energy plots
close all;
cd ..
cd('Results');
if EDEV
    cd('EDEV_final');
else
    if vertex
        cd('RemControl_Total_vertex');
    elseif k_D_var && ~k_V_var
        cd('RemControl_Total_k_D_var');
    elseif k_V_var && ~k_D_var
        cd('RemControl_Total_k_V_var'); 
    elseif k_V_var && k_D_var
        cd('kD-kV_final');
    else
        cd('Ec-D_final');
    end
end
%cd('RemControl_Total_vertex');
%%% calling subfolders
flist=dir();
isub=[flist.isdir];
flist=flist(isub);
nameflist={flist.name}';
flist(ismember(nameflist,{'.','..'}))=[];
nameflist=cell2mat({flist.name}');
%%%
nfile=size(flist,1);
L=cell(nfile,1);
Eval=L;
Dval=L;
kval=L;
EDval=L;
EVval=L;
if k_D_var && k_V_var
    kvalD=kval;
    kvalV=kval;
end
figure;
colors=jet(nfile);
markers={'-o';'-^';'-*';'-s';'-+';'-x';'-v';'-d'};  %%% Only works when the number of contractility/motility values is 4
markers1={'o';'^';'*';'s';'+';'x';'v';'d'};
if vertex
%     tresh1=1.4;
%     tresh2=tresh1;
    tresh1=0;
    tresh2=0.6;
else
    tresh1=0;
    tresh2=0.6;
end
for i=1:nfile
    cd(flist(i).name);
    load('tout');
    load('Ab');
    load('Mat');
    load('Set');
    if k_V_var && ~k_D_var
        a=strcat({' '},'(k_D=',num2str(Mat.D.kappaA),')');
    elseif k_D_var && ~k_V_var
        a=strcat({' '},'(k_V=',num2str(Mat.V.kappaA),')');
    elseif k_D_var && k_V_var
        a=strcat({' '},'(\epsilon^c=',num2str(Ab.Ec),',',{' '},'\delta_D=',num2str(Set.deltaD),')');
    else
        a=[];
    end
    ini=find(Ab.Vw, 1 );
    Ab.Vw(ini-1)=Ab.VWini;
    tout=tout(Ab.Vw>0);
    Ab.Vw=Ab.Vw(Ab.Vw>0);
    tout=tout(tout<=8000);
    Ab.Vw=Ab.Vw(tout<=8000);
    plot(tout,Ab.Vw,markers{1+rem(i,length(markers))},'color',colors(i,:),'LineWidth',0.5,'MarkerSize',1);
    hold on
    Eval{i}=flist(i).name(4:6);
    Dval{i}=flist(i).name(8:10);
    if k_D_var && k_V_var
        kvalD{i}=flist(i).name(12:14);
        kvalV{i}=flist(i).name(16:18);
    elseif EDEV
        EDval{i}=flist(i).name(32:34);
        EVval{i}=flist(i).name(36:38);
    else 
        kval{i}=string(str2num(flist(i).name(16:18))/str2num(flist(i).name(12:14)));
    end
    if (k_V_var && ~k_D_var) || (~k_V_var && k_D_var)
        L{i}=strcat('k_V/k_D','=',kval{i},' ','\delta_D','=',Dval{i});
    elseif k_V_var && k_D_var
        L{i}=strcat('k_D','=',kvalD{i},' ','k_V','=',kvalV{i}); 
    elseif EDEV
        L{i}=strcat('\epsilon^c_D','=',EDval{i},' ','\epsilon^c_V','=',EVval{i});  
    else
        L{i}=strcat('\epsilon^c','=',Eval{i},' ','\delta_D','=',Dval{i});
    end
    cd ..
end
xlabel('\bf{time-step}','FontSize',12);
ylabel('\bf{Wound Area}','FontSize',12);
h=legend(L{:},'Location','Northeast');
set(h,'FontSize',5);
set(gcf,'units','inches');
set(gcf,'Position',[0 0 6 4.5]);
set(gcf, 'PaperPosition', [0 0 6 4.5]);
set(gcf,'PaperSize',[6 4.5]);
set(gca,'box','off');
title(strcat('Wound Area Evolution',a));
print('WoundArea-eps','-dpdf');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% contour plots
Eval=str2num(unique(nameflist(:,4:6),'rows'));
Dval=str2num(unique(nameflist(:,8:10),'rows'));
kval=str2num(unique(nameflist(:,16:18),'rows'))./str2num(unique(nameflist(:,12:14),'rows'));
if k_D_var && k_V_var
    kvalD=str2num(unique(nameflist(:,12:14),'rows'));
    kvalV=str2num(unique(nameflist(:,16:18),'rows'));
    kvalD(kvalD==0.8)=0.75;
    kvalD(kvalD==1.2)=1.25;
    kvalD(kvalD==1.8)=1.75;
    kvalV(kvalV==0.8)=0.75;
    kvalV(kvalV==1.2)=1.25;
    kvalV(kvalV==1.8)=1.75;
    kvalV(kvalV==2.2)=2.25;
elseif EDEV
    EDval=str2num(unique(nameflist(:,32:34),'rows'));
    EVval=str2num(unique(nameflist(:,36:38),'rows'));
    EVval(EVval==0.8)=0.75;
    EDval(EDval==9.9)=10;
end
if k_D_var || k_V_var
    val.tc=zeros(size(kval,1),size(Dval,1));
elseif EDEV
    val.tc=zeros(size(EDval,1),size(EVval,1));
else
    val.tc=zeros(size(Eval,1),size(Dval,1));
end
val.ent=val.tc;
val.en=val.tc;
val.enA=val.tc;
val.enAt=val.tc;
val.nrem=val.tc;
if (k_V_var && ~k_D_var) || (~k_V_var && k_D_var)
    evo.en=cell(size(kval,1),size(Dval,1));
elseif k_V_var && k_D_var
    evo.en=cell(size(kvalV,1),size(kvalD,1));
elseif EDEV
    evo.en=cell(size(EVval,1),size(EDval,1));
else
    evo.en=cell(size(Eval,1),size(Dval,1));
end
evo.enA=evo.en;
evo.nrem=evo.en;
evo.tc=evo.en;
evo.area=evo.en;
evo.area_aux=evo.en;
if (k_V_var && ~k_D_var) || (~k_V_var && k_D_var)
    Eval=kval;
elseif k_V_var && k_D_var 
    Eval=kvalV;
    Dval=kvalD;
elseif EDEV
    Eval=EVval;
    Dval=EDval;
end
for i=1:numel(Eval)
    for j=1:numel(Dval)
        if (k_D_var || k_V_var) %|| EDEV
            if exist(nameflist(numel(Eval)*(j-1)+i,:))
                cd(nameflist(numel(Eval)*(j-1)+i,:));
            end
        elseif EDEV
            if exist(nameflist(end-numel(Eval)*i+j,:))
                cd(nameflist(end-numel(Eval)*i+j,:));
            end
        else
            if exist(nameflist(numel(Dval)*(i-1)+j,:))
                cd(nameflist(numel(Dval)*(i-1)+j,:));
            end
        end
        load('tout');
        load('Ab');
        load('nrem');
        load('ener');
        load('Set');
        load('Mat');
        %ini=find(Ab.Vw, 1 );
        Ab.Vw(ini-1)=Ab.VWini;
        %Ab.Vw=[Ab.Vw(1:ini-1);Ab.VWini;Ab.Vw(ini:end)];
        if length(tout)>length(Ab.Vw)
            %tout(end)=[];
            Ab.Vw=[Ab.Vw(1:end);0];

        end
        ener=[ener(2:end,:);ener(1,:)];
%         interval1=Ab.Vw>tresh2 & tout>=tout(Ab.Vw==max(Ab.Vw));
%         interval2=Ab.Vw>tresh2 & tout>=Ab.tAb;
        interval1=tout>=tout(Ab.Vw==max(Ab.Vw)) & ener(:,1)>0 & tout<=25000;
        %interval1= interval1 & Ab.Vw>0.1;
        %interval2=tout>=Ab.tAb & ener(:,1)>0 & tout<=25000 & Ab.Vw>0;
        interval2= ener(:,1)>0 & tout<=25000 & Ab.Vw>0;
        if ener_time
            interval=interval2;
        else
            interval=interval2;
        end
        tc=tout(interval);
        evo.tc{i,j}=tc-tc(1);
        val.tc(end-i+1,j)=tc(end)-tc(1);
        if vertex
            en=ener(interval,2);
        else
            en=sum(ener(interval,1:2),2);
        end
        evo.en{i,j}=en;
        enA=ener(interval,3);
        evo.enA{i,j}=enA;
        val.ent(end-i+1,j) =sum(en(2:end).*diff(tout(interval)));
        val.en(end-i+1,j)  =val.ent(end-i+1,j)/val.tc(end-i+1,j);
        val.enAt(end-i+1,j)=sum(enA(2:end).*diff(tout(interval)));
        val.enA(end-i+1,j)=val.enAt(end-i+1,j)/val.tc(end-i+1,j);
        val.nrem(end-i+1,j)=sum(numrem(interval));
        evo.nrem{i,j}=numrem(interval);
        evo.area{i,j}=Ab.Vw(interval);
        evo.area_aux{i,j}=evo.area{i,j};
        if evo.area{i,j}(end)>3
            val.tc(end-i+1,j)  =NaN;
            val.ent(end-i+1,j) =NaN;
            val.en(end-i+1,j)  =NaN;
            val.enAt(end-i+1,j)=NaN;
            val.enA(end-i+1,j) =NaN;
            val.nrem(end-i+1,j)=NaN;
        end
        evo.area{i,j}=100*evo.area{i,j}/evo.area{i,j}(1);
        cd ..
    end
end
if ener_time
names={'closure time';'total work';'average energy';'average area deviation energy';'area deviation energy';'number of remodellings'};
fnames={'closure_time';'total_work';'average_energy';'average_AdevEner';'AdevEner';'number_of_remodellings'};
fields=fieldnames(val);
for i=1:numel(fields)
    figure;
    b=val.(fields{i});
    imagesc(b);
    if k_V_var && k_D_var
        xlabel('\bf{k_D}','FontSize',14);
        ylabel('\bf{k_V}','FontSize',14);
    elseif EDEV
        xlabel('\bf{\epsilon^c_D}','FontSize',14);
        ylabel('\bf{\epsilon^c_V}','FontSize',14);
    else
        xlabel('\bf{\delta}','FontSize',14);
        if (k_V_var && ~k_D_var) || (~k_V_var && k_D_var)
            ylabel('\bf{k_V/k_D}','FontSize',14);
        else
            ylabel('\bf{\epsilon^c_w}','FontSize',14);
    
        end
    end
    set(gcf,'units','inches');
    set(gcf,'Position',[0 0 6 4.5]);
    set(gcf, 'PaperPosition', [0 0 6 4.5]);
    set(gcf,'PaperSize',[6 4.5]);
    set(gca,'box','off');
    % set(gca,'XAxisLocation','top');
    set(gca,'XTickLabel',Dval);
    set(gca,'XTick',1:numel(Dval));
    set(gca,'YTickLabel',strcat(num2str(Eval(end:-1:1))));
    set(gca,'YTick',1:numel(Eval));
    ax=gca;
    ax.FontSize=15;
    colorbar;
    h=colormap;
    colormap(flipud(h));
    % set(h,'YDir','reverse');
%     if i==1 
%         s='%4.2f';
%     else
        s='%4.0f';
%     end
    text(kron(1:numel(Dval),ones(1,numel(Dval)))-0.25,kron(ones(1,numel(Dval)),1:numel(Dval)),cellstr(num2str(val.(fields{i})(:),s)));
    if i<2
        b='(s)';
    else
        b=[];
    end
    %title(strcat(names{i},{' '},'contour',a,b));
    print(fnames{i},'-dpdf');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% energy evolution plots
colors=jet(numel(Dval));
    if Dvalcompare   % Dvalcompare=~Evalcompare
        irange=numel(Eval);
        jrange=numel(Dval);
    else
        irange=numel(Dval);
        jrange=numel(Eval);
        evo.tc=evo.tc';
        evo.en=evo.en';
        evo.nrem=evo.nrem';
        evo.area=evo.area';
        evo.area_aux=evo.area_aux';
    end
    for i=irange:-1:1 %i=1:irange
        figure;
        L=cell(jrange,1);
        s=false(jrange,1);
        maxntick=0;
        for j=jrange:-1:1 %j=1:jrange
            %s(1)=subplot(2,1,2);
            if evo.area_aux{i,j}(end)<3
            if plot_remodel
            yyaxis left
            end
            plot(evo.tc{i,j}(2:end),evo.en{i,j}(2:end),markers{j},'color',colors(j,:),'LineWidth',2,'MarkerSize',2);
            ylabel('\bf{W_E}','Fontsize',14)
            hold on
            %s(2)=subplot(2,1,1);
            %yyaxis left
            %p=plot(evo.tc{i,j}(2:end),diff(evo.en{i,j}),markers{j},'color',colors(j,:),'LineWidth',2,'MarkerSize',2);
            %ylabel('\bf{\delta{E}}','FontSize',12);
            if plot_remodel
            hold on
            yyaxis right
            %b=stem(evo.tc{i,j},evo.nrem{i,j},'color',colors(j,:),'LineWidth',2,'MarkerFaceColor',colors(j,:));
            b=plot(evo.tc{i,j}(evo.nrem{i,j}>0),evo.nrem{i,j}(evo.nrem{i,j}>0),markers1{j},'color',colors(j,:),'LineWidth',1);
            ylabel('\bf{# of remodellings}','FontSize',14);
            maxnrem=max(evo.nrem{i,j});
            maxntick=max([maxntick maxnrem 1]);
            end
            if Dvalcompare
                if k_V_var && k_D_var
                    L{j}=strcat('k_D=',num2str(Dval(j),'%1.2f\n'));
                elseif EDEV
                    L{j}=strcat('\epsilon^c_D=',num2str(Dval(j),'%1.2f\n'));
                else
                    L{j}=strcat('\delta=',num2str(Dval(j),'%1.1f\n'));
                end
            else
                if k_V_var && k_D_var
                    L{j}=strcat('k_V=',num2str(Eval(j),'%1.2f\n'));
                elseif EDEV
                    L{j}=strcat('\epsilon^c_V=',num2str(Eval(j),'%1.2f\n'));
                else
                    L{j}=strcat('\epsilon^c_w=',num2str(Eval(j),'%1.1f\n'));
                end                
            end
            else
                s(j)=true;
            end
        end
        L(s)=[];
        if plot_remodel
        set(gca,'YLim',[0 maxntick]);
        set(gca,'YTickLabel',0:maxntick);
        set(gca,'YTick',0:maxntick);
        end
        xlabel('\bf{time(s)}','FontSize',15);
        if ~(k_D_var && k_V_var)
            locL='Northeast';
        else
            locL='Southeast';
        end
        h=legend(L{end:-1:1},'Location',locL);
        set(h,'FontSize',15);
        set(gcf,'units','inches');
        set(gcf,'Position',[0 0.03 6 3.25]);
        set(gcf, 'PaperPosition', [0 0 6 3.25]);
        set(gcf,'PaperSize',[6 3.28]);
        ax=gca;
        ax.FontSize=15;
        %%set(gca,'box','off');
        %title(strcat('\delta{E} evolution,',{' '},'\epsilon^c_w=',num2str(Eval(i),'%1.1f\n')));
        if Dvalcompare
            if (k_V_var && ~k_D_var) || (~k_V_var && k_D_var)
                %title(strcat('Energy evolution,',{' '},'{k_V/k_D}=',num2str(Eval(i),'%1.1f\n'),',',a));
                print(strcat('ener_evol_','k_v/k_D',num2str(Eval(i),'%1.1f\n')),'-dpdf');
            elseif k_V_var && k_D_var
                %title(strcat('Energy evolution,',{' '},'{k_V}=',num2str(Eval(i),'%1.2f\n'),',',a));
                print(strcat('ener_evol_','k_V',num2str(Eval(i),'%1.2f\n')),'-dpdf');
            elseif EDEV
                print(strcat('ener_evol_','E_V',num2str(Eval(i),'%1.2f\n')),'-dpdf');
            else
                %title(strcat('Energy evolution,',{' '},'\epsilon^c_w=',num2str(Eval(i),'%1.1f\n')));
                print(strcat('ener_evol_','epsw',num2str(Eval(i),'%1.1f\n')),'-dpdf');
            end
        else
            if (k_V_var && ~k_D_var) || (~k_V_var && k_D_var)
                %title(strcat('Energy evolution,',{' '},'\delta=',num2str(Dval(i),'%1.1f\n'),',',a));
                print(strcat('ener_evol_','del',num2str(Dval(i),'%1.1f\n')),'-dpdf');
            elseif k_V_var && k_D_var
                %title(strcat('Energy evolution,',{' '},'{k_D}=',num2str(Dval(i),'%1.2f\n'),',',a));
                print(strcat('ener_evol_','k_D',num2str(Dval(i),'%1.2f\n')),'-dpdf');
            elseif EDEV
                print(strcat('ener_evol_','E_D',num2str(Dval(i),'%1.2f\n')),'-dpdf');
            else
                %title(strcat('Energy evolution,',{' '},'\delta=',num2str(Dval(i),'%1.1f\n')));
                print(strcat('ener_evol_','del',num2str(Dval(i),'%1.1f\n')),'-dpdf');
            end
        end 
        %print(strcat('delta_ener_evol_',num2str(Eval(i),'%1.1f\n')),'-dpdf');
        %print(strcat('ener_evol_',num2str(Eval(i),'%1.1f\n')),'-dpdf');
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Area-Energy plots
else
    if Dvalcompare   % Dvalcompare=~Evalcompare
        irange=numel(Eval);
        jrange=numel(Dval);
    else
        irange=numel(Dval);
        jrange=numel(Eval);
        evo.area=evo.area';
        evo.en=evo.en';
        evo.nrem=evo.nrem';
        evo.area_aux=evo.area_aux';
    end    
    colors=jet(jrange);
    for i=1:irange
        figure;
        L=cell(jrange,1);
        s=false(jrange,1);
        maxntick=0;
        for j=1:jrange
            if evo.area_aux{i,j}(end)<3
            if plot_remodel
            yyaxis left
            end
            p=plot(evo.area{i,j}(2:end),evo.en{i,j}(2:end),markers{j},'color',colors(j,:),'LineWidth',2,'MarkerSize',2);
            ylabel('\bf{W_E}','FontSize',14);
            hold on
            if plot_remodel
            hold on
            yyaxis right
            %b=stem(evo.area{i,j},evo.nrem{i,j},'color',colors(j,:),'LineWidth',2,'MarkerFaceColor',colors(j,:));
            nrem=evo.nrem{i,j};
            b=plot(evo.area{i,j}(nrem>0),nrem(nrem>0),'*','color',colors(j,:));
            ylabel('\bf{# of remodellings}','FontSize',14);
            maxnrem=max(evo.nrem{i,j});
            maxntick=max([maxntick maxnrem 1]);
            end
            if Dvalcompare
                if k_V_var && k_D_var
                    L{j}=strcat('{k_D}=',num2str(Dval(j),'%1.2f\n')); 
                elseif EDEV
                    L{j}=strcat('\epsilon^c_D=',num2str(Dval(j),'%1.2f\n'));
                else
                    L{j}=strcat('\delta=',num2str(Dval(j),'%1.1f\n'));
                end
            else
                if k_V_var && k_D_var
                    L{j}=strcat('{k_V}=',num2str(Eval(j),'%1.2f\n'));
                elseif EDEV
                    L{j}=strcat('\epsilon^c_V=',num2str(Eval(j),'%1.2f\n'));
                else
                    L{j}=strcat('\epsilon^c_w=',num2str(Eval(j),'%1.1f\n'));
                end
            end
            else
                s(j)=true;
            end
        end
        L(s)=[];
        if plot_remodel
        set(gca,'YTickLabel',0:maxntick);
        set(gca,'YTick',0:maxntick);
        if sum(nrem>0)>0 || Dvalcompare
            set(gca,'Ylim',[0 maxntick]);
        end
        end
        xlabel('\bf{area(%)}','FontSize',14);
        if (k_V_var && k_D_var) || EDEV
            locL='Northwest';
        else
            locL='Northeast';
        end
        h=legend(L{:},'Location',locL);
        set(h,'FontSize',15);
        set(gcf,'units','inches');
        set(gcf,'Position',[0 0 6 4.5]);
        set(gcf, 'PaperPosition', [0 0 6 4.5]);
        set(gcf,'PaperSize',[6 4.5]);
        ax=gca;
        ax.FontSize=15;
        %set(gca,'box','off');
        if Dvalcompare
            if k_V_var && k_D_var
                %title(strcat('Energy-Area,',{' '},'{k_V}=',num2str(Eval(i),'%1.2f\n')));
                print(strcat('ener_area_','k_V',num2str(Eval(i),'%1.2f\n')),'-dpdf');
            elseif EDEV
                print(strcat('ener_area_','E_V',num2str(Eval(i),'%1.2f\n')),'-dpdf');
            else
                %title(strcat('Energy-Area,',{' '},'\epsilon^c_w=',num2str(Eval(i),'%1.1f\n')));
                print(strcat('ener_area_','epsw',num2str(Eval(i),'%1.1f\n')),'-dpdf');
            end      
        else
            if k_V_var && k_D_var
                %title(strcat('Energy-Area,',{' '},'{k_D}=',num2str(Dval(i),'%1.2f\n')));
                print(strcat('ener_area_','k_D',num2str(Dval(i),'%1.2f\n')),'-dpdf');
            elseif EDEV
                 print(strcat('ener_area_','E_D',num2str(Dval(i),'%1.2f\n')),'-dpdf'); 
            else
                %title(strcat('Energy-Area,',{' '},'\delta=',num2str(Dval(i),'%1.1f\n')));
                print(strcat('ener_area_','del',num2str(Dval(i),'%1.1f\n')),'-dpdf'); 
            end
        end
    end
end
cd ..
cd ..