function [V] = FindSeedLumen(lnod, lnodExternal, lnod_vor,  Vor)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function finds the node that needs to be splitted in order to create the lumen. First all of the elements at the boundary need to be
% screened, in these elements the nodes that have two neighbors have to be put in a list. Substract the nodes that are in lnodExternalVor. This
% creates a list with nodes inside the network. Find the new neighbours of the nodes, delete (1) if they are in old list (2) delete if they are in 
% lnodExternalVor. Do this until no new neighbours can be found --> creates final list. If list >1 node, take node closest to center of network. 

k = 1;
lnod_next = [];
lnod_firstline = [];
index = [];

%Find voronoi external boundaries
[~,indices] = ismember(lnodExternal, lnod, 'rows');
lnod_vorexternal = lnod_vor(indices,:);

%Find nodes on the first line that are connected to these boundaries
lnod_firstline = unique(lnod_vorexternal(:,1));
index1 = find(lnod_vor(:,1)==lnod_firstline(1));
index2 = find(lnod_vor(:,2)==lnod_firstline(1));
index = [index1;index2];
    
for i = 2:length(lnod_firstline)
    ix = find(lnod_vor(:,1) == lnod_firstline(i));
    ix2 = find(lnod_vor(:,2) == lnod_firstline(i));
    index(end+1:end+(length(ix)+length(ix2)),1) = [ix; ix2];
end

lnod_vor_check = lnod_vorexternal;

%After finding first connection a while loop is created to keep looping
%until there are no neighbors found (lnod_next = []). Each loop it is
%checked if the nodes are (1) not on the boundary and (2) not in the
%previous list.
while k > 0
    j=1;
    lnod_next=[];
    %See if nodes are not on the boundary and not in the previous list.
    for i = 1:length(index)
            if  ismember(lnod_vor(index(i),:),lnod_vor_check,'rows') == 0
                if ismember(lnod_vor(index(i),:),lnod_vorexternal, 'rows') == 0
                    lnod_next(j,:)=(lnod_vor(index(i),:));
                    j=j+1;
                end
            end
    end
    lnod_vor_check = lnod_next;
    lnod_next = unique(lnod_next);

    for i = length(lnod_next):-1:1
        if find(lnod_next(i) == lnod_firstline) ~=0
            lnod_next(i) = [];
        end
    end

    if isempty(lnod_next) == 1 
        k = 0;
    else
        k = 1;
        
        %Find neighbors of the next nodes
        lnod_firstline = lnod_next; 
        index = [];
        index1 = find(lnod_vor(:,1)==lnod_firstline(1));
        index2 = find(lnod_vor(:,2)==lnod_firstline(1));
        index = [index1;index2];

        for i = 2:length(lnod_firstline)
            ix1 = find(lnod_vor(:,1) == lnod_firstline(i));
            ix2 = find(lnod_vor(:,2) == lnod_firstline(i));
            index(end+1:end+(length(ix1)+length(ix2)),1) = [ix1; ix2];
        end
    end
          
end

Middle_nodes = lnod_firstline;

%If >1 vertex is over then calculate the center of the network and take the
%closest point. 

if length(Middle_nodes)>1
    center = [sum(Vor(:,1))/length(Vor), sum(Vor(:,2))/length(Vor)];
    d = zeros(length(Middle_nodes),1);
    for i = 1:length(Middle_nodes)
        d(i,1) = sqrt((Vor(Middle_nodes(i),1)-center(1,1))^2 + (Vor(Middle_nodes(i),2) - center(1,2))^2);
    end
    x = d == min(d);
    V = Middle_nodes(x);
else
    V = Middle_nodes(1);
end



end
    


    



