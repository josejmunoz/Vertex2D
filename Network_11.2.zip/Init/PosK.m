function K=PosK(K,dof)
% Sets zero diagonal terms to 1 in order to avoid singular matrices
% this may happen for systmes with no Delaunay stiffnes
for i=1:length(dof)
    if abs(K(dof(i),dof(i)))<eps
        K(dof(i),dof(i))=1;
    end
end
