function [Vor,lnod_vor,vor_cell,celledge,edgesize,celledgeW,vor_cellW,remnod]=DefineExtVertex(X,Vor,Vorpp,vor_cell,lnod,lnodp,lnodExternal,lnodW,lnodExternalp,lnodWp,lnod_vor,lnod_vorp,nodB,celledgep,Set,r,Sp,inc)
alpha=Set.alpha;
sizeb=length(nodB);
sizeV=size(Vor,1);
sizelnodV=size(lnod_vor,1);
sizelnodp=size(lnodp,1);
sizeExtp=size(lnodExternalp,1);
celledge=cell(sizeb,1);
edgesize=celledge;
if sizeExtp<1
    lnodExternalp=zeros(0,2);
end
for i=1:sizeb
    [I,n]=ismember([lnod(end-i+1,:);lnod(end-i+1,[2 1])],lnodExternalp,'rows');
    if sum(I)<1
        X1=X(lnod(end-i+1,1),:);
        X2=X(lnod(end-i+1,2),:);
        V1=Vor(lnod_vor(sizelnodV-i+1,1),:);
        Xh=([X2(1)-X1(1) X2(2)-X1(2);X2(2)-X1(2) X1(1)-X2(1)]/((X2(1)-X1(1))^2+(X2(2)-X1(2))^2))*...
            [(X2(1)-X1(1))*V1(1)+(X2(2)-X1(2))*V1(2);(X2(2)-X1(2))*X1(1)+(X1(1)-X2(1))*X1(2)];
        V2=2*Xh'-V1+[eps eps];
    else
        n=n(I);
        %V1=Vor(lnod_vor(sizelnodV-i+1,1),:);
        %%V1=Vorpp(lnod_vorp(sizelnodp-sizeExtp+n,1),:);
        V2=Vorpp(lnod_vorp(sizelnodp-sizeExtp+n,2),:);%+V1-Vorpp(lnod_vorp(sizelnodp-sizeExtp+n,1),:);
    end
    Vor(lnod_vor(sizelnodV-i+1,2),:)=V2;
end
indV=0;
indlnodV=sizelnodV;
Xc=zeros(sizeb,2);
if r  %% wounding increment
    lnodExternalp=lnodExternalp(1:sizeExtp-size(lnodWp,1),:);
end
nodBp=sort(lnodExternalp(:,1));
[~,locb]=ismember(nodB,nodBp);
if inc>1
    elep=lnodp(~ismember(sort(lnodp,2),sort(lnod,2),'rows'),:);
    ele =lnod(~ismember(sort(lnod,2),sort(lnodp,2),'rows'),:);
    remnod=unique([elep(:,1);elep(:,2);ele(:,1);ele(:,2)]);
else
    remnod=[];
end
isWedge=ismember(nodB,lnodW(:,1));
for i=1:sizeb
    lnodext_aux=lnodExternal(lnodExternal(:,1)==nodB(i) | lnodExternal(:,2)==nodB(i),:);
    if (sum(ismember(lnodext_aux,lnodExternalp,'rows'))>1 && locb(i)>0) && ~ismember(nodB(i),remnod)
        nv               =length(celledgep{locb(i)});
        vcellaux         =zeros(nv,1);
        Voraux           =Vorpp(lnod_vorp(celledgep{locb(i)}(1:end-1),2),:);
        vcellaux(1:end-1)=sizeV+sizeb+(indV+1:indV+nv-1);
        vcellaux(end)    =vor_cell{nodB(i)}(1);
        if nv>1
            lnodvaux     =[vor_cell{nodB(i)}(end) sizeV+sizeb+indV+1;sizeV+sizeb+(indV+1:indV+nv-2)' sizeV+sizeb+(indV+2:indV+nv-1)';sizeV+sizeb+indV+nv-1 vor_cell{nodB(i)}(1)];
        else
            lnodvaux     =[vor_cell{nodB(i)}(end) vor_cell{nodB(i)}(1)];
        end
        indV             =indV+nv-1;
    else
        if inc<1
            V0=Vor(vor_cell{nodB(i)}(2),:);
            V1=Vor(vor_cell{nodB(i)}(1),:);
            V2=Vor(vor_cell{nodB(i)}(end),:);
            P1=(V1+V0)/2;
            P2=(V2+V0)/2;
            m1=(V0(1)-V1(1))/(V1(2)-V0(2));
            if abs(m1)==Inf
                m1=(V0(1)-V1(1))/(V1(2)-V0(2)+eps*1e12);
            end
            m2=(V0(1)-V2(1))/(V2(2)-V0(2));
            if abs(m2)==Inf
                m2=(V0(1)-V2(1))/(V2(2)-V0(2)+eps*1e12);
            end
            Xc(i,:)=([-1  1;-m2 m1]*[m1*P1(1)-P1(2);m2*P2(1)-P2(2)]/(m2-m1))';
            rc=norm(Xc(i,:)-V0);
        else
            [Xc(i,:),rc]=DefineCentre(Vor,Sp(nodB(i)),vor_cell{nodB(i)});
        end
        V1=Vor(vor_cell{nodB(i)}(1),:)-Xc(i,:);
        V2=Vor(vor_cell{nodB(i)}(end),:)-Xc(i,:);
        a1=norm(V1);
        a2=norm(V2);
        c=V2(1)*V1(2)-V2(2)*V1(1);
        ang=acos(min(1,max(-1,sum(V1.*V2)/(a1*a2))));
        if c<0 
            ang=2*pi-ang;
        end
        if inc>35
            nv=1;
        else
            nv=floor(alpha*rc*ang/(2*pi));
        end
        if nv<1
            nv=1;
        end
        ang1=ang/nv;
        numV=nv-1;
        bb=1;
        vcellaux=zeros(nv,1);
        Voraux=zeros(numV,2);
        lnodvaux=zeros(nv,2);
        Vinit=vor_cell{nodB(i)}(end);
        while numV>0
            indV=indV+1;
            cs=cos(ang1);
            sn=sqrt(1-cs^2);
            V=[-V2(2) V2(1);V2(1) V2(2)]*[sn;cs]*rc/a2;
            V=V';
            V2=V;
            a2=norm(V2);
            Vaux=V+Xc(i,:);
            vcellaux(bb)=sizeV+sizeb+indV;
            Voraux(bb,:)=Vaux;
            lnodvaux(bb,:)=[Vinit vcellaux(bb)];
            Vinit=vcellaux(bb);
            numV=numV-1;
            bb=bb+1;
        end
        lnodvaux(end,:)=[Vinit vor_cell{nodB(i)}(1)];
        vcellaux(end)=vor_cell{nodB(i)}(1);
    end
    Vor=[Vor;Voraux];
    vor_cell{nodB(i)}=[vor_cell{nodB(i)};vcellaux];
    lnod_vor=[lnod_vor;lnodvaux];
    celledge{i}=indlnodV+(1:nv);
    edgesize{i}=nv*ones(nv,1);
    indlnodV=indlnodV+nv;
end 
celledgeW=cell2mat(celledge(isWedge)');
edgesize =cell2mat(edgesize);
if ~isempty(celledgeW)
    lnodvW=lnod_vor(celledgeW,:);
    lnodvaux=zeros(size(lnodvW));
    lnodvaux(1,:)=lnodvW(1,:);
    lnodvW(1,:)=[];
    for i=1:length(celledgeW)-1
        I= lnodvW(:,1)==lnodvaux(i,2);
        lnodvaux(i+1,:)=lnodvW(I,:);
        lnodvW(I,:)=[0 0];
    end
    lnodvW=lnodvaux(end:-1:1,[2 1]);
    vor_cellW=[lnodvW(:,1);lnodvW(1,1)];
else
    vor_cellW=[];
end
end
function [Xc,r]=DefineCentre(Vor,Sp,vcell)
% This function defines area-adapted curves for boundary cells, so the
% cell area is preserved as a bulk cell turns into a boundary cell, by
% remodelling/wounding
V1=Vor(vcell(1),:);
V2=Vor(vcell(end),:);
S1=0;
for i=1:length(vcell)-1
    S1=S1+0.5*det([Vor(vcell(i),:);Vor(vcell(i+1),:)]);  %%calculating volume of open cell i without curve
end
S1=S1+0.5*det([V2;V1]);
Sw=Sp-S1; %% area of the removed segment (reference area - remaining area)
if Sw<1e-10*Sp
    r=0;
    Xc=[0 0];
else
    P=(V1+V2)/2;
    b=norm(V2-V1)/2;
    t=(V2-V1)/(2*b);
    n=[t(2) -t(1)]; %% inward normal
%     if Sw<0
%         n=-n;
%         Sw=-Sw;
%     end
    if Sw>0.5*pi*b^2
        h=0;
        r=b;
    else
        % Newton-Raphson
        r=1.1*b;
        h=sqrt(r^2-b^2);
        s=r^2*asin(b/r)-b*sqrt(r^2-b^2)-Sw;
        Ks=2*h*(r*asin(b/r)-b/sqrt(1-(b/r)^2))/r;
        while abs(s)>1e-10
            dh=-s/Ks;
            h=h+dh;
            r=sqrt(h^2+b^2);
            s=r^2*asin(b/r)-b*sqrt(r^2-b^2)-Sw;
            Ks=2*(r*asin(b/r)-b/sqrt(1-(b/r)^2))*h/r;
        end
    end
    Xc=P+abs(h)*n;
end
end