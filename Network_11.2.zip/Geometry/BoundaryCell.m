function [vcell,cc]=BoundaryCell(i,cc,FE,lnod_ext)
cc=cc+1;
s=[2 3;3 1;1 2];
ss=[1 2;3 1;2 3];
sizet=size(FE,1);
nt=1:sizet;
sizeb=size(lnod_ext,1);
a= FE(:,1)==i | FE(:,2)==i | FE(:,3)==i;
vcell=nt(a); %%index of triangles around boundary node i
[at,bt]=ismember(vcell,lnod_ext(:,1));
diffext=diff(lnod_ext(:,1));
ind=bt(at);
for jj=1:length(ind)
    ext=FE(lnod_ext(ind(jj),1),ss(lnod_ext(ind(jj),2),:));
    if ~ismember(i,ext)
        if ind(jj)<sizeb && abs(diffext(ind(jj)))<eps
            ind(jj)=ind(jj)+1;
        else
            ind(jj)=0;
        end
    end
end
vcellb=vcell(at); %%index of triangles around node i at the boundary
vcellb(ind==0)=[];
ind(ind==0)=[];
if length(vcell)>1
    vcell_aux=zeros(length(vcell),1);
    b= FE(vcellb(1),:)==i;
    lnod=FE(vcellb(1),s(b,:));
    vcell_aux(1)=vcellb(1);
    vcell(vcell==vcellb(1))=[];
    a=2;
    while ~isempty(vcell)
        %%searching for cell connectivity in counter-clockwise direction
        r=false;
        c= FE(vcell,1)==lnod(2) | FE(vcell,2)==lnod(2) | FE(vcell,3)==lnod(2);
        if sum(c)<1
            r=true;
            %%searching for cell connectivity in clockwise direction
            c= FE(vcell,1)==lnod(1) | FE(vcell,2)==lnod(1) | FE(vcell,3)==lnod(1);
        end
        b= FE(vcell(c),:)==i;
        lnod=FE(vcell(c),s(b,:));
        vcell_aux(a)=vcell(c);
        vcell(c)=[];
        a=a+1;
    end
    vcell=vcell_aux;
    if r
        vcell=vcell(end:-1:1);
    end
else
    ind=[ind ind+1];
end
for j=1:length(ind)
    ext=FE(lnod_ext(ind(j),1),ss(lnod_ext(ind(j),2),:));
%     if ind(j)<sizeb && abs(diffext(ind(j)))<eps
%        if ~ismember(i,ext)
%            ind(j)=ind(j)+1;
%            ext=FE(lnod_ext(ind(j),1),ss(lnod_ext(ind(j),2),:));
%        end
%     end 
    if ext(1)==i
    vcell=[ind(j)+sizet;vcell];
    elseif ext(2)==i
    vcell=[vcell;ind(j)+sizet];
    end
end
% indVout=sizet+sizeb+cc;
% vcell=[indVout;vcell;indVout];
end
