function [ln]=Reorderln(X,V,ln,E,Ep,EV,EVp,Mat)  
%%% reorders lengths after remodelling according to array c
% INPUT:
% c= array if reordering indeces in vertex network after remodelling
Eaux=sort(E,2);
Epaux=sort(Ep,2);
% EVaux=sort(EV,2);
% EVpaux=sort(EVp,2);
[a,b]=ismember(Eaux,Epaux,'rows');
% Delaunay
Ec =ln.D.n1.A.c;
ln.D.n1.A.c=zeros(size(E,1),1);
ln.D.n1.A.c(a)=Ec(b(a));
ln.D.n1.A.c(~a)=Mat.D.Ec0A; % New elements: assign initial contractility
ln.D.n.A.c =ln.D.n1.A.c;
% Del, branch B
Ec =ln.D.n1.B.c;
ln.D.n1.B.c=zeros(size(E,1),1);
ln.D.n1.B.c(a)=Ec(b(a));
ln.D.n1.B.c(~a)=Mat.D.Ec0B; 
ln.D.n.B.c =ln.D.n1.B.c;
% Del, branch B
Ec =ln.D.n1.S.c;
ln.D.n1.S.c=zeros(size(E,1),1);
ln.D.n1.S.c(a)=Ec(b(a));
ln.D.n1.S.c(~a)=Mat.D.Ec0; 
ln.D.n.S.c =ln.D.n1.S.c;
% Vertex
% EcV=ln.V.n1.A.c;
% epsV=EcV(c);
epsV=ln.V.n1.A.c;
if size(E,1)>size(EV,1)  %%when Set.Bcells=-1, size(EV,1)>size(E,1)
    [a,b]=ismember(Eaux(1:size(EV,1),:),Epaux(1:size(EVp,1),:),'rows');
else
    ln.V.n1.A.c(length(a)+1:end)=Mat.V.Ec0A;
    ln.V.n1.B.c(length(a)+1:end)=Mat.V.Ec0B;
    ln.V.n1.S.c(length(a)+1:end)=Mat.V.Ec0;
end
ln.V.n1.A.c=zeros(size(EV,1),1);
ln.V.n1.A.c(a)=epsV(b(a));
ln.V.n1.A.c(~a)=Mat.V.Ec0A;
ln.V.n.A.c =ln.V.n1.A.c;
% Vert, branch B
ln.V.n1.B.c=zeros(size(EV,1),1);
ln.V.n1.B.c(a)=epsV(b(a));
ln.V.n1.B.c(~a)=Mat.V.Ec0B;
ln.V.n.B.c =ln.V.n1.B.c;
% Vert, branch Spring
ln.V.n1.S.c=zeros(size(EV,1),1);
ln.V.n1.S.c(a)=epsV(b(a));
ln.V.n1.S.c(~a)=Mat.V.Ec0;
ln.V.n.S.c =ln.V.n1.S.c;
%
ln.V.n.S.e=sqrt(sum((V(EV(:,2),:)-V(EV(:,1),:)).^2,2));
ln.V.n.A.e=ln.V.n.S.e;
ln.V.n.B.e=ln.V.n.S.e;
%
ln.D.n.S.e=sqrt(sum((X(E(:,2),:)-X(E(:,1),:)).^2,2));
ln.D.n.A.e=ln.D.n.S.e;
ln.D.n.B.e=ln.D.n.S.e;
end
