function [e,Ec1,err,g,K,lrn1,Eps,ln1,G]=ActiveLineElem(beta,nDelay,dt,Ec0,Ec,err,Gamma,kappa,ld,lrn,tAb,theta,x,xp,x0,Set)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Elemental subroutine for bar elements
% OUTPUT:
% g= residual vector with elastic forces
% K = Stiffness matrix
% lrn  = Reference length at previous time-step t_n
% lrn1 = Reference length at current time-step t_{n+1}
% Eps  = elastic strain
% Ec   = Contractility. If beta>0, it follows the evolution law:
%
%   dot eps_c=-beta*k*(eps_c-eps_c^0)^alpha
%
% INPUT:
% Ec     =contractile strain.
% GammaA = remodelling rate. =0 Elastic bar, Gamma<>0, Linear active bar,
% with law,
%                 dot L=(l-L-L*Ec)*Gamma
% ld  = ld.L and ld.l =Rest and apparent length at delayed time
% lrn = Reference length (different from l0 if Gamma/=0)
% poly_elas =true: consider polynomial elastic law: g=k*eps^2
% x,xp,x0   =row vector [x1 x2] with current, previous and initial
%            positions of nodes 1 and 2
% theta     = time integration parameter. theta=0 Forward Euler.
tolL=1e-10; % Tolerance for 0 length
poly=false;
across=false; % true: eps_c is made dependent on strain across edge
              % false: eps_c is made dependent on strain tangent to the
              % edge (same element)
alpha=1; % Parameter for time evolution of contractility of eps_c when beta>0
if isfield(Set,'poly_elas')
    poly=Set.poly_elas;
end
dim=length(x)/2;
x12=zeros(2*dim,1);
gamma =zeros(2*dim,2*dim);
gamma(1:dim,1:dim)=eye(dim);
gamma(1:dim,dim+1:2*dim)=-eye(dim);
gamma(dim+1:2*dim,1:dim)=-eye(dim);
gamma(dim+1:2*dim,dim+1:2*dim)=eye(dim);
ln1=norm(x(1:dim)-x(dim+1:2*dim));
x12(1:dim,1)=x(1:dim)-x(dim+1:2*dim);
if abs(ln1)<eps
    x12(1)=1;
else
    x12=x12/ln1;
end
x12(dim+1:2*dim,1)=-x12(1:dim,1);
ln=norm(xp(1:dim)-xp(dim+1:2*dim));
if beta>eps
    [Ec1,lrn1,err]=UpdateEcLr(across,alpha,beta,dt,Ec,Ec0,err,Gamma,kappa,ln,ln1,lrn,tAb,theta);
else
    Ec1=Ec;
end
% Define A such that d epsC / dx = A*x12
if abs(Gamma)<tolL
    ln0=norm(x0(1:dim)-x0(dim+1:2*dim));
    lrn1=ln0;
    if abs(ln0)<tolL
        A=1;
    else
        A=1/lrn1;
    end
    dLdl=0;
else
    lnt=(1-theta)*ln+theta*ln1;
    if beta<eps
        Ec1=Ec;
        if nDelay>0
            dLdl=0;
            lrn1=lrn+dt*Gamma*(ld.l-ld.L*(1+Ec1));
        else
            dLdl=1/(1+theta*dt*(1+Ec1)*Gamma)*dt*Gamma*theta;
            lrn1=1/(1+theta*dt*(1+Ec1)*Gamma)*(lrn+ dt*Gamma*lnt-(1-theta)*dt*(1+Ec1)*Gamma*lrn);
        end
    else
        dLdl=0;
    end
    if abs(lrn1)<tolL
        A=1;
    elseif Set.DispBased
        A=(1-dLdl);
    else
        A=(1-dLdl*ln1/lrn1)/lrn1;
    end
end
if abs(lrn1)<tolL && ~Set.DispBased
    Eps=0;
    EpsC=0; 
else
    if Set.DispBased
        Eps=ln1-lrn1;
    else
        Eps=(ln1-lrn1)/lrn1;  % strain for elastic energy (contractillity excluded)
    end
    if abs(Gamma)<tolL
        EpsC=Eps+Ec1; % contractility added also in Spring branch if not Active branch
    else
        EpsC=Eps;
    end
end
% Self-regulated and non-self-regulated cases
if poly %exponential/polynomial elasticity
    gA=EpsC;
    Ke=EpsC*(2/lrn1-EpsC/ln1)*(x12)*x12'+EpsC^2/ln1*gamma;
    e=0.5*Eps^3*kappa/3;
elseif Set.enerM==0 % elastic force is k*eps along bar direction
    gA=1;
    if abs(ln1)<eps
        Ke=gamma;
    else
        Ke=(A-EpsC/ln1)*(x12)*x12'+EpsC/ln1*gamma;
    end
%     e=0.5*Eps^2*kappa;
    e=0.5*Eps^2*kappa*ln1;
elseif Set.enerM==1 % elastic force is min E_elastic wrt position x. E_elast=0.5*k*eps^2, specific energy (TRUE minimisation)
    gA=A;
    if abs(lrn1)<eps
        dA=0;
        Ke=zeros(2*dim);
    else
        if Set.DispBased
            dA=0;
        else
            dA=2*ln1/lrn1^3*dLdl^2-2/lrn1^2*dLdl;
        end
        Ke=-EpsC*A/ln1*(x12)*x12' + A*EpsC/ln1*gamma;
    end
    Ke=Ke+(A^2+EpsC*dA)*(x12)*x12';
    e=0.5*Eps^2*kappa;
else  % elastic force is min E_elastic wrt position x. E_elast=0.5*k*eps^2*ln1, total energy (TRUE minimisation)
    gA=ln1*A+EpsC/2;
    if abs(lrn1)<eps
        dA=0;
        Ke=zeros(2*dim);
    else
        if Set.DispBased
            dA=0;
        else
            dA=2*ln1/lrn1^3*dLdl^2-2/lrn1^2*dLdl;
        end
        Ke=-EpsC*A/ln1*(x12)*x12' + A*EpsC/ln1*gamma;
    end
    gAA=EpsC*A*x12;
    Ke=Ke+(A^2+EpsC*dA)*(x12)*x12' ;
    Ke=Ke*ln1+gAA*x12'+x12*gAA';
    if abs(ln1)>eps
        Ke=Ke+EpsC^2/2/ln1*(gamma-(x12)*x12');
    end
    e=0.5*Eps^2*kappa*ln1;
end
g=kappa*EpsC*gA*x12;
G=g(1:dim)'*x12(1:dim);
K=kappa*Ke;
% Correct stiffness matrix due to static condensation of elemental Ec and lr
if beta>eps
    if Set.enerM==0
        Kxp=kappa*[-ln1/lrn1^2*x12 x12];
    elseif Set.enerM==1
        Kxp=kappa/lrn1*[-(EpsC+ln1/lrn1)/lrn1*x12 x12];
    else
        Kxp=kappa*[-(2*EpsC+ln1/lrn1)*ln1/lrn1^2*x12 (EpsC+ln1/lrn1)*x12];
    end
    if Gamma>0 % When gamma>0, dependence of g on \eps_c is removed
        Kxp(:,end)=0;
    end
    lrnt=(1-theta)*lrn+theta*lrn1;
    Kpx=[-dt*Gamma*theta*x12'
        dt*beta*kappa*theta*alpha*(Ec0+1-lnt/lrnt)^(alpha-1)/lrnt*x12'];
    if tAb>=1 && across
        Kpx(2,:)= 0;
    end
    [Kpp,gp]=KgEcL(across,alpha,beta,dt,Ec,Ec0,Ec1,Gamma,kappa,ln,ln1,lrn,lrn1,tAb,theta);
    K=K-Kxp*(Kpp\Kpx);
    g=g-Kxp*(Kpp\gp); %Unnecessary since gp=0 after update of Lrn1 and Ec1
end
end