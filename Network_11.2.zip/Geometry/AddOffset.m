function [X,X_off]=AddOffset(X,lnodExternal)
% Adds Offset to node coordinates X according to lnodExternal
%%%%%%%%% Does not work in 3D
l_avg=mean(sqrt(sum([X(lnodExternal(:,2),1)-X(lnodExternal(:,1),1) X(lnodExternal(:,2),2)-X(lnodExternal(:,1),2)].^2,2)));
q=[X(lnodExternal(:,2),2)-X(lnodExternal(:,1),2) X(lnodExternal(:,1),1)-X(lnodExternal(:,2),1)];
normq=sqrt(sum((q).^2,2));
q=[q(:,1)./normq q(:,2)./normq]*l_avg;
X_off_in=[X(lnodExternal(:,1),:)+q;X(lnodExternal(:,2),:)+q];
%%%%%%%%%
% X_off=X_off_in(ia,:);
X_off=unique(X_off_in,'rows');
X=[X;X_off];
end