function [Ec1, lr1,err] = UpdateEcLr(across,alpha,beta,dt,Ec,Ec0,err,gamma,kappa,ln,ln1,lr,t,theta)
% INPUT:
% beta : material parameter for contractility self-regulation
% dt   : time-step
% Ec   :
% Ec0  : reference contractility
% gamma: material parameter  (remodelling rate)
% ln   : pevious time-step length at time t_{n}
% ln1  : current lenth at time t_{n+1}
% lr   : resting length at previous time-step
% theta: numerical parameter for time-integration
%
% OUTPUT:
% Ec1  : contractitility at new time-step t_{n+1}
% lr1 : resting length at new time-step t_{n+1}
%
% Update constraint strain and resting length for self regulated constraction
% Instead of updateing form iterative values and stiffness matrices,
% the functions updates the values by solving the
% time discretised version of the followiong evolution laws for Ec and L:
%
%   dot eps_c=-beta*k*(eps_c-eps_c^0)^alpha
%
%   dot L=gamma*(l-(1+eps_c)*L)
%
Ec1=Ec;
lr1=lr;
lnt=(1-theta)*ln+theta*ln1;
lrnt=lr;
if abs(gamma)<eps
    Ec1=Ec-dt*beta*kappa*(lnt/lrnt-1-Ec0).^alpha;
    return;
end
[Kpp,g]=KgEcL(across,alpha,beta,dt,Ec,Ec0,Ec1,gamma,kappa,ln,ln1,lr,lr1,t,theta);
tol=1e-10;
kmax=50;
k=0;
dp=1;
while (norm(g)>=tol || norm(dp)>=tol ) && k<kmax
    dp=-Kpp\g;
    lr1=lr1+dp(1);
    Ec1=Ec1+dp(2);
    [Kpp,g]=KgEcL(across,alpha,beta,dt,Ec,Ec0,Ec1,gamma,kappa,ln,ln1,lr,lr1,t,theta);
    k=k+1;
%    fprintf('%i Ng %e Np %e\n',k,norm(g),norm(dp)); 
end
if (norm(dp)>tol || norm(g)>tol) && err==0
    fprintf('Convergence of resting length and contractility failed after %i iterations\n',kmax);
    Ec1=Ec;
    lr1=lr;
    err=1;
end
end
