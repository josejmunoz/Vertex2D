function [gout,l1,tout,u,TL,ener,Ec,Vol,numrem,xierror,map_error,Ab,DevLD,DevLV]=MainIncrements(Ab,BC,Lumen,Mat,Set,Step)
% OUTPUT:
% Ab     = Ablation structure
%        Ab.active : switch to active ablation
%        Ab.Vnoc   : relative (divided by length) total volume minus (Vc1+Vc2+Vw)
%        Ab.Vc1    : volume corona 1
%        Ab.Vc2    : volume corona 2
%        Ab.Vw     : volume nods (nodes abblated)
%        Ab.Pw     : perimeter wound
%        Ab.Contract: Set of contracted cells in wound (only perimeter of
%        those cells that are in wound perimeter will be contracted)
%        Ab.Corona1 : nodes at corona1
%        Ab.Corona2 : nodes at corona2
%        Ab.nodAb   : nodes abblated
%        Ab.nodAb1  : nodes abblated current length
%        Ab.eleDDL: Voronoi connectivity Dead-Dead nodes
%        Ab.eleVorDD: Voronoi connectivity between Dead-Dead cells
%        Ab.eleVorDL: Voronoi connectivity between Dead-Live cells
%        Ab.eleVorDLc: Voronoi connectivity between Dead-Live cells with
%        contractility
%        Ab.Co      : coefficient applied on ablated cells Delaunay elements (Dead-Dead and Dead-Alive)
%        Ab.CoVor   : coefficient applied on ablated cells Voronoi elements (Dead-Dead)
%        Ab.Ec      : coefficient applied on contractility of ablated area boundary (Dead-Alive)
%        Ab.Eca     : true -> activate the first element
% l1     = time evolution of Spring resting length of the first element
% TL     = maximum size along x
% LOCAL:
% lnodExternal = connectivity of external nodes from which offset is built if Set.Bcells=true
% lnodExternalO= connectivity of external nodes that are at the offset
% nodes  = total number of nodes, including the external nodes
% nodesI = internal number of nodes, discounting the external nodes (=off-set if Bcells==true)
% nodes0 = number of nodes in original mesh (without offset)
% stress =contains structure for stresses. Structure ordered as:
%           Netwrok.time.Branch()
%         where:
%            Network=D   : at Delaunay
%                   =V   : at Vertices netwrok (Voronoi, Baryentric,...)
%            Time   =n   : stress at previous time-step t_n
%                   =n1  : stress at current time-step t_{n+1}
%            Branch =S() : at spring branch
%                   =A() : at branch A
%                   =B() : at branch B
%                   =T() : total stress
%          Example:
%            stress.D.n.B(i) = stress at previous time step at Delaunay
%                              element (i), branch B
% ln      =contains structure for lengths. Structure ordered as:
%           Network.Time.Branch.Type()
%         where:
%            Network=D   : at Delaunay
%                   =V   : at Vertices netwrok (Voronoi, Baryentric,...)
%            Time   =n   : lengths at previous time-step t_n
%                   =n1  : lengths at current time-step t_{n+1}
%            Branch =S   : at spring branch
%                   =A   : at branch A
%                   =B   : at branch B
%            Type   =r() : resting length
%                   =e() : elastic (in Spring branch=total length)
%                   =c() : contractility (strain)
%          Example:
%            ln.V.n1.A.r(i) = resting length at current time-step of Voronoi element i at branch A
%%%%%%%%%%%%%%%%%%%%%%%
Vor_stiff=Set.Network~=0 && ...
    (abs(Mat.V.kappa)>eps || abs(Mat.V.kappaA)>eps || Mat.V.etaA<0 || Mat.V.etaB<0); %%=0 No stiffness on Voronoi vertices, =1 Stiffness applied to Voronoi vertices
Del_stiff=abs(Mat.D.kappa)>eps || abs(Mat.D.kappaA)>eps || abs(Mat.D.kappaB)>eps; %%=0 No stiffness on Delaunay
if BC.ts>0
    Step.dt=Step.dts;                       % Current time-step
else
    Step.dt=Step.dt;                        % Current time-step
end
num_sh=Step.num_sh;
eV=0;
eVol=0;
Ab.WVini=0;
Ab.active =false;   %%Ablation switch
Ab.Map    =false;   %%Resting length mapping switch when ablation
Ab.Eca    =false;   %%Activate contractility on the wound ring
Ab.Apop   =false;
% if Set.Vrel
%     Set.Xirel =-1;
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%
% Geometry (One element, network, real cells)
[cdof,dim,lnodFEp,dofx,vext,nodes,TL,X,lnodExternal,lnod_ext,Ab.nodAb,doc]=Geo(BC,Set);
%Ab.nodAb=[1 2 3 4 5 6 7 8 9 10 11 13 16 18 21]; Large wound
Ab=Ablate(Ab,Set);
if Set.Network~=0
    [X,lnodExternal,lnodFEp,~,nodes,nodesI,nodes0]=UpdatelnodFE(X,lnodExternal,lnodFEp,nodes,Set);
    [lnod,nodV,ia]=lnodOfDelaunay(lnodExternal,X,lnodFEp,Set);
    [Vor,~,xip]=VoronoiInterpol([],X,lnodFEp,Set,0,0);
    [Vor,vor_cell,vor_cell_ele,lnod,lnod_vor,V0,ln.V.n,celledge,edgesize,celledgeW,vor_cellW,cdofv,dofdeletev,~,C]=VoronoiInitial(BC,X,lnodFEp,Mat.V,nodV,Vor,Vor,lnod,[],[],lnod_ext,lnodExternal,zeros(0,2),zeros(0,2),zeros(0,2),ia,0,{},Set,[],false,0);
    if Set.Network<0
        [X]=correctNode(X,Vor,vor_cell,nodV);
    end
    Vor_stiff=Vor_stiff && ~isempty(lnod_vor);
    Ab=Ablation(Ab,nodV,lnod,vor_cell_ele,lnod_vor,[],[]);
    Vor0=Vor;
    Vorp=Vor;
    Vor00=Vor;
    ln.V.n1=ln.V.n;
else
    lnod=[1 2 1];
    nodesI=nodes;
    nodes0=nodes;
    Ab.eleDDL=[];
    Ab.nodAb1=[];
    xip=[];
    xi=[];
    lnod_vor=[];
    Vor=[];
    Vor0=[];
    vor_cell=[];
    Vorp=[];
    Vor00=[];
end
% Initial values
[ener,ln.D.n,Eps_tot,gout,u,tout,numrem,xierror,map_error,nodError,Ab,DevLD,DevLV]=length0(Ab,lnod,Mat.D,Step.nincr,X,V0);
ln.D.n1=ln.D.n;
[ld,Mat]=DelayInit(ln,lnod,lnod_vor,Mat,X,Vor,Step);
l1=zeros(Step.nincr,1);
Ec=zeros(Step.nincr,1);
l1(1)=ln.D.n1.A.r(1);
Vol=zeros(Step.nincr,length(vor_cell));
X0=X(1:nodes0,:);
i=0;
[stress,stressVol]=InitStress(size(lnod,1),Set.Network,nodesI,size(lnod_vor,1));
OutputVTK(i,Ab,dim,ln,lnod,lnod_vor,nodes0,Set,stress,stressVol,Vor,Vor0,vor_cell,X0,X,nodError)
Points(X,lnod,Vor,lnod_vor,vor_cell,Ab,stress,Set);
% Initial values
Mat=SetContractility(Mat,0);
x=reshape(X',size(X,1)*size(X,2),1)';
x0=x;
xp=x;
lnodFE=lnodFEp;
lnodFE0=lnodFE;
lnodFEadd=[];
lnodp=lnod;
lnod_vorp=lnod_vor;
gA=0;
g_xi=0;
nrem=0;
error=0;
step_h=false;
%%%%%%%%  Loop on load increments %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Step.t=0;
Step.tp=Step.t;
conv=1;
TargetArea=true;
Woundremove=true;
lnodWp=zeros(0,2);
lnodW=lnodWp;
VW0=[];
Pw=[];
Rw=[];
ii=0;
while (Step.tend-Step.t>Step.tol &&  conv) && TargetArea
    %%%
        if Step.t-Ab.tAb>=Ab.tEc*Step.dt0
            Ab.Eca=true; % Apply contractility on wound ring
        end
    %%%
    if Step.t-Ab.tAb>=0 && Set.Ablation
        Ab.active=true; % Apply ablation
        if Step.t-Ab.tAb>=Ab.tEc*Step.dt0
            Ab.Eca=true; % Apply contractility on wound ring
        end
    elseif ~step_h
        if Set.Ablation %|| ~isempty(lnodW)
            Step.dt=Step.factorW*Step.dt;
        else
            Step.factorW=1;
        end
    end
    Step.t=Step.t+Step.dt;
    Set.t=Step.t;
    i=i+1;
    %%%%%%%%%%%
    r=false;
    Wln=[];
    remnod=[];
    if Ab.Apop && ~step_h && Set.AblationType==0  %Gradual apoptosis
        [X,X0,x,x0,xp,dofx,cdof,vext,nodes,nodes0,nodV,gA,gD,gV,g_xi,...
            lnodFE0,lnodFEp,lnodFEadd,N,Vorp,Vor0,Vor00,xip,lnodp,lnod_vorp,V0,ln,Ab]=Remove1cell(X,X0,x,x0,...
            xp,dofx,cdof,vext,nodes,nodes0,nodV,gA,gD,gV,g_xi,lnodFE0,lnodFEp,N,Vorp,Vor0,...
            Vor00,xip,lnodp,lnod_vorp,vor_cell,V0,V,ln,Ab,i-1,Set);
    elseif Ab.active && Woundremove && Set.AblationType==1  %Removing wound cells 
        [X,X0,x,x0,xp,dofx,cdof,vext,nodes,nodes0,nodV,gA,gD,gV,...
        lnodFE0,lnodFEp,N,Vor,Vorp,Vorpp,Vor0,Vor00,xip,lnodp,lnodExternalp,lnod_vorp,celledgep,V0,Vp,VW0,ln,Ab,m,...
        Set,lnodWp,Wln]=RemoveWoundCells(X,X0,x,x0,xp,dofx,cdof,vext,nodes,nodes0,nodV,...
        gA,gD,gV,lnodFE0,lnodFEp,N,Vor,Vorp,Vorpp,Vor0,Vor00,xip,lnodp,lnodExternal,lnod_vorp,celledgep,V0,...
        Vp,ln,Ab,m,Set);
        Woundremove=false;
        r=true;
        Ab.VWini=VW0;
    end
    Vref=V0;
    %%%%%%%%%%%
    Mat=SetContractility(Mat,Step.t);
    if ((Set.Network~=0 && Set.Remodel && i>1) && (i>(Ab.tAb/(5*Step.factorW*Step.dt0)+Ab.tEc+1) || ~Ab.active) && ~step_h) || r
        if ~r
            [Pw,Rw]=WoundEdgeLengths(Vorp,lnod_vorp,vor_cell,lnodWp,lnodExternalp,celledgep);
        end
        [X,lnodFE,lnodExternal,lnod_ext,lnodW,~]=BoundaryFilter(X(1:nodes0,:),lnodFEp,lnodFEadd,lnodWp,i,Set,r,Pw,Rw);
        [X,lnodExternal,lnodFE,~,nodes,~,nodes0]=UpdatelnodFE(X(1:nodes0,:),lnodExternal,lnodFE,nodes0,Set);
        [lnod,nodV,ia]=lnodOfDelaunay(lnodExternal,X,lnodFE,Set);
         if ~isequal(lnodFE,lnodFEp)
            [xip,Vorp(1:size(lnodFE,1),:),Vor0(1:size(lnodFE,1),:),~,I,~]=UpdateXIp(X,Vorp(1:size(lnodFEp,1),:),Vor00(1:size(lnodFE0,1),:),lnod_vorp,lnodFE,lnodFEp,lnodFE0,xip,Set.tess);
         end
    end
    Xn=X;
    if ~(Set.Xirel>0 && Set.Bcells<0 && Set.Vrel)
        [x,X,~]=LoadUnload(cdof,X,x0,vext,TL,Step,BC);
    end
    nodesV=0;
    if Set.Network~=0
        N=zeros(size(lnodFE,1),dim+1);
        xi=zeros(size(lnodFE,1)*dim,1);
        %if ~(Set.Xirel>0 && Set.Bcells<0 && Set.Vrel)
            [Vor(1:size(lnodFE,1),:),N,xi]=VoronoiInterpol(Vorp(1:size(lnodFE,1),:),X,lnodFE,Set,xip,i);
        %end
        if ((i>1 && Set.Remodel) && (i>(Ab.tAb/(5*Step.factorW*Step.dt0)+Ab.tEc+1) || ~Ab.active) && ~step_h) || r
             [Vor,vor_cell,vor_cell_ele,lnod,lnod_vor,V,~,celledge,edgesize,celledgeW,vor_cellW,cdofv,dofdeletev,remnod,C]=VoronoiInitial(BC,X,lnodFE,Mat.V,nodV,Vor(1:size(lnodFE,1),:),Vorpp,lnod,lnodp,lnod_vorp,lnod_ext,lnodExternal,lnodW,lnodExternalp,lnodWp,ia,1,celledgep,Set,Vp,r,i);
             if ~isequal(lnod_vor,lnod_vorp)
                [ln]=Reorderln(X,Vor,ln,lnod,lnodp,lnod_vor,lnod_vorp,Mat);
             end
            Ab=Ablation(Ab,nodV,lnod,vor_cell_ele,lnod_vor,lnodW,celledgeW);

            stress.V.n1.T=zeros(size(lnod_vor,1),1);
            stress.V.n1.A=zeros(size(lnod_vor,1),1);
            stress.V.n1.B=zeros(size(lnod_vor,1),1);
            stress.V.n1.S=zeros(size(lnod_vor,1),1);
            x=reshape(X',size(X,1)*size(X,2),1)';
            if (Ab.active && ~isequal(lnod,lnodp) && ((Set.Xirel<=0 && ~isempty(Ab.nodAb)) || size(lnodW,1)>0)) && ~r
                [xi,xip,N,Vor,Vorp,Vref,V]=Xigen(xi,xip,N,X,Xn,Vor,Vorp,lnodFE,lnod_vor,Ab,I,WVele,Set,V0,remnod,nodV,vor_cell);
            end
            
        end
        nodesV=size(Vor,1);
        sizet=size(lnodFE,1);
        if nodesV>sizet
            Vorp=[Vorp(1:sizet,:);Vor(sizet+1:end,:)];
            Vor0=[Vor0(1:sizet,:);Vor(sizet+1:end,:)];
        end
        if ~step_h
             if i>1 && (~isequal(lnodFE,lnodFEp) || r)
                [~,g_v,~,~,~,~]=gkVoronoiVolume(Xn,lnodFE,N,Vorp,vor_cell,vor_cellW,lnod_vor,Vref,VW0,nodes,Ab,Set,C);
                gAn1=Set.Vp*g_v;
                %gAn1=zeros(size(gAn1));
                %gA  =zeros(size(gA));
                [ln,nrem,error,nodError]=MapTest(Xn,Vorp,lnod,lnodp,lnod_vor,lnod_vorp,lnodExternal,lnodW,lnodExternalp,lnodWp,ln,...
                    vor_cell,nodV,N,gD+gV+gA,gD,gV+gA,gAn1,Mat,lnodFE,Set,Ab,nrem,nodesp,Vref,V,stressp,celledge,celledgep,edgesize,Wln,r);
             else
                nrem=0;
             end
        end
        Vor=LoadUnloadVor(Vor,cdofv,cdof,vor_cell,Set,BC,Step,sizet,TL);
        [x,X]=ModifyX(Ab,X,x,Vor,vor_cell,nodV,doc,Set,false);
        if Ab.active && ~isempty(Ab.nodAb)
            Ab.Map=true;
            Ab.Apop=true;
        end
        
    end
%     ln.V.n.A.r=zeros(size(ln.V.n.A.r));
    % Lumen settings
    [lnod,lnodFE,ln,lnod_vor,Lumen,N,nodesV,stress,Vor,Vor0,Vorp,vor_cell,xi,xip]=LumenGeoUpdate(i,ln,lnod,lnodFE,lnodExternal,lnod_vor,Lumen,N,nodesV,num_sh,stress,Vor,Vor0,Vorp,vor_cell,xi,xip);
    % Solve mMechanical equilibrium
    [g,K,gD,gV,gA,ln,Eps,stress,stressVol,V,eD,eV,eVol]=Mechanics(BC,X,x,xp,x0,Vor,Vorp,Vor0,Vref,VW0,Mat,Set,Ab,Step,dim,nodes,nodes0,...
    nodesV,nodV,N,xi,xip,ln,lnodFE,lnod,lnodExternal,lnodW,lnod_vor,Lumen,vor_cell,vor_cellW,ld,Vor_stiff,edgesize,C);
    %%%%%%%%%%%%%%%%%%%%
    [dofxi,dofx]=dofXI(Ab,dofx,lnodExternal,lnodFE,nodesV,nodes,dim,lnod_vor,Set,BC,cdofv,dofdeletev);
    dof=[dofx dofxi];
    dx=1;
    fprintf('1st g after mapping ||g||=%4.3e, ER: %4.3e\n',norm(g(dof)),norm(error));
    %%%%%%%%%%%%%%%%%%%%
    Vst=5;
    Vinc=(V0-Vref)/Vst;
    check=true;
    s=0;
    while norm(Vref-V0)>Step.tol || check
        if  Set.Print && ~isempty(remnod)
            if norm(Vref-V0)>Step.tol
                fprintf('TARGET AREA GRADUAL RECOVERY, Step %i of %i\n',s,Vst);
            else
                fprintf('BULK REMODELLING... GRADUAL RECOVERY NOT NEEDED\n'); 
            end
        end
        if s>0
             Vref=Vref+Vinc;
             [~,g_v,~,~,~,~]=gkVoronoiVolume(Xn,lnodFE,N,Vorp,vor_cell,vor_cellW,lnod_vor,Vref,VW0,nodes,Ab,Set,C);
             g=g+g_v;
        end
    check=false;
    j=0;
    %%%%%% Newton-Raphson Iterations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    while (norm(g(dof))>Step.tol || norm(dx)>Step.tol) && j<Step.maxiter && norm(g(dof))<1e10
        if (Vor_stiff || Set.Vp>eps) && ~Del_stiff
            K=PosK(K,dof);
        end
        dx=-K(dof,dof)\g(dof);
        x(dofx)=x(dofx)+dx(1:length(dofx))';
        dxi=dx(length(dofx)+1:end);  %iteration on parametric coordinates
        [N,xi,Vor]=ShapeFunc(N,xi,dxi,dofxi,dim,nodes,x,Vor,lnodFE,Set); %modifying shape functions of interpolation
        [x,X]=ModifyX(Ab,X,x,Vor,vor_cell,nodV,doc,Set,true);
        if Set.Network~=0
            X=reshape(x,dim,nodes)';
            if ~(Set.Xirel>0 && Set.Bcells<0 && Set.Vrel)
                Vor(1:size(lnodFE,1),:)=Voronoi(lnodFE,N,X);
            end
        end
        
        [g,K,gD,gV,gA,ln,Eps,stress,stressVol,V,eD,eV,eVol]=Mechanics(BC,X,x,xp,x0,Vor,Vorp,Vor0,...
            Vref,VW0,Mat,Set,Ab,Step,dim,nodes,nodes0,nodesV,nodV,N,xi,xip,ln,lnodFE,lnod,lnodExternal,lnodW,lnod_vor,Lumen,...
            vor_cell,vor_cellW,ld,Vor_stiff,edgesize,C);
        j=j+1;
        if Set.Print>0
            fprintf('IT: %i, T: %4.3f, DT: %4.3f, Ng: %4.3e, Nx: %4.3e, Nxi: %4.3e,NREM: %i\n',j,Step.t,Step.dt,norm(g(dof)),norm(dx(1:length(dofx))),norm(dxi),nrem);
        end
    end
    s=s+1;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if norm(g(dof))<Step.tol
        step_h=false;
        if Set.Print>0
            fprintf('CONVERGED INCR %i in %i ITERATIONS, Dxi= %e\n',i,j,norm(xi-xip));
        end
        Step=UpdateDt(BC,Step);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        OutputVTK(i,Ab,dim,ln,lnod,lnod_vor,nodes0,Set,stress,stressVol,Vor,Vor0,vor_cell,X0,X,nodError)
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %         eXi=0.5*sum((xi-xi0).^2);  %interpolation penalisation energy (unscaled)
%         if Set.NetworkType==0 && BC.FullConstr>0 && Set.Xirel<1
        if ~isempty(cdof)
            u(i+1)=x(cdof(1))-x0(cdof(1));
            gout(i+1)=sum(g(cdof))/(length(cdof)-1); % Per unit of length when network > 0
        end
        l1(i+1)=ln.D.n1.A.r(1);
        Ec(i+1)=ln.D.n1.A.c(1);
        m=min(size(Eps_tot,2),length(Eps));
        Eps_tot(i+1,1:m)=Eps(1:m);     %elastic strain of model.
        tout(i+1)=Step.t;
        ener(i+1,1)=eD;  %Delaunay energy
        ener(i+1,2)=eV;  %Voronoi energy
        ener(i+1,3)=Set.Vp*eVol;  %volume penalisation energy
%         Vol(i+1,:)=V;
        %         ener(i+1,4)=Set.lambda*eXi;  %interpolation penalisation energy
        ener(i+1,5)=eD+eV+Set.Vp*eVol;  %total energy
        numrem(i+1)=nrem;
        map_error(i+1)=norm(error);
        num_sh=0;
        [xierror(i+1)]=xicheck(xi);
        xp=x;
        xip=xi;
        lnodFEp=lnodFE;
        if Ab.active
            WVele=[Vor(lnod_vor(Ab.eleVorDL,1),:) Vor(lnod_vor(Ab.eleVorDL,2),:)];
        end
        [ld,ln,Vor,Vorp]=UpdateLn(ld,ln,lnod,lnod_vor,Mat,1,Vor_stiff,Set.Network,X,Vor,Vorp);
        if Set.Ablation>1 || Ab.active %&& Step.dt>=Step.dt %%&& Ab.active
            Ab=SaveAblationIncrement(Set,Ab,i,lnod_vor,nodV,V,Vor,nodes);
        end
        Step.tp=Step.t;
        Step.dt=Step.dt0;
        lnod_vorp=lnod_vor;
        lnodp=lnod;
        lnodExternalp=lnodExternal;
        lnodWp=lnodW;
        stressp=stress;
        celledgep=celledge;
        nodesp=nodes;
        [dLD,dLV]=StDevL(ln,X,Vor,lnod,lnod_vor);
        DevLD(i)=dLD;
        DevLV(i)=dLV;
        Vorpp=Vorp;
        Vp=V;
        if ~isempty(VW0)
            VW0=V(end);
        end
    elseif num_sh<Step.num_sh_Max
        step_h=true; %%step halving switch
        Step.dt=Step.dt/2;
        x=xp;
        X=reshape(x,dim,nodes)';
        xi=xip;
        Step.t=Step.tp;
        num_sh=num_sh+1;
        if Set.Print>0
            fprintf('Increment %i not converged. Trying step halving %i\n',i,num_sh);
        end
        [ld,ln,Vor,Vorp]=UpdateLn(ld,ln,lnod,lnod_vor,Mat,2,Vor_stiff, Set.Network,X,Vor,Vorp);
        i=i-1;
    else
        if Set.Print>0
            fprintf('Increment %i not converged in %i iterations and  %i step halvings\n',i,j,Step.num_sh_Max);
        end
        conv=0;
    end
    %%%%%%%%%
%     if Set.Ablation && Ab.Vw(i)<Ab.TargetArea  %% Wound target area
%         TargetArea=false;
%     end
    %%%%%%%%
    if (length(lnodW)<1 || Ab.Vw(i)<0.1) && Ab.active
        fprintf('WOUND CLOSED..., post-increment %i\n',ii);
%         if i>=114
%             TargetArea=false;
%         end
        if length(lnodW)<1 %&& ii>=3
            Set.Remodel=false;
        end
        ii=ii+1;
        %if ii>14
%             if ii==15
%                 fprintf('Full vertex relaxation applied at post-increment %i\n',ii);
%             end
%             Set.Xirel=1;
%             BC.mu=30;
%             dofx=zeros(0,1);
%             Set.lambda=0.1;
%             Mat.D.kappaA=0.0;  % Stiffness of 2nd branch Delaunay
%             Mat.D.GammaA=0.0;
%             Mat.D.EcA   =0.0;
            if ii>5
                TargetArea=false;
            end
        %end
    end
end
if ~exist('V','var')
    V=(1+u)*norm(X0(1,:)-X0(2,:));
end
[erD,erV]=Error(lnod,lnod_vor,lnodFE,[lnodExternal;lnodW],ln,X,Vor);
PrepareResults(Set,Mat,Ab,numrem,ener,tout,gout)
end
%%
function Ab=SaveAblationIncrement(Set,Ab,i,lnod_vor,nodV,V,Vor,nodes)
% Saves ablation data after converged increment
nodVnodAb=ismember(nodV,Ab.nodAb);
nodVCor1=ismember(nodV,Ab.Corona1);
nodVCor2=ismember(nodV,Ab.Corona2);
Ab.Vc1(i)=sum(V(nodVCor1))/length(Ab.Corona1);
Ab.Vc2(i)=sum(V(nodVCor2))/length(Ab.Corona2);
Ab.V_tot(i)=sum(V)/length(V);
if Set.AblationType==0
    Ab.Vw(i)=sum(V(nodVnodAb));
elseif length(V)>nodes
    Ab.Vw(i)=V(end);
else
    Ab.Vw(i)=0;
end    
Ab.Vnoc(i)=(sum(V)-sum(V(nodVCor1))-sum(V(nodVCor2))-sum(V(nodVnodAb)))/(length(V)-length(Ab.Corona1)-length(Ab.Corona2)-length(Ab.nodAb));
for p=1:length(Ab.eleVorDL)
    Ab.Pw(i)=Ab.Pw(i)+norm(Vor(lnod_vor(Ab.eleVorDL(p),1),:)-Vor(lnod_vor(Ab.eleVorDL(p),2),:));
end
end
%% 
function Step=UpdateDt(BC,Step)
% Updates time-step Step.dt after converged increment
if abs(Step.dt0-Step.dts)>eps && Step.dt<Step.dt && abs(Step.t-BC.ts)<eps && Step.t>=BC.ts
    Step.dt=Step.dt0;
elseif 2*Step.dt<Step.dt0 && Step.t>=BC.ts
    Step.dt=2*Step.dt;
elseif 2*Step.dt<Step.dts && Step.t<BC.ts
    Step.dt=2*Step.dt;
elseif 2*Step.dt>=Step.dt0 && Step.t>=BC.ts
    Step.dt=Step.dt0;
elseif 2*Step.dt>=Step.dts && Step.t<BC.ts
    Step.dt=Step.dts;
end
end

