function PlotFitExpData
Exp=[0 41.373
68.22 79.202
134.56 84.648
201.056	83.727
267.435	82.9
333.828	79.764
666.908	57.874
999.44 47.351
1331.581 40.077
1664.147 34.191
1996.685 32.275
2329.379 31.208
2661.847 29.059
2994.321 28.613
3326.715 28.284
3660.415 27.639
4226.38	17.818
5126.38	14.833
6026.38	6.576
6926.38	3.323
7826.38	1.749
8726.38	0];
cd ..
cd('Results/RemControl_Total_kk/20_3.5_0.3_0.5_2.0_0.5_0.8');
load('Ab');
load('tout');
tsim1=tout(Ab.Vw>0);
Asim1=[Ab.Vw(Ab.Vw>0);0];
cd ..
cd('20_3.5_0.3_4.0_0.5_0.5_0.8');
load('Ab');
load('tout');
tsim2=tout(Ab.Vw>0);
Asim2=[Ab.Vw(Ab.Vw>0);0];
cd ..
cd ..
%cd('FitExpResults/20_2.0_0.1_1.0_2.0_1.5_2.0_30_hyb');
%cd('FitExpResults/20_1.98_0.1_1.0_2.0_1.5_2.0_30_hyb');
%cd('FitExpResults/20_1.97_0.1_1.0_2.0_1.5_2.0_30_hyb');
cd('FitExpResults/20_1.97_0.05_1.0_2.0_1.5_2.0_30_hyb');
%cd('FitExpResults/20_2.1_0.3_2.0_2.0_1.0_2.0_20_hyb');
load('Ab');
load('tout');
ttest=tout(Ab.Vw>0);
Atest=[Ab.Vw(Ab.Vw>0);0];
cd ..
texp=Exp(:,1);
trange=texp(end)-texp(1);
tind=0:length(texp);
texp=texp-texp(1);
texp=(texp/trange)*max([length(Asim1) length(Asim2) length(Atest)]);
Aexp=Exp(:,2);
Asim1=Asim1-min(Asim1);
Asim2=Asim2-min(Asim2);
Atest=Atest-min(Atest);
Aexp=Aexp-min(Aexp);
Aexprange=abs(Aexp(1)-Aexp(end));
Asim1range=abs(Asim1(1)-Asim1(end));
Asim2range=abs(Asim2(1)-Asim2(end));
Atestrange=abs(Atest(1)-Atest(end));
Asim1=Asim1*Aexprange/Asim1range;
Asim2=Asim2*Aexprange/Asim2range;
Atest=Atest*Aexprange/Atestrange;
figure;
plot(texp,Aexp,'k--','LineWidth',2);
hold on
plot(1:length(Asim1),Asim1,'b-^','LineWidth',2,'markerSize',4);
hold on
plot(1:length(Asim2),Asim2,'r-v','LineWidth',2,'markerSize',4);
hold on
plot(1:length(Atest),Atest,'g-*','LineWidth',2,'markerSize',4);
end