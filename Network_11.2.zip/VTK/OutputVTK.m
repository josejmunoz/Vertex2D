function OutputVTK(i,Ab,dim,ln,lnod,lnod_vor,nodes0,Set,stress,stressVol,Vor,Vor0,vor_cell,X0,X,nodError)
if ~Set.VTK
   return;
end
CreatvtkDel2D(i,X0,X(1:nodes0,:),lnod(:,1:2),stress.D.n1,Set.Bcells,Ab,Ab.active,false,ln.D.n1,nodError);
% if Set.Ablation>1
%     CreatvtkDel2D(i,X(1:nodes0,:),X(1:nodes0,:),lnod(Ab.eleDDL,1:2),stress.D.n1,0,Ab,false,true,ln.D.n1,nodError);
% end
if Set.Network~=0
    CreatvtkVor2D(i,Vor0,Vor,stress.V.n1,lnod_vor,dim,Ab,Ab.active,false,ln.V.n1);
    [TriVorCell,Trigroup]=TriangulisedVoronoiCell(vor_cell,Ab.cellAb,Ab.active);
    CreatvtkTriVor2D(i,Vor,lnod_vor,TriVorCell,Trigroup,stressVol,Ab,Ab.active,false);
%     if Set.Ablation>1
%         CreatvtkVor2D(i,Vor0,Vor,stress.V.n1,lnod_vor([Ab.eleVorDD;Ab.eleVorDL],:),dim,Ab,false,true,ln.V.n1);
%         [TriVorCell,Trigroup]=TriangulisedVoronoiCell(vor_cell(Ab.cellAb,:),Ab.cellAb,false);
%         CreatvtkTriVor2D(i,Vor,lnod_vor([Ab.eleVorDD;Ab.eleVorDL],:),TriVorCell,Trigroup,stressVol(Ab.cellAb),Ab,false,true);
%     end
end
