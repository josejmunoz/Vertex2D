function [error]=xicheck(xi)
xi=reshape(xi,2,size(xi,1)/2)';
sumxi=sum(xi,2);
a=sum((xi(:,2)<0 | xi(:,1)<0) | sumxi>1);
if a>0 
    error=true;
else
    error=false;
end
end