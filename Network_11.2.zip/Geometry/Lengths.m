function l=Lengths(lnod,X)
nele=size(lnod,1);
l=zeros(nele,1);
for ie=1:nele
    x1=X(lnod(ie,1),:);
    x2=X(lnod(ie,2),:);
    l(ie)=norm(x1-x2);
end
