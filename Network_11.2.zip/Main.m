%%%%%%%%%%%%%%%% Hybrid Network Analysis of multicellular systems %%%%%%%%%
function Main(Ecw,D,k_D,k_V,EcD,EcV)
%  Main file
%  Version: 11.0
%  Date:    9/5/2020
addpath(pwd)
%clf;clc;
%close all;
%clearvars;
tic
%%%%%%%%%%%%%%  Input File %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Material properties
% Topology
% Type of analysis Boundary conditiosn, Time-steppin
InputNetwork
Mat.D.kappaA=k_D;
Mat.V.kappaA=k_V;
Set.deltaD  =D;
Ab.Ec       =Ecw;
Mat.D.EcA   =EcD;
Mat.V.EcA   =EcV;
%%%%%%%%%%%%%%%% Internal Setting BC %%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~exist('Set','var')
    Set.Ablation =0;  %1.5   % =0: no tissue ablation, >0: tissue ablation with redius "Ablation"(in cell mean size units)
end
if ~exist('Ab','var')
    Ab.Co       =1e-4;    % coefficient applied on ablated cells Delaunay elements (Dead-Dead and Dead-Alive)
end
if ~exist('BC','var')
    BC.Monotonic =false;% true=linear (monotonic), false=linear + constant/reverse
end
if ~exist('Mat','var')
    Mat.D.kappa=0;% true=linear (monotonic), false=linear + constant/reverse
end
if ~exist('Step','var')
    Step.dt0=1;
    Step.tend=10;
end
[Ab,BC,err,esc,Lumen,Mat,Set,Step]=PreSet(Ab,BC,Lumen,Mat,Set,Step);
if err==1
    return;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if Set.Profiler
    profile on
end
if Set.Fitting
    % Define Material parameters to Fit:
    %  Delaunay:                               Vertices:
    %  k kA kB GA GB eA eB Ec EcA EcB Ect EcAt b k kA kB GA GB eA eB Ec EcA EcB Ect EcAt b
    p=[0 0  0  0  0  0  0  0  0   0   0   0    0 1 1  0  0  0  1  0  1  0   0   0   0    0  ];
    % Bounds
    LB=zeros(size(p));
    UB=Inf*ones(size(p));
    [Mat,gout,u,r,Fval,exitflag,output,tout]=MainIncrementsFitting(Mat,Step,Set,BC,p,LB,UB,Set.File,Ab);
    savefile='gu';
    save(savefile,'Mat','r','Fval','exitflag','output','gout','tout');
    if Set.Ablation>1
        savefile2='V';
        save(savefile2,'V','Ab')
    end
else
    % OUTPUT:
    % gout : stress resultants for each time
    % t    : time for each increment
    % ener : energies at each time.
    %    ener(:,1): Delaunay elastic energy
    %    ener(:,2): Voronoi elastic energy
    %    ener(:,3): Volume constraint penalty term
    %    ener(:,4): Total energy
    % u       : displacement at first constrained dof
    % TL      : total initial length on x of the tissue
    % V(:,i)  : volume at each time at cell i.
    [gout,lr,tout,u,TL,ener,Ec,V,numrem,xierror,map_error,Ab,dLD,dLV]=MainIncrements(Ab,BC,Lumen,Mat,Set,Step);
    savefile='gu';
    save(savefile);
end
%%%%%%%%%%%%%%%%%%%%%%%%%plot%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
PostSet(esc)

%         Subplots(gout,tout,u);
%         if Set.Ablation >0 && (Set.Network<0 || 2*Set.Ablation<Set.Network) && exist('area','file') && exist('APWound','file')
%             num1=xlsread('area');
%             num2=xlsread('APWound');
%             Vplot(V,Ab,xlsread('area'),xlsread('APWound'));
%         end
%         if Set.Results==1
%             PrepareResultsYanlan(Set,Mat,Ab,numrem,ener,tout,gout,dLD,dLV,3,false);
%         end
if Set.Profiler
    profile viewer
    profile off
end
fprintf('Network Programme Ended\n')
fprintf('Total Elapsed Time=%e seconds\n',toc)
if Set.LogFile
    diary off
end
end