function [dof,cdof,doc,vext] = SetLeftRight(BC,lnodExternal,X,Set)
%SetLeftRight: determines left and right side, and applies boundary
%conditions
CVert=BC.CVert;
if Set.Network<0
    Set.NetworkType=0;
end
tolx=0.8; % Tolerance for angle of normal for detectin Right or Left boundary
nodes=size(X,1);
dim=size(X,2);
dof=1:dim*nodes;
x=reshape(X',dim*nodes,1)';
doc=[];
k=0;
ir=0;
il=ir; 
if BC.FullConstr<0 && Set.NetworkType==0
    cdof=zeros(1,2*size(lnodExternal,1));
    dofdeleteR=zeros(1,4*size(lnodExternal,1));
    dofdeleteL=dofdeleteR;
    for n=1:size(lnodExternal,1)
        dof1=(lnodExternal(n,1)-1)*dim+1:lnodExternal(n,1)*dim;
        dof2=(lnodExternal(n,2)-1)*dim+1:lnodExternal(n,2)*dim;
        x1 =x(dof1);
        x2=x(dof2);
        l12=x1'-x2';
        Rotate90=[0 -1;1 0]*l12;
        nT=Rotate90/norm(l12);
        if nT(1)>tolx  %Right
            cdof(k+1)=dof1(1);
            cdof(k+2)=dof2(1);
            k=k+2;
            if CVert
                dofdeleteR(ir+1)=dof1(2);
                dofdeleteR(ir+2)=dof2(2);
                ir=ir+2;
            end
            dofdeleteR(ir+1)=dof1(1);
            dofdeleteR(ir+2)=dof2(1);
            ir=ir+2;
        elseif nT(1)<-tolx  %left
            if CVert
                dofdeleteL(il+1)=dof1(2);
                dofdeleteL(il+2)=dof2(2);
                il=il+2;
            end
            dofdeleteL(il+1)=dof1(1);
            dofdeleteL(il+2)=dof2(1);
            il=il+2;
        end
    end
    cdof=cdof(1:k);
    dofdelete=[dofdeleteR(1:ir) dofdeleteL(1:il)];
    cdof=unique(cdof);
    if ~CVert
        [~,IR]=min(x(dofdeleteR+1));
        [~,IL]=min(x(dofdeleteL+1));
        dofdelete=[dofdelete dofdeleteR(IR)+1 dofdeleteL(IL)+1];
    end
    dof(dofdelete)=[];
elseif BC.FullConstr>0
        dofdelete=dim*lnodExternal(:,1)-dim+(1:dim);
        dofdelete=reshape(dofdelete',size(lnodExternal,1)*dim,1);
        cdof=[];
    dof(dofdelete)=[];
else
     if BC.mu<eps
        r=Set.Network;
        c=[r 0];
        s=[r 2*r];
        dl1=sqrt(sum(([X(:,1)-c(1) X(:,2)-c(2)]).^2,2));
        dl2=sqrt(sum(([X(:,1)-s(1) X(:,2)-s(2)]).^2,2));
        [~,I]=min(dl1);
        [~,J]=min(dl2);
        dofdelete=[2*I-1;2*I;2*J-1];
        doc=dofdelete;
        dof(dofdelete)=[];
     end
    cdof=[];
end
vext=zeros(1,nodes*dim);
end

