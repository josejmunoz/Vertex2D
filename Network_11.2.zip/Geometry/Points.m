function Points(X,lnod,Vor,lnod_vor,vor_cell,Ab,stress,Set)
if Set.Network==0
    return;
end
if isempty(stress)
    stressD=zeros(size(lnod,1),1);
    stressV=zeros(size(lnod_vor,1),1);
else
    stressD=stress.D.n1.A;
    stressV=stress.V.n1.A;
end
for i=1:size(lnod_vor,1)
    if stressV(i)>-eps
        plot([Vor(lnod_vor(i,1),1) Vor(lnod_vor(i,2),1)],[Vor(lnod_vor(i,1),2) Vor(lnod_vor(i,2),2)],'-r','LineWidth',4);
    else
        plot([Vor(lnod_vor(i,1),1) Vor(lnod_vor(i,2),1)],[Vor(lnod_vor(i,1),2) Vor(lnod_vor(i,2),2)],'-b','LineWidth',4);
    end
    hold on
end
scatter(Vor(:,1),Vor(:,2),'*')
hold on
a=(1:size(Vor,1))';
b=num2str(a);
c=cellstr(b);
dx=0.07;
dy=0.07;
text(Vor(:,1)+dx,Vor(:,2)+dy,c,'color','r');
hold on
a=(1:size(X,1))';
b=num2str(a);
c=cellstr(b);
text(X(:,1)+dx,X(:,2)+dy,c);
for i=1:size(lnod,1)
    if stressD(i)>-eps
        plot([X(lnod(i,1),1) X(lnod(i,2),1)],[X(lnod(i,1),2) X(lnod(i,2),2)],'k-','LineWidth',1);
    else
        plot([X(lnod(i,1),1) X(lnod(i,2),1)],[X(lnod(i,1),2) X(lnod(i,2),2)],'g-','LineWidth',1);
    end
    hold on
end
if ~isempty(Ab.nodAb)
    vorcDL=vor_cell(Ab.cellAb);
    if Ab.active
        c='r';
    else
        c='b';
    end
    for i=1:length(Ab.nodAb)
        fill(Vor(vorcDL{i}(1:end-1),1),Vor(vorcDL{i}(1:end-1),2),c);
        alpha(.2);
    end
end
end