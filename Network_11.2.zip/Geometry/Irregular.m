function [X]=Irregular(X)
%  Creates and irregular version of nodal points X (only for 2D)
n=sqrt(size(X,1));
X=sortrows(X);
for i=1:n-2;
    X(i*n+2:(i+1)*n-1,1)=X(i*n+2:(i+1)*n-1,1)+0.5*rand(n-2,1);
    X(i*n+2:(i+1)*n-1,2)=X(i*n+2:(i+1)*n-1,2)+0.5*rand(n-2,1);
end
end
