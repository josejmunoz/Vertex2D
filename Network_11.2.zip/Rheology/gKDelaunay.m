function [eD,g,K,ln1,Eps,stress]=gKDelaunay(ld,ln,...
    nodes,nodesV,nodes0,dim,dt,Mat,lnod,theta,x,xp,x0,Set,Ab)
Maxwell=abs(Mat.etaA)>eps || abs(Mat.etaB)>eps;
nele=size(lnod,1);
dof=zeros(2*dim,1);
BcellsPenal=false; % true: Treat offset through penalisation of icnremental displacements 
                   % false:  Treat offset using off-set elements stiffness
%nodesV=0;
g=zeros(dim*(nodes+nodesV),1);
if Set.sparseM
    c=zeros(nele*dim*2*dim*2,1);
    r=zeros(nele*dim*2*dim*2,1);
    v=zeros(nele*dim*2*dim*2,1);
    k=0;
else
    K=zeros(dim*(nodes+nodesV),dim*(nodes+nodesV));
end
Eps=zeros(nele,1);
EpsElasele=zeros(nele,1);
ln1.A.r=zeros(nele,1);
ln1.B.r=zeros(nele,1);
ln1.A.e=zeros(nele,1);
ln1.B.e=zeros(nele,1);
ln1.A.c=zeros(nele,1);
ln1.B.c=zeros(nele,1);
ln1.S.e=zeros(nele,1);
ln1.S.c=zeros(nele,1);
stress.T=zeros(nele,1);
stress.S=zeros(nele,1);
stress.A=zeros(nele,1);
stress.B=zeros(nele,1);
eD=0;
eleMat=Mat;
err=0;
for ie=1:nele
    if ismember(ie,Ab.eleDDL) && Ab.active
        eleMat.kappa=Ab.Co*Mat.kappa;
        eleMat.kappaA=Ab.Co*Mat.kappaA;
        eleMat.kappaB=Ab.Co*Mat.kappaB;
        eleMat.GammaA=50*Mat.GammaA;
        eleMat.GammaB=50*Mat.GammaB;
        eleMat.etaA=Ab.Co*Mat.etaA;
        eleMat.etaB=Ab.Co*Mat.etaB;
        eleMat.Ec0 =0;
        eleMat.Ec0A=0;
        eleMat.Ec0B=0;
        eleMat.Ec  =0;
        eleMat.EcA =0;
        eleMat.EcB =0;
    else
        eleMat=Mat;
        if max(lnod(ie,:)-nodes0)>0 && ~BcellsPenal
            eleMat.kappa=eleMat.kappa*Mat.Bcells;
            eleMat.kappaA=eleMat.kappaA*Mat.Bcells;
            eleMat.kappaB=eleMat.kappaB*Mat.Bcells;
        end
    end
Ec0=eleMat.Ec0;
Ec0A=eleMat.Ec0A;
Ec0B=eleMat.Ec0B;
    if eleMat.beta<eps
        Ec=eleMat.Ec;
    else
        Ec=ln.S.c(ie);
    end
    if eleMat.betaA<eps
        EcA=eleMat.EcA;
    else
        EcA=ln.A.c(ie);
    end
    if eleMat.betaB<eps
        EcB=eleMat.EcB;
    else
        EcB=ln.S.c(ie);
    end
    % Elemetnal residual and Jacobian
    dof1=(lnod(ie,1)-1)*dim+1:lnod(ie,1)*dim;
    dof2=(lnod(ie,2)-1)*dim+1:lnod(ie,2)*dim;
    
    x1 =x(dof1);
    x1p=xp(dof1);
    x10=x0(dof1);
    
    x2 =x(dof2);
    x2p=xp(dof2);
    x20=x0(dof2);
    
    % Backward Euler, calculation of lengths at current time step (ln1) according to previous time step (ln)
    if Maxwell
        [ener,gel,Kel,EpsElas,ln1.A.e(ie,:),ln1.B.e(ie,:),ln1.S.e(ie,:),G_tot,Gs,GacA,GacB]=MaxwellKelvinElas...
            (eleMat,dim,dt,x1,x1p,x10,x20,x2,x2p,ln.A.e(ie),ln.B.e(ie),Set);
        ln1.A.r(ie,:)=ln1.A.e(ie,:);
        ln1.B.r(ie,:)=ln1.B.e(ie,:);
        ln1.S.e(ie,:)=ln1.A.e(ie,:);
        ln1.S.c(ie)=Mat.Ec;
        ln1.A.c(ie)=0;
        ln1.B.c(ie)=0;
    else
        [ener,err,gel,Kel,EpsElas,ln1.S.c(ie),ln1.A.c(ie),ln1.B.c(ie),ln1.A.r(ie),ln1.B.r(ie),ln1.S.e(ie),G_tot,Gs,GacA,GacB]=...
            ActiveElas(dt,Ec0,Ec0A,Ec0B,Ec,EcA,EcB,err,ld(ie),ln.A.r(ie),ln.B.r(ie),...
            eleMat,Ab.tAb,theta,x1,x1p,x2,x2p,x10,x20,Set); % elemental calculation
    end
   
    Eps(ie,:)=EpsElas;
    EpsElasele(ie,1)=EpsElas;
    stress.T(ie,:)=G_tot;
    stress.S(ie,:)=Gs;
    stress.A(ie,:)=GacA;
    stress.B(ie,:)=GacB;
    % Add penalisation to off-set displacements
    if Mat.Bcells>0 
        for n=1:2
            if n>nodes0 && BcellsPenal
                if n==1
                    gel(1:dim) = ...
                    gel(1:dim) + Mat.Bcells*(x1-x1p);
                else
                    gel(dim+1:2*dim) = ...
                    gel(dim+1:2*dim) + Mat.Bcells*(x2-x2p);
                end
                for d=1:ndim
                    Kel((n-1)*dim+d,(n-1)*dim+d) = ...
                    Kel((n-1)*dim+d,(n-1)*dim+d) + Mat.Bcells;
                end
            end
        end
    end
    % Assemble
    dof(1:dim)      =dof1;
    dof(dim+1:2*dim)=dof2;
    g(dof)=g(dof)+gel;
    if Set.sparseM
        for i=1:2*dim
            for j=1:2*dim
                k=k+1;
                r(k)=dof(i);
                c(k)=dof(j);
                v(k)=Kel(i,j);
            end
        end
    else
        K(dof,dof)=K(dof,dof)+Kel;
    end
    eD=eD+ener;
end
if Set.sparseM
    K=sparse(r(1:k),c(1:k),v(1:k),dim*(nodes+nodesV),dim*(nodes+nodesV));
end
end