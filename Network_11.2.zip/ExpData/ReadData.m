function [Y,time]=ReadData(File)
%% Reads variables gout and tout from datfile File
% File = Name of datafile
% Y    = contains variable gout
% tout = times for which each component Y(i) corresponds to
load(File);
if strcmp(File,'Expdata_stress_control')
     Y=(mean_stress(4:200)./1000)';
%     scatter(time(4:200),mean_stress(4:200)./1000,'b'); % kilopascal
elseif strcmp(File,'CharrasData_ECadGFP')
    Y=(CharrasDataControl(:,2)./1000);
    time=CharrasDataControl(:,1);
    %scatter(time,Y,'b'); % kilopascal
    %hold on
else %if strcmp(File,'OneElem_k1')
    Y=gout;
    time=tout;
end
