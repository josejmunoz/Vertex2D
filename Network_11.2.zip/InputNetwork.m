%%%%%%%%%%%%%%%% Input File for Hybrid Network Analysis %%%%%%%%%%%%%%%%%%
% 
%%%%%%%%%%%%%%%% Material %%%%%%%%%%%%%%%%%%
%
%  For each Delaunay/Voronoi element, Active or Maxwell (etaA>0 or etaB>0)
%         kappa
%    |----/\/\----------|
%    |    kappaA GammaA |
%  --|----/\/\----||--- |----
%    |    kappaB GammaB |
%    |----/\/\----||----|
%
%  One elastic branch if kappaA=0 and kappaB=0
%  One active branch if kappa<>0 or kappaB<>0
%
%  For each Delaunay/Voronoi element using Kelvin (etaA<0 or etaB<0)
%       kappa
%    |--/\/\----|
%    |   -etaA  |
%  --|----||--- |----
%    |   -etaB  |
%    |----||----|
%
% Delaunay. Maxwell/Kelvin is considered whenever abs(etaA)>eps || abs(etaB)>eps
Mat.D.kappaA=1.0;  % Stiffness of 2nd branch Delaunay
Mat.D.GammaA=0.001;  % 0.0000625; % best fit
Mat.D.EcA   =1.0;
% Vertices/Voronoi. Maxwell on Voronopi is considered whenever, 
%  abs(etaVA)>eps || abs(etaVB)>eps
Mat.V.kappaA=2.0;  % Stiffness for Active/Maxwell 1st Branch on Voronoi
Mat.V.GammaA=0.004;  % 2.0 Viscossity for Active 1st Branch in voronoi. =0: no viscosity
Mat.V.EcA   =1.3;  % 0.8 Contractility in Voronoi
% Volume Constraints
Set.Vp      =4.0e1;
%Penalisation of volume constraint
%%%%%%%%%%%%%%%%% Geometry %%%%%%%%%%%%%%%%%%%
Set.NetworkType=1;
Set.Network=20;    % if NetworkType=0, Geometry is made of a grid with Network x Network
                   % if NetworkType=1, Geometry is made of a circular grid
                   % of Network radius
                   % Network =0: 1 element
                   % Network <0: Experimental real cells
%%%%%%%%%%%%%%%%% Time Stepping %%%%%%%%%%%%%%%%%%%
Step.dt0     =16.0; % Initial time-step
Step.tend    =20000.0;  % Final time 
Set.Remodel  =true;   % =true: Remodel (update connectivity at each increment), =false: connectivity is constant
%%%%%%%%%%%%%%%%% Other settings %%%%%%%%%%%%%%%%%%%
Set.Print=1;        % =0 No printing
Set.Bcells=-1;
BC.FullConstr=0; % =0 : no boundary constraint, =-1 : right and left of the boundary is constrained, =1 : whole boundary is constrained (pinned) 
BC.Monotonic=true;
BC.ts=3.0;
BC.xStretch=0.0; % Applied displacements on the right according to input strain
Set.MapSplit=true;
Set.lambda=0.0;
Set.deltaD=0.5;   % =<1.1 , for >1.1 no remodelling at the wound edge           
Set.DispBased=0;
Set.alpha=40;    %boundary cells curveture smoothness factor
Set.Vrel=true;
Set.Xirel=-1; % 0=vertex position attached to nodes. 1=vertex positions is independent of nodal coordinates (full-vertex mechanics)
% When Lumen.V is set, this vertex is set to split.
% When Lumen.lnod0 is set, these vertex bar elements have an applied pressure
% If none of them is set, vertex is chosen in UpdateGeoLumen.
Lumen=[];
%Lumen=cell(1,1);
% Lumen{1}.lnod0=[2, 5; 5,4; 4,7;7,8;8,2]; % Setting for Lumen around cell 5 in 2x2 netowrk
%Lumen{1}.P0=0.1; % Lumen pressure
BC.mu=Mat.D.kappaA+Mat.V.kappaA;
Set.AblationType=1; % =0: confluent network, =1: ablation is defined by cell removal (internal boundary formation)
Set.Ablation=1.7;
Ab.tAb=5000.0;
Ab.tEc=250/Step.dt0; 
Step.factorW=240/Step.dt0;
Ab.Ec       =2.8; 