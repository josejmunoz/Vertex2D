function [dofxi,dofx]=dofXI(Ab,dofx,lnodExternal,lnodFE,nodesV,nodes,dim,lnod_vor,Set,BC,cdofv,dofdeletev)
% lnodaux=zeros(3*(dim-1)*size(lnodFE,1),3);
% for i=1:size(lnodFE,1)
%     lnodaux(3*i-2:3*i,1:2)=nchoosek(lnodFE(i,:),2);
%     lnodaux(3*i-1,[1 2])=lnodaux(3*i-1,[2 1]);
%     lnodaux(3*i-2:3*i,3)=i*ones(3,1);
% end
% [~,I,~]=unique(sort(lnodaux(:,1:2),2),'rows');
% lnodaux=lnodaux(I,:);
% a= ismember(lnodaux(:,1:2),lnodExternal,'rows');
% xifix=unique(lnodaux(a,3));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%% decoupling of ALL vertices %%%%%%%%%%%%%%%%%%%%%
dofxi=zeros(0,1);
if Set.Xirel==1
    if ~Set.Vrel
        a= ismember(lnodFE(:,1),lnodExternal(:,1)) | ismember(lnodFE(:,2),lnodExternal(:,1)) | ismember(lnodFE(:,3),lnodExternal(:,1));
        dofxi=1:nodesV*dim;
        xifix=1:nodesV;
        xifix=xifix(a); %%interpolated Voronoi edges on the boundary of the tissue kept pinned to avoid rigid modes between the two coupled networks
        dofdel=[xifix*2-1;xifix*2];
        dofxi(ismember(dofxi,dofdel))=[];
        dofxi=dofxi+nodes*dim;
    else
        dofxi=nodes*dim+(1:nodesV*dim);
        dofxi([dofdeletev;cdofv]-nodes*dim)=[];
    end
    %%%%%%%% decoupling of ONLY vertices on the wound edge %%%%%%%%
elseif Set.Xirel==-1 && Ab.active && ~isempty(Ab.nodAb)
    if size(Ab.eleVorDL,1)>0
%         I=ismember(lnod_vor(Ab.eleVorDL,:),lnod_vor(Ab.eleVorDD,:));
%         aux=lnod_vor(Ab.eleVorDL,:);
%         dofDL=unique(aux(I));
        dofDL=unique([lnod_vor(Ab.eleVorDL,1);lnod_vor(Ab.eleVorDL,2)]);
%        dofDL=unique([lnod_vor(Ab.eleVorDL,1);lnod_vor(Ab.eleVorDL,2);lnod_vor(Ab.eleVorDD,1);lnod_vor(Ab.eleVorDD,2)]);
        dofDL=[(dofDL-1)*dim+1;dofDL*dim];
        dofxi=dofDL+nodes*dim;
        if size(dofxi,1)>0
            dofxi=dofxi';
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if BC.FullConstr>0  %%pinning boundary nodes to avoid boundary cells shape lose when contractility is applied
            a= ismember(lnodFE(:,1),lnodExternal(:,1)) | ismember(lnodFE(:,2),lnodExternal(:,1)) | ismember(lnodFE(:,3),lnodExternal(:,1));
            dofaux=zeros(nodes*dim,1);
            dofaux(dofx)=dofaux(dofx)+1;
            dofdel=unique([lnodFE(a,1);lnodFE(a,2);lnodFE(a,3)]);
            dofdel=[dofdel*2-1;dofdel*2]; % Valid in 2D
            dofaux(dofdel)=0;
            dofaux=logical(dofaux);
            dofx=1:nodes*dim;
            dofx=dofx(dofaux);
        end
        dofxdel=[Ab.nodAb*2-1 Ab.nodAb*2];
        dofx(ismember(dofx,dofxdel))=[];
    end
elseif Set.Bcells<0 && Set.Xirel<1
        nodesVb=size(lnodFE,1)+1:nodesV;    %%Adding boundary vertices to degrees of freedom
        dofxi=[dofxi 2*nodesVb-1+nodes*dim 2*nodesVb+nodes*dim];    
end 
if Ab.active && ~isempty(Ab.nodAb)
    if dim==2
        dofab=[2*Ab.nodAb-1 2*Ab.nodAb];
    else
        dofab=[3*Ab.nodAb-2 3*Ab.nodAb-1 3*Ab.nodAb];
    end
   dofx(ismember(dofx,dofab))=[];
end
dofx=sort(dofx);
dofxi=sort(dofxi);
end