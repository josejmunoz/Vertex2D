function []=Vplot(V,Ab,num1,num2)
% Defaults for this blog post
width = 10;     % Width in inches
height = 3;    % Height in inches
alw = 1.5;    % AxesLineWidth
fsz = 36;      % Fontsize
lw = 4;      % LineWidth
msz = 10; % MarkerSize
%%%%%%%%%%%%%%%%%%%%%%
trange1=max(num1(:,1))-min(num1(:,1));
tscale1=trange1/length(V);

trange2=max(num2(:,1))-min(num2(:,1));
tscale2=trange2/length(Ab.Vw);
tscale12=(max(num1(:,1))/max(num2(:,1)));
tscale2=tscale12*tscale2;

Vrange1=max(num1(:,2))-min(num1(:,2));
Vrangesim1=max(V)-min(V);
Vscale1=Vrange1/Vrangesim1;
Vdiff=V(1)*Vscale1-num1(1,2);

Vnocrange1=max(num1(:,6))-min(num1(:,6));
Vnocrangesim1=max(Ab.Vnoc)-min(Ab.Vnoc);
Vnocscale1=Vnocrange1/Vnocrangesim1;
Vnocdiff=Ab.Vnoc(1)*Vnocscale1-num1(1,6);

Vc1range1=max(num1(:,3))-min(num1(:,3));
Vc1rangesim1=max(Ab.Vc1)-min(Ab.Vc1);
Vc1scale1=Vc1range1/Vc1rangesim1;
Vc1diff=Ab.Vc1(1)*Vc1scale1-num1(1,3);

Vc2range1=max(num1(:,4))-min(num1(:,4));
Vc2rangesim1=max(Ab.Vc2)-min(Ab.Vc2);
Vc2scale1=Vc2range1/Vc2rangesim1;
Vc2diff=Ab.Vc2(1)*Vc2scale1-num1(1,4);


Vwrange2=max(num2(:,2))-min(num2(:,2));
Vwrangesim2=max(Ab.Vw)-min(Ab.Vw);
Vwscale2=Vwrange2/Vwrangesim2;
Vwdiff=Ab.Vw(1)*Vwscale2-num2(1,2);

Pwrange2=max(num2(:,3))-min(num2(:,3));
Pwrangesim2=max(Ab.Pw)-min(Ab.Pw);
Pwscale2=Pwrange2/Pwrangesim2;
Pwdiff=Ab.Pw(1)*Pwscale2-num2(1,3);

figure
% pos=get(gcf,'Position');
% set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
% set(gca,'FontSize',fsz,'LineWidth',lw)

% subplot(1,6,1)
% pos=get(gcf,'Position');
% set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
% set(gca,'FontSize',fsz,'LineWidth',lw)
plot(num1(:,1),num1(:,2)/num1(1,2),'-*','Markersize',msz,'LineWidth',3);
hold on
plot(tscale1*(1:length(V)),V/V(1),'LineWidth',3);
xlabel('time','fontsize',18); ylabel('mean total area','fontsize',18)
title('partial tissue','fontsize',22);
% subplot(1,6,2)
% pos=get(gcf,'Position');
% set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
% set(gca,'FontSize',fsz,'LineWidth',lw)
figure
plot(num1(:,1),num1(:,3)/num1(1,3),'-*','Markersize',msz,'LineWidth',3);
hold on
plot(tscale1*(1:length(Ab.Vc1)),Ab.Vc1/Ab.Vc1(1),'LineWidth',3);
xlabel('time','fontsize',18); ylabel('mean corona1 area','fontsize',18)
title('partial tissue','fontsize',22);
% subplot(1,6,3)
% pos=get(gcf,'Position');
% set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
% set(gca,'FontSize',fsz,'LineWidth',lw)
figure
plot(num1(:,1),num1(:,4)/num1(1,4),'-*','Markersize',msz,'LineWidth',3);
hold on
plot(tscale1*(1:length(Ab.Vc2)),Ab.Vc2/Ab.Vc2(1),'LineWidth',3);
xlabel('time','fontsize',18); ylabel('mean corona2 area','fontsize',18)
title('partial tissue','fontsize',22);
% subplot(1,6,4)
% pos=get(gcf,'Position');
% set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
% set(gca,'FontSize',fsz,'LineWidth',lw)
figure
plot(num1(:,1),num1(:,6)/num1(1,6),'-*','Markersize',msz,'LineWidth',3);
hold on
plot(tscale1*(1:length(Ab.Vnoc)),Ab.Vnoc/Ab.Vnoc(1),'LineWidth',3);
xlabel('time','fontsize',18); ylabel('mean non-corona area','fontsize',18)
title('partial tissue','fontsize',22);
% subplot(1,6,5)
% pos=get(gcf,'Position');
% set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
% set(gca,'FontSize',fsz,'LineWidth',lw)
figure
plot(tscale12*num2(:,1),num2(:,2)/num2(1,2),'-*','Markersize',msz,'LineWidth',3);
hold on
plot(tscale2*(1:length(Ab.Vw)),Ab.Vw/Ab.Vw(1),'LineWidth',3);
xlabel('time','fontsize',18); ylabel('wound area','fontsize',18)
title('partial tissue','fontsize',22);
% subplot(1,6,6)
% pos=get(gcf,'Position');
% set(gcf,'Position',[pos(1) pos(2) width*100 height*100]);
% set(gca,'FontSize',fsz,'LineWidth',lw)
figure
plot(tscale12*num2(:,1),num2(:,3)/num2(1,3),'-*','Markersize',msz,'LineWidth',3);
hold on
plot(tscale2*(1:length(Ab.Pw)),Ab.Pw/Ab.Pw(1),'LineWidth',3);
xlabel('time','fontsize',18); ylabel('wound perimeter','fontsize',18)
title('partial tissue','fontsize',22);
figure
plot(tscale12*num2(1:(end-2),1),(num2(1:(end-2),3)*num2(1,2))./(num2(1:(end-2),2)*num2(1,3)),'-*','Markersize',msz,'LineWidth',3);
hold on
a=2/length(num2(:,1));
a=floor(length(Ab.Pw)*a);
plot(tscale2*(1:(length(Ab.Pw)-10)),(Ab.Pw(1:(end-10))*Ab.Vw(1))./(Ab.Pw(1)*Ab.Vw(1:(end-10))),'LineWidth',3);
xlabel('time','fontsize',18); ylabel('wound perimeter/area','fontsize',18)
title('patial tissue','fontsize',22);
end