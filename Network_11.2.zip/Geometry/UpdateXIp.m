function [xi,V,V0,EV,I,c]=UpdateXIp(X,V,V0,EV,FE,FEp,FE0,xi,tess)
xiaux=zeros(size(FE,1)*(size(FE,2)-1),1);
Vaux=zeros(size(FE,1),size(FE,2)-1);
Vaux0=Vaux;
FEaux=sort(FE,2);
FEpaux=sort(FEp,2);
FE0aux=sort(FE0,2);
[I,LocFEp]=ismember(FEaux,FEpaux,'rows');
[~,LocFE0]=ismember(FEaux,FE0aux,'rows');
for i=1:length(LocFEp)
    if LocFEp(i)~=0  %%unchanged triangles
        if FE(i,:)==FEp(LocFEp(i),:)  %%unchanged triangles with unchanged order of vertices
            xiaux(2*i-1:2*i)=xi(2*LocFEp(i)-1:2*LocFEp(i));
        elseif FE(i,[3 1 2])==FEp(LocFEp(i),:)  %%uchanged triangles with changed order of vertices [1 2 3]-->[3 1 2]
            xiaux(2*i-1:2*i)=[xi(2*LocFEp(i)) 1-xi(2*LocFEp(i)-1)-xi(2*LocFEp(i))];
        else   %%unchanges triangles with changed order of vertices [1 2 3]-->[2 3 1]
            xiaux(2*i-1:2*i)=[1-xi(2*LocFEp(i)-1)-xi(2*LocFEp(i)) xi(2*LocFEp(i)-1)];
            
        end
        Vaux(i,:)=V(LocFEp(i),:);   %%re-arranging surviving vertices with respect to new order of trianlges
    %%applying fresh interpolation on new triangles
    elseif tess
        s=1/(2*((X(FE(i,2),1)-X(FE(i,1),1))*(X(FE(i,3),2)-X(FE(i,1),2))-(X(FE(i,3),1)-X(FE(i,1),1))*(X(FE(i,2),2)-X(FE(i,1),2))));
        Vor=s*[(X(FE(i,3),2)-X(FE(i,1),2))*(norm(X(FE(i,2),:))^2-norm(X(FE(i,1),:))^2)-(X(FE(i,2),2)-X(FE(i,1),2))*(norm(X(FE(i,3),:))^2-norm(X(FE(i,1),:))^2) (X(FE(i,2),1)-X(FE(i,1),1))*(norm(X(FE(i,3),:))^2-norm(X(FE(i,1),:))^2)-(X(FE(i,3),1)-X(FE(i,1),1))*(norm(X(FE(i,2),:))^2-norm(X(FE(i,1),:))^2)];
        %%obtaining Vronoi vertices in local coordinates respected to triangles edges
        s=[X(FE(i,3),2)-X(FE(i,1),2) X(FE(i,1),2)-X(FE(i,2),2)
            X(FE(i,1),1)-X(FE(i,3),1) X(FE(i,2),1)-X(FE(i,1),1)];
        xiaux(2*i-1:2*i)=(Vor-X(FE(i,1),1:2))*(s/det(s));
        Vaux(i,:)=Vor;    %%replacing Vorp for new vertices by the actual Vor (if tessellation Voronoi)
    else
        xiaux(2*i-1:2*i)=[1/3;1/3];
        Vaux(i,:)=(X(FE(i,1),:)+X(FE(i,2),:)+X(FE(i,3),:))/3;  %%%%replacing Vorp for new vertices by the actual Vor (if tessellation barycentric)
    end
    
    %%applying the approach above to recover Vor0 for new set of triangles
    if LocFE0(i)~=0
        Vaux0(i,:)=V0(LocFE0(i),:);
    elseif tess
        s=1/(2*((X(FE(i,2),1)-X(FE(i,1),1))*(X(FE(i,3),2)-X(FE(i,1),2))-(X(FE(i,3),1)-X(FE(i,1),1))*(X(FE(i,2),2)-X(FE(i,1),2))));
        Vor=s*[(X(FE(i,3),2)-X(FE(i,1),2))*(norm(X(FE(i,2),:))^2-norm(X(FE(i,1),:))^2)-(X(FE(i,2),2)-X(FE(i,1),2))*(norm(X(FE(i,3),:))^2-norm(X(FE(i,1),:))^2) (X(FE(i,2),1)-X(FE(i,1),1))*(norm(X(FE(i,3),:))^2-norm(X(FE(i,1),:))^2)-(X(FE(i,3),1)-X(FE(i,1),1))*(norm(X(FE(i,2),:))^2-norm(X(FE(i,1),:))^2)];
        Vaux0(i,:)=Vor;
    else
        Vaux0(i,:)=(X(FE(i,1),:)+X(FE(i,2),:)+X(FE(i,3),:))/3;
    end
end
xi=xiaux;
V=Vaux;
V0=Vaux0;
c=0;
EV=0;
% [a,Loca]=ismember(EV(:,1),LocFEp);   %%updating indices of surviving vertices in the previous connectivity (only elements with both survived ends are being kept)
% [b,Locb]=ismember(EV(:,2),LocFEp);
% c=logical(a.*b);
% EV=[Loca(c) Locb(c)];

end

