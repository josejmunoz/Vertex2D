function [param,LB,UB]=RetreiveMat(Mat,p,LBi,UBi)
param=zeros(sum(p~=0),1);
LB=param;
UB=param;
k=0;
for i=1:length(p)
    %  k kA kB GA GB eA eB Ec EcA EcB Ect EcAt kV kVA kVB GVA GVB eVA eVB EcV EcVA EcVB EcVt EcVAt
    if p(i)>0
        k=k+1;
        switch i
            case 1
                param(k)=Mat.D.kappa;   % Stiffness of Main Delaunay
            case 2
                param(k)=Mat.D.kappaA;  % Stiffness of 2nd branch Delaunay
            case 3
                param(k)=Mat.D.kappaB;  % Stiffness of 3rd branch Delaunay
            case 4
                param(k)=Mat.D.GammaA;  %GammaA=-1 dashpot branch on Delaunay
            case 5
                param(k)=Mat.D.GammaB;
            case 6
                param(k)=Mat.D.etaA;    % >0 Maxwell Viscosity of Delaunay 1st Branch, <0 dashpot only of Delaunay
            case 7
                param(k)=Mat.D.etaB;    % >0 Maxwell Viscosity of Delaunay 2nd Branch, <0 dashpot only of Delaunay
            case 8
                param(k)=Mat.D.Ec;      % Contractility in Spring Delaunay
            case 9
                param(k)=Mat.D.EcA;     % Contractility in A
            case 10
                param(k)=Mat.D.EcB;     % Contractility in B
            case 11
                param(k)=Mat.D.Ect;     % time at which Contractility in elastic branch =Set.Ec (=0, constant contractility)
            case 12
                param(k)=Mat.D.EcAt;    % time at which Contractility in active branch =Set.EcA (=0, constant contractility)
            case 13
                param(k)=Mat.V.kappa;    %kappa for voronoi vertices stiffness
            case 14
                param(k)=Mat.V.kappaA;   % Stiffness for Active/Maxwell 1st Branch on Voronoi
            case 15
                param(k)=Mat.V.kappaB;   % Stiffness for Active/Maxwell 2nd Branch on Voronoi
            case 16
                param(k)=Mat.V.GammaA;     % Viscossity for Active 1st Branch in voronoi. =0: no viscosity
            case 17
                param(k)=Mat.V.GammaB;     % Viscossity for Active 2nd Branch in voronoi. =0: no viscosity
            case 18
                param(k)=Mat.V.etaA;       % >0 Maxwell Viscosity of Voronoi 1st Branch, <0 dashpot only of Voronoi
            case 19
                param(k)=Mat.V.etaB;       % >0 Maxwell Viscosity of Voronoi 2nd Branch, <0 dashpot only of Voronoi
            case 20
                param(k)=Mat.V.Ec;       % Contractility in Spring Voronoi
            case 21
                param(k)=Mat.V.EcA;      % Constractility in Voronoi
            case 22
                param(k)=Mat.V.EcB;      % Constractility in Voronoi
            case 23
                param(k)=Mat.V.Ect;      % time at which Contractility in elastic branch =Set.EcVor (=0, constant contractility)
            case 24
                param(k)=Mat.V.EcAt;      % time at which Contractility in active branch =Set.EcVorA (=0, constant contractility)
        end
        LB(k)=LBi(i);
        UB(k)=UBi(i);     
    end
end
