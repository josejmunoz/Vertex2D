% Programe that loops on singell analysis with teted paramter values
% in reference:
%
% Junctional and cytoplasmic contributions in wound healing Mosaffa, 
%  P., Tetley R.J., Rodr�guez-Ferran, A., Mao, Y., Mu�oz, J.J. 
%  Journal of the Royal Society Interface, 2020
%
% Payman Mosaffa, J.J. Munoz
% 15/7/2020
clearvars
% Values of Nodal Contractility tested
EcD=[0.5 2.0 5.0 10.0]; 
% Value of Vertex Contractility tested
EcV=0.6;
% Nodal and Vertex Stiffness
k_D=0.2;
k_V=2.0;
% Other values tested on Loop:
%k_D=[0.5 0.75 1.25 1.6 2.0];
%k_V=[1.25 1.75 2.25];
d_val=1.0; % Tolerance for regulated Delaunay.
% Wound contracitlity. Use 2.1/EcV
%e_val=2.1;
for i=1:length(EcD)
    for j=1:length(EcV)
        clf;clc;
        close all;
        e_val=2.1/EcV(j);
        Main(e_val,d_val,k_D,k_V,EcD(i),EcV(j));
    end
end