function [lnodW,lnodFE]=DefineWoundEdge(lnodW,lnodFE,X,Pw,Rw,Set)
if ~isempty(lnodW)
    s=0;
    for i=1:size(lnodW,1)
        if i<2
            X1=X(lnodW(end,1),:);
        else
            X1=X(lnodW(i-1,1),:);
        end
        X2=X(lnodW(i,1),:);
        X3=X(lnodW(i,2),:);
        P1=X2-X1;
        P2=X3-X2;
        s=s+P1(1)*P2(2)-P1(2)*P2(1); % s>0: counter-clockwise order of lnodW, s<0: clockwise order
    end
    if Set.deltaD>0
        tolw=Set.deltaD;  % nodal remodelling tolerance at the wound edge is set equal to the bulk DelaunayR tolerance
    else
        tolw=0.3;  % assigning a defult value if DelaunayR is not used
    end
    tolRw=0.1-0.1*(Set.deltaD-0.1);    % vertex (wound edge length)/(cell perimeter) treshold   
    r=false;
    rr=true;
    while (r || rr) && size(lnodW,1)>3
        w1=zeros(size(lnodW,1),1);
        w2=false(size(lnodW,1),1);
        for i=1:size(lnodW,1)
            if i<2
                X1=X(lnodW(end,1),:);
            else
                X1=X(lnodW(i-1,1),:);
            end
            X2=X(lnodW(i,1),:);
            X3=X(lnodW(i,2),:);
            P1=X2-X1;
            P2=X3-X2;
            P3=X1-X3;
            if (s>0 && P1(1)*P2(2)-P1(2)*P2(1)>0) ||  (s<0 && P1(1)*P2(2)-P1(2)*P2(1)<0)
                p1=norm(P1);
                p2=norm(P2);
                p3=norm(P3);
                w1(i)=((p1+p2-p3)*(p1+p3-p2)*(p2+p3-p1))/(2*p1*p2*p3); % computing the aspect ratio of each pair of consecutive wound edges
                w2(i)= p3<p1 | p3<p2;
            else
                w1(i)=0;
            end
        end
        if rr
            Rw(w1<eps)=Inf;
            [a1,b]=min(Rw);
            a2=0;
        else
            [a2,b]=max(w1);
            a1=tolRw+1;
        end
        if (a2>tolw && w2(b)) || a1<tolRw
            if rr
                if b<2
                    Rw([1 end])=Inf;
                elseif b>length(Rw)-1
                    Rw([1 end-1])=Inf;
                else
                    Rw([b-1 b+1])=Inf;
                end
                Rw(b)=[];
            end
            if b<2
                c1=lnodW(end,:);
                c2=lnodW(1  ,:);
                lnodW(1,:)=[c1(1) c2(2)];
                lnodW(end,:)=[];
            else
                c1=lnodW(b-1,:);
                c2=lnodW(b  ,:);
                lnodW(b,:)=[c1(1) c2(2)];
                lnodW(b-1,:)=[];
            end
            if s>0         % counter-clockwise lnodW
                lnodFE=[lnodFE; [c2(2) c1(1) c1(2)]];
            else           % clockwise lnodW
                lnodFE=[lnodFE;[c2(2) c1(2) c1(1)]];
            end
        elseif rr
            rr=false;
            r=true;
        elseif r
            r=false;
        end
    end
    if size(lnodW,1)<4
        X1=X(lnodW(1,1),:);
        X2=X(lnodW(2,1),:);
        X3=X(lnodW(3,1),:);
        P1=X2-X1;
        P2=X3-X2;
        s=P1(1)*P2(2)-P1(2)*P2(1);
        if s>0 % counter-clockwise order 
            lnodFE=[lnodFE;[lnodW(1,1) lnodW(2,1) lnodW(3,1)]];  
        else   % clockwise order
            lnodFE=[lnodFE;[lnodW(1,1) lnodW(3,1) lnodW(2,1)]];
        end
        lnodW=zeros(0,2);
    end
end
end