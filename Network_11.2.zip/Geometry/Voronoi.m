function [Vor]=Voronoi(FE,N,X)
Vor=zeros(size(FE,1),2);
for i=1:size(FE,1)
    Vor(i,:)=N(i,1)*X(FE(i,1),:)+N(i,2)*X(FE(i,2),:)+N(i,3)*X(FE(i,3),:);
end
end