function CreatvtkDel2D(step,X0,X,lnod,stress,Bcells,Ab,AbActive,wound,ln,nodError)
if wound
    str0='VTKResultsWound';
    stress.T=stress.T(Ab.eleDDL);
    stress.S=stress.S(Ab.eleDDL);
    stress.A=stress.A(Ab.eleDDL);
    stress.B=stress.B(Ab.eleDDL);
    ln.A.r=ln.A.r(Ab.eleDDL);
    ln.A.c=ln.A.c(Ab.eleDDL);
    ln.S.c=ln.S.c(Ab.eleDDL);
else
    str0='VTKResults';
end
str2='.vtk';
str3 = num2str(step);
str13=strcat(str0,str3);
comp=computer;
if strcmp(comp(1:3),'PCW') % Windows machine
    newSubFolder = sprintf('%s\\%s',pwd,str0);
else
    newSubFolder = sprintf('%s/%s',pwd,str0);
end
if ~exist(newSubFolder, 'dir')
    mkdir(newSubFolder);
end
cd(newSubFolder);
% if i==0
%     if exist(newSubFolder,'file')
%         system('rm *.vtk');
%     end
% end
nameout=strcat(str13,str2);
file=fopen(nameout,'w');
fprintf(file,'%s\n','# vtk DataFile Version 3.98');
fprintf(file,'%s\n','Delaunay_vtk');
fprintf(file,'%s\n','ASCII');
fprintf(file,'%s\n','DATASET UNSTRUCTURED_GRID');
%%%%%%%%%%%%
if AbActive
    lnod(Ab.eleDDL,:)=[];
    stress.T(Ab.eleDDL)=[];
    stress.S(Ab.eleDDL)=[];
    stress.A(Ab.eleDDL)=[];
    stress.B(Ab.eleDDL)=[];
    ln.A.r(Ab.eleDDL)=[];
    ln.A.c(Ab.eleDDL)=[];
    ln.S.c(Ab.eleDDL)=[];
end
% if wound    %% re-indexing elements (lnod) 
%     nodes=length(Ab.nodAb1);
%     aux=1:nodes;
%     lnod1=zeros(length(Ab.eleDDL),2);
%     for i=1:length(Ab.eleDDL)
%         lnod1(i,1)=aux(Ab.nodAb1==lnod(i,1));
%         lnod1(i,2)=aux(Ab.nodAb1==lnod(i,2));
%     end
%     lnod=lnod1;    
% else
nodes=size(X0,1);
% end
fprintf(file,'%s %d %s\n','POINTS',nodes,'float');
dim=size(X,2);
for i=1:nodes
    if dim==2
        fprintf(file,' %f %f %f\n',X(i,1),X(i,2),0);
    else
        fprintf(file,' %f %f %f\n',X(i,1),X(i,2),X(i,3));
    end
end
% neleFE=size(lnodFE,1);
if Bcells==1
    i=find(lnod(:,1)>nodes | lnod(:,2)>nodes); % Not in 3D
    stress.T(i,:)=[];
    stress.S(i,:)=[];
    stress.A(i,:)=[];
    stress.B(i,:)=[];
    ln.A.r(i)=[];
    ln.S.c(i)=[];
    ln.A.c(i)=[];
    ln.S.e(i)=[];
    lnod(i,:)=[];
end
nele=size(lnod,1);
% lnodFEd=lnodFE-1;
fprintf(file,'%s %d %d\n','CELLS',nele,nele*(size(lnod(1,:),2)+1));
% for j=1:size(lnodFEd,1)
%     if dim==3
%         fprintf(file,'%d %d %d %d %d\n',size(lnodFEd(j,:),2),lnodFEd(j,1),lnodFEd(j,2),lnodFEd(j,3),lnodFEd(j,4));
%     elseif dim==2
%         fprintf(file,'%d %d %d %d\n',size(lnodFEd(j,:),2),lnodFEd(j,1),lnodFEd(j,2),lnodFEd(j,3));
%     end
% end
lnodd=lnod-1;
for j=1:size(lnodd,1)
    fprintf(file,'%d %d %d\n',size(lnodd(j,:),2),lnodd(j,1),lnodd(j,2));
end
% fprintf(file,'%s %d\n','CELL_TYPES',neleFE+nele);
% for j=1:size(lnodFE,1)
%     if dim==3
%         fprintf(file,'%d\n',10);
%     elseif dim==2
%         fprintf(file,'%d\n',5);
%     end
% end
% for j=1:size(lnod,1)
%     fprintf(file,'%d\n',3);
% end
fprintf(file,'%s %d\n','CELL_TYPES',nele);
for j=1:size(lnod,1)
    fprintf(file,'%d\n',3);
end
%%%%%%%Results%%%%%%%%%%
fprintf(file,'%s %d\n','POINT_DATA',nodes);
fprintf(file,'%s \n','VECTORS  Displacements float');
for k=1:nodes
    if dim==2 || nodes==2
        fprintf(file,'%f   %f   %f\n',X(k,1)-X0(k,1),X(k,2)-X0(k,2),0.0);
    else
        fprintf(file,'%f   %f   %f \n',x(3*k-2)-x0(3*k-2),x(3*k-1)-x0(3*k-1),x(3*k)-x0(3*k));
    end
end
%
fprintf(file,'%s \n','SCALARS MapError float');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for k=1:nodes
    if abs(nodError(k))<eps
    fprintf(file,'%f\n',-16);
    else
    fprintf(file,'%f\n',log10(abs(nodError(k))));
    end
end
%%%%%%%%%%%%%%%%%%%%%%%
fprintf(file,'%s %d \n','CELL_DATA',nele);
% fprintf(file,'%s \n','SCALARS stress float ');
% fprintf(file,'%s \n','LOOKUP_TABLE default');
% fprintf(file,'%f\n',zeros(size(lnod,1),1));
fprintf(file,'%s \n','SCALARS stressTot float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(stress.T)
    fprintf(file,'%f\n',stress.T(i,1));
end
%
fprintf(file,'%s \n','SCALARS stressSpring float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(stress.S)
    fprintf(file,'%f\n',stress.S(i,1));
end
%
fprintf(file,'%s \n','SCALARS stressA float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(stress.A)
    fprintf(file,'%f\n',stress.A(i,1));
end
%
fprintf(file,'%s \n','SCALARS stressB float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(stress.B)
    fprintf(file,'%f\n',stress.B(i,1));
end
fprintf(file,'%s \n','SCALARS DRelRestingLengthA float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:min(length(ln.A.r),length(ln.S.e))
    fprintf(file,'%f\n',ln.A.r(i)/ln.S.e(i));
end
fprintf(file,'%s \n','SCALARS DContractilityS float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(ln.S.c)
    fprintf(file,'%f\n',ln.S.c(i));
end
fprintf(file,'%s \n','SCALARS DContractilityA float ');
fprintf(file,'%s \n','LOOKUP_TABLE default');
for i=1:length(ln.A.c)
    fprintf(file,'%f\n',ln.A.c(i));
end
fclose(file);
cd '..'