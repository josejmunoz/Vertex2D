function [g,K,gD,gV,gA,ln,Eps,stress,stressVol,V,eD,eV,eVol]=Mechanics(BC,X,x,xp,x0,Vor,Vorp,Vor0,V0,VW0,Mat,Set,Ab,Step,dim,nodes,nodes0,nodesV,nodV,N,xi,xip,ln,lnodFE,lnod,lnodExternal,lnodW,lnod_vor,Lumen,vor_cell,vor_cellW,ld,Vor_stiff,edgesize,C)
[eD,g,K,ln.D.n1,Eps,stress.D.n1]=...
        gKDelaunay(ld{Mat.D.DEnd}.D,ln.D.n,...
        nodes,nodesV,nodes0,dim,Step.dt,Mat.D,lnod,Step.theta,x,xp,x0,Set,Ab);
    %%%%%%%%%%%%%%%%%%%%
    g_xb=0;
    if ~BC.FullConstr && Set.Network~=0 && abs(BC.mu)>eps  %%Viscous/elastic term on free boundary
        [g_xb,K_xb]=gKb(x,x0,Vor,Vorp,dim,nodes,nodesV,Set,nodV,lnod,lnodExternal,lnodW,lnod_vor);
        g=g+BC.mu*g_xb;
        K=K+BC.mu*K_xb;
    end
    gD=g;
    %%%%%%%%%%%%%%%%%%%%
    if (Vor_stiff || abs(Set.Vp)>eps) && Set.Network~=0 && abs(Set.lambda)>eps  %Penalisation on interpolation
        [g_xi,K_xi]=gKXi(dim,nodes,nodesV,Vor,Vorp,xi,xip,Set);
        g=g+Set.lambda*g_xi;
        K=K+Set.lambda*K_xi;
    end
    %%%%%%%%%%%%%%%%%%%%
    if (Vor_stiff || Set.Vp>eps) && Set.Network~=0
        if abs(Set.Vp)>eps %Volume constraint
            [eVol,g_v,K_o,~,V,stressVol]=gkVoronoiVolume(X,lnodFE,N,Vor,vor_cell,vor_cellW,lnod_vor,V0,VW0,nodes,Ab,Set,C);
%             if isempty(lnodW)
%                 Set.Vp=5*Set.Vp;
%             end
            g=g+Set.Vp*g_v;
            K=K+Set.Vp*K_o;
            gA=Set.Vp*g_v;
        else
            gA=zeros(size(g));
            eVol=0;
        end
        if Vor_stiff  %mechanics on tessallation
            [eV,g_vor,K_o,ln.V.n1,stress.V.n1]=gKVoronoi(Mat.V,N,lnod_vor,lnodFE,Vor,Vor0,Vorp,X,Step.dt,ld{Mat.V.DEnd}.V,ln.V.n,Step.theta,Ab,Set,edgesize);
            g=g+g_vor;
            K=K+K_o;
            gV=g_vor;
        else
            gV=zeros(size(g));
            eV=0;
        end
    else
        gV=zeros(size(g));
        gA=gV;
        eVol=0;
        eV=0;
    end
    gV=gV+BC.mu*g_xb;
    %%%%%%%%%%%%%%%%%%%%
    if (size(Lumen,1) > 0)
        [g_pres,K_pres]=gKPressure(lnodFE,Lumen,N,Set,Vor,X);
        g=g+g_pres;
        K=K+K_pres;
    end
end