function [Vor,N,xi]=VoronoiInterpol(Vorp,X,lnodFE,Set,xi,i)
Vor=zeros(size(lnodFE,1),2);
if i==0
    if Set.tess
        xi=Vor;
        for i=1:size(lnodFE,1)  %%obtaining Voronoi vertices. Not in 3D
            s=1/(2*((X(lnodFE(i,2),1)-X(lnodFE(i,1),1))*(X(lnodFE(i,3),2)-X(lnodFE(i,1),2))-(X(lnodFE(i,3),1)-X(lnodFE(i,1),1))*(X(lnodFE(i,2),2)-X(lnodFE(i,1),2))));
            Vor(i,:)=s*[(X(lnodFE(i,3),2)-X(lnodFE(i,1),2))*(norm(X(lnodFE(i,2),:))^2-norm(X(lnodFE(i,1),:))^2)-(X(lnodFE(i,2),2)-X(lnodFE(i,1),2))*(norm(X(lnodFE(i,3),:))^2-norm(X(lnodFE(i,1),:))^2) (X(lnodFE(i,2),1)-X(lnodFE(i,1),1))*(norm(X(lnodFE(i,3),:))^2-norm(X(lnodFE(i,1),:))^2)-(X(lnodFE(i,3),1)-X(lnodFE(i,1),1))*(norm(X(lnodFE(i,2),:))^2-norm(X(lnodFE(i,1),:))^2)];
            %%obtaining Vronoi vertices in local coordinates respected to triangles edges
            s=[X(lnodFE(i,3),2)-X(lnodFE(i,1),2) X(lnodFE(i,1),2)-X(lnodFE(i,2),2)
                X(lnodFE(i,1),1)-X(lnodFE(i,3),1) X(lnodFE(i,2),1)-X(lnodFE(i,1),1)];
            xi(i,:)=(Vor(i,:)-X(lnodFE(i,1),1:2))*(s/det(s));
        end
        N=[1-xi(:,1)-xi(:,2) xi(:,1) xi(:,2)];
    else
        N=ones(size(lnodFE,1),3)/3;
        xi=ones(size(lnodFE,1),2)/3;
        Vor=Voronoi(lnodFE,N,X);
    end
    xi=reshape(xi',size(lnodFE,1)*size(X,2),1);
elseif Set.Xirel>0 && Set.Bcells<0 && Set.Vrel
    Vor=Vorp;
    XI=reshape(xi,size(X,2),size(lnodFE,1))';
    N=[1-XI(:,1)-XI(:,2) XI(:,1) XI(:,2)];
else
    XI=reshape(xi,size(X,2),size(lnodFE,1))';
    N=[1-XI(:,1)-XI(:,2) XI(:,1) XI(:,2)];
    Vor=Voronoi(lnodFE,N,X);
end
end
