function [eD,err,gel,Kel,Eps_elas,Ec1,Ec1A,Ec1B,lrn1A,lrn1B,ln1,G_tot,Gs,GAcA,GAcB]=...
    ActiveElas...
    (dt,Ec0,Ec0A,Ec0B,Ec,EcA,EcB,err,ld,lrnA,lrnB,Mat,tAb,theta,x1,x1p,x2,x2p,x10,x20,Set)
%Two Active element and a linear elastic element connected in parallel,
% Total 3 branches:
% Spring branch
% Branch A: active element.
% Branch B: active element.
% nDelay: time delay for rest length of evolution law in branch A
% ld  = Contains retlength and current length at time (t-Delay)
dim=length(x1);
kappa=Mat.kappa;
kappaA=Mat.kappaA;
kappaB=Mat.kappaB;
GammaA=Mat.GammaA;
GammaB=Mat.GammaB;
Delay=0;
DelayA=Mat.nDelay;
DelayB=0;
beta=Mat.beta;
betaA=Mat.betaA;
betaB=Mat.betaB;
gel=zeros(2*dim,1);
Kel=zeros(2*dim);
lrn1A=lrnA;
lrn1B=lrnB;
ln1=lrnA; % Initialise
Eps_elas=0;
e1=0;
e2=0;
e3=0;
Gs=0;
GA=0;
GB=0;
Ec1=Ec;
Ec1A=EcA;
Ec1B=EcB;
%Active elementA, Active elementB, and a linear elastic element connected in parallel
if abs(kappa)>0
    [e1,Ec1,err,gel,Kel,~,Eps_elas,ln1,Gs]=ActiveLineElem(beta,Delay,dt,Ec0,Ec,err,0,kappa,ld,lrnA,tAb,theta,[x1 x2],[x1p x2p],[x10 x20],Set);
end
if abs(kappaA)>0
    [e2,Ec1A,err,gacA,KacA,lrn1A,Eps_A,ln1,GA]=ActiveLineElem(betaA,DelayA,dt,Ec0A,EcA,err,GammaA,kappaA,ld,lrnA,tAb,theta,[x1 x2],[x1p x2p],[x10 x20],Set); %element 1
    gel=gel+gacA;
    Kel=Kel+KacA;
    if abs(kappa)<eps
        Eps_elas=Eps_A;
    end
end
if abs(kappaB)>0
    [e3,Ec1B,err,gacB,KacB,lrn1B,Eps_B,ln1,GB]=ActiveLineElem(betaB,DelayB,dt,Ec0B,EcB,err,GammaB,kappaB,ld,lrnB,tAb,theta,[x1 x2],[x1p x2p],[x10 x20],Set);  %element 2
    gel=gel+gacB;
    Kel=Kel+KacB;
    if abs(kappa)<eps
        Eps_elas=Eps_B;
    end
end
G_tot=Gs+GA+GB;
GAcA=GA;
GAcB=GB;
eD=e1+e2+e3;
end
