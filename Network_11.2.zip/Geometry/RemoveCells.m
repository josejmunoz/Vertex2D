function [X,x,X0,x0,xp,dofx,cdof,vext,nodes,nodes0,g,g_v,gD,gV,g_xi,FE0,FEp,...
    xip,lnodp,Vp,V0,V00,Vol,ln,lnodvp,Ab]=RemoveCells(X,x,X0,x0,xp,dofx,cdof,vext,nodes,nodV,...
    nodes0,g,g_v,gD,gV,g_xi,FE0,FEp,xip,lnodp,Vp,V0,V00,Vol,ln,lnodvp,Ab)
dim=size(X,2);
Xad=sum(X(Ab.nodAb,:))/length(Ab.nodAb);  %%defining one node for wounded area as the medium of all nodes
%in the wound
X(Ab.nodAb,:)=[];                         %%removing wounded cells
X=[Xad;X];
X0(Ab.nodAb,:)=[];
X0=[Xad;X0];
aux=Ab.nodAb+1;
auxn=nodes+1;
m=1:dim*auxn;
dofx=[1:dim dofx+dim];
vext=[zeros(1,dim) vext];
g=[zeros(1:dim)';g];
gD=[zeros(1:dim)';gD];
gV=[zeros(1:dim)';gV];
g_v=[zeros(1:dim)';g_v];
g_xi=[zeros(1:dim)';g_xi];
if dim==2
    xp([dim*Ab.nodAb-1 dim*Ab.nodAb])=[];
    m([dim*aux-1 dim*aux])=[];
    vext([dim*aux-1 dim*aux])=[];
    g([dim*aux-1 dim*aux])=[];
    gD([dim*aux-1 dim*aux])=[];
    gV([dim*aux-1 dim*aux])=[];
    g_v([dim*aux-1 dim*aux])=[];
    g_xi([dim*aux-1 dim*aux])=[];
else
    xp([dim*Ab.nodAb-2 dim*Ab.nodAb-1 dim*Ab.nodAb])=[];
    m([dim*aux-2 dim*aux-1 dim*aux])=[];
    vext([dim*aux-2 dim*aux-1 dim*aux])=[];
    g([dim*aux-2 dim*aux-1 dim*aux])=[];
    gD([dim*aux-2 dim*aux-1 dim*aux])=[];
    gV([dim*aux-2 dim*aux-1 dim*aux])=[];
    g_v([dim*aux-2 dim*aux-1 dim*aux])=[];
    g_xi([dim*aux-2 dim*aux-1 dim*aux])=[];
end
I=1:length(m);
for i=1:length(cdof)
    cdof(i)=I(m==cdof(i));
end
I=ismember(m,dofx);
nodes=size(X,1);
nodes0=nodes0-length(Ab.nodAb)+1;
m=1:dim*nodes;
dofx=m(I);
xp=[reshape(Xad,1,dim) xp];
x=reshape(X',nodes*dim,1)';
x0=reshape(X0',nodes*dim,1)';
FE0=FE0+1;
FEp=FEp+1;
I0=ismember(FE0,aux);
FE0(I0)=1;
I0=sum(I0,2);
FE0(I0>1,:)=[];
V0(I0>1,:)=[];
V00=V0;
Ip=ismember(FEp,aux);
FEp(Ip)=1;
Ip=sum(Ip,2);
FEp(Ip>1,:)=[];
Vp(Ip>1,:)=[];
I=1:auxn;
I(aux)=[];
m=1:nodes;
for i=1:size(FE0,1)
    FE0(i,1)=m(I==FE0(i,1));
    FE0(i,2)=m(I==FE0(i,2));
    FE0(i,3)=m(I==FE0(i,3));
end
for i=1:size(FEp,1)
    FEp(i,1)=m(I==FEp(i,1));
    FEp(i,2)=m(I==FEp(i,2));
    FEp(i,3)=m(I==FEp(i,3));
end
xip=reshape(xip',dim,size(xip,1)/dim)';
xip(Ip>1,:)=[];
I=find(sum(FEp==1,2));
for i=1:length(I)
    X1=X(FEp(I(i),1),:);
    X2=X(FEp(I(i),2),:);
    X3=X(FEp(I(i),3),:);
    xip(I(i),:)=[X3(2)-X1(2) X1(1)-X3(1);X1(2)-X2(2) X2(1)-X1(1)]*(Vp(I(i),:)-X1)'/((X2(1)-X1(1))*(X3(2)-X1(2))-(X3(1)-X1(1))*(X2(2)-X1(2)));
end
xip=reshape(xip',dim*size(FEp,1),1);
lnodp=lnodp+1;
Id=ismember(lnodp,aux);
lnodp(Id)=1;
Id=sum(Id,2);
lnodp(Id>1,:)=[];
Iv=Id(1:size(lnodvp,1));
lnodvp(Iv>1,:)=[];
s=find(lnodp(:,1)==1 | lnodp(:,2)==1);
lnods=sort(lnodp(s,:),2);
[B,I]=sort(lnods(:,2));
s=s(I);
ss1=find(diff(B)==0);
ss2=ss1+1;
lnodp(s(ss1),:)=[];
for i=1:length(ss1)
    if lnodvp(s(ss1(i)),1)==lnodvp(s(ss2(i)),1)
        lnodvp(s(ss2(i)),:)=[lnodvp(s(ss1(i)),2) lnodvp(s(ss2(i)),2)];
    elseif lnodvp(s(ss1(i)),1)==lnodvp(s(ss2(i)),2)
        lnodvp(s(ss2(i)),:)=[lnodvp(s(ss1(i)),2) lnodvp(s(ss2(i)),1)];
    elseif lnodvp(s(ss1(i)),2)==lnodvp(s(ss2(i)),1)
        lnodvp(s(ss2(i)),:)=[lnodvp(s(ss1(i)),1) lnodvp(s(ss2(i)),2)];
    else
        lnodvp(s(ss2(i)),:)=[lnodvp(s(ss1(i)),1) lnodvp(s(ss2(i)),1)];
    end
end
lnodvp(s(ss1),:)=[];
I=1:length(Ip);
I(Ip>1)=[];
m=1:size(FEp,1);
for i=1:size(lnodvp,1)
    lnodvp(i,1)=m(I==lnodvp(i,1));
    lnodvp(i,2)=m(I==lnodvp(i,2));
end
ln.D.n.A.r=ln.D.n.A.r(Id<=1);
ln.D.n.A.e=ln.D.n.A.e(Id<=1);
ln.D.n.A.c=ln.D.n.A.c(Id<=1);
ln.D.n.B.r=ln.D.n.B.r(Id<=1);
ln.D.n.B.e=ln.D.n.B.e(Id<=1);
ln.D.n.B.c=ln.D.n.B.c(Id<=1);
ln.D.n.S.e=ln.D.n.S.e(Id<=1);
ln.D.n.S.c=ln.D.n.S.c(Id<=1);
ln.D.n1.A.r=ln.D.n1.A.r(Id<=1);
ln.D.n1.A.e=ln.D.n1.A.e(Id<=1);
ln.D.n1.A.c=ln.D.n1.A.c(Id<=1);
ln.D.n1.B.r=ln.D.n1.B.r(Id<=1);
ln.D.n1.B.e=ln.D.n1.B.e(Id<=1);
ln.D.n1.B.c=ln.D.n1.B.c(Id<=1);
ln.D.n1.S.e=ln.D.n1.S.e(Id<=1);
ln.D.n1.S.c=ln.D.n1.S.c(Id<=1);
ln.D.n.A.r(s(ss1))=[];
ln.D.n.A.e(s(ss1))=[];
ln.D.n.A.c(s(ss1))=[];
ln.D.n.B.r(s(ss1))=[];
ln.D.n.B.e(s(ss1))=[];
ln.D.n.B.c(s(ss1))=[];
ln.D.n.S.e(s(ss1))=[];
ln.D.n.S.c(s(ss1))=[];
ln.D.n1.A.r(s(ss1))=[];
ln.D.n1.A.e(s(ss1))=[];
ln.D.n1.A.c(s(ss1))=[];
ln.D.n1.B.r(s(ss1))=[];
ln.D.n1.B.e(s(ss1))=[];
ln.D.n1.B.c(s(ss1))=[];
ln.D.n1.S.e(s(ss1))=[];
ln.D.n1.S.c(s(ss1))=[];
ln.V.n.A.r=ln.V.n.A.r(Iv<=1);
ln.V.n.A.e=ln.V.n.A.e(Iv<=1);
ln.V.n.A.c=ln.V.n.A.c(Iv<=1);
ln.V.n.B.r=ln.V.n.B.r(Iv<=1);
ln.V.n.B.e=ln.V.n.B.e(Iv<=1);
ln.V.n.B.c=ln.V.n.B.c(Iv<=1);
ln.V.n.S.e=ln.V.n.S.e(Iv<=1);
ln.V.n.S.c=ln.V.n.S.c(Iv<=1);
ln.V.n1.A.r=ln.V.n1.A.r(Iv<=1);
ln.V.n1.A.e=ln.V.n1.A.e(Iv<=1);
ln.V.n1.A.c=ln.V.n1.A.c(Iv<=1);
ln.V.n1.B.r=ln.V.n1.B.r(Iv<=1);
ln.V.n1.B.e=ln.V.n1.B.e(Iv<=1);
ln.V.n1.B.c=ln.V.n1.B.c(Iv<=1);
ln.V.n1.S.e=ln.V.n1.S.e(Iv<=1);
ln.V.n1.S.c=ln.V.n1.S.c(Iv<=1);
ln.V.n.A.r(s(ss2))=ln.V.n.A.r(s(ss1))+ln.V.n.A.r(s(ss2));
ln.V.n.A.r(s(ss1))=[];
ln.V.n.A.e(s(ss2))=ln.V.n.A.e(s(ss1))+ln.V.n.A.e(s(ss2));
ln.V.n.A.e(s(ss1))=[];
ln.V.n.A.c(s(ss1))=[];
ln.V.n.B.r(s(ss2))=ln.V.n.B.r(s(ss1))+ln.V.n.B.r(s(ss2));
ln.V.n.B.r(s(ss1))=[];
ln.V.n.B.e(s(ss2))=ln.V.n.B.e(s(ss1))+ln.V.n.B.e(s(ss2));
ln.V.n.B.e(s(ss1))=[];
ln.V.n.B.c(s(ss1))=[];
ln.V.n.S.e(s(ss2))=ln.V.n.S.e(s(ss1))+ln.V.n.S.e(s(ss2));
ln.V.n.S.e(s(ss1))=[];
ln.V.n.S.c(s(ss1))=[];
ln.V.n1.A.r(s(ss2))=ln.V.n1.A.r(s(ss1))+ln.V.n1.A.r(s(ss2));
ln.V.n1.A.r(s(ss1))=[];
ln.V.n1.A.e(s(ss2))=ln.V.n1.A.e(s(ss1))+ln.V.n1.A.e(s(ss2));
ln.V.n1.A.e(s(ss1))=[];
ln.V.n1.A.c(s(ss1))=[];
ln.V.n1.B.r(s(ss2))=ln.V.n1.B.r(s(ss1))+ln.V.n1.B.r(s(ss2));
ln.V.n1.B.r(s(ss1))=[];
ln.V.n1.B.e(s(ss2))=ln.V.n1.B.e(s(ss1))+ln.V.n1.B.e(s(ss2));
ln.V.n1.B.e(s(ss1))=[];
ln.V.n1.B.c(s(ss1))=[];
ln.V.n1.S.e(s(ss2))=ln.V.n1.S.e(s(ss1))+ln.V.n1.S.e(s(ss2));
ln.V.n1.S.e(s(ss1))=[];
ln.V.n1.S.c(s(ss1))=[];
I=ismember(nodV,Ab.nodAb);
Vol1=sum(Vol(I));
Vol(I)=[];
Ab.nodAb=1;
Vol=[Vol1;Vol];
end