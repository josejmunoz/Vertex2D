function [doc,nodAb]=SetBoundary(doc,lnodExternal,X,Set)
Ablation=Set.Ablation;
nodes=size(X,1);
nodAb=1:nodes;
%%%AbCent:laser beam centre coordination is set to the mean of all nodes on the boundary of the tissue
AbCent=sum(X(lnodExternal(:,1),1:2))/size(lnodExternal,1);
%%%Cheking which cells are within the domain of laser beam
AbRad=Ablation*sqrt((max(X(:,1))-min(X(:,1)))*(max(X(:,2))-min(X(:,2)))/nodes); %%AbRad=Ablation*units of mean cell size
aux1=ones(nodes,1)*AbCent;
aux2=sqrt(sum((X(:,1:2)-aux1).^2,2));
nodAb(aux2>=AbRad)=[];
doc=doc(ismember(doc,[2*nodAb-1;2*nodAb]));
end