function [x,X]=ModifyX(Ab,X,x,V,vor_cell,nodV,doc,Set,iter)
% Modifies positions of wounded nodes
dim=size(X,2);
nodes=size(X,1);
if Set.Xirel>0 && Set.Vrel && Set.Bcells<0
    for i=1:length(nodV)
        nv=vor_cell{nodV(i)};
        nv(end)=[];
        d=dim*(nodV(i)-1)+1:dim*nodV(i);
        A=0;
        B=0;
        for j=1:(length(nv)-1)
            a=(V(nv(j),1)*V(nv(j+1),2)-V(nv(j+1),1)*V(nv(j),2));
            A=A+a;
            B=B+(V(nv(j),:)+V(nv(j+1),:))*a;
        end
        a=V(nv(end),1)*V(nv(1),2)-V(nv(1),1)*V(nv(end),2);
        A=A+a;
        B=B+(V(nv(end),:)+V(nv(1),:))*a;
        x(d)=B/(A*3);
%        x(d)=sum(V(nv,:))/length(nv);
    end
    X=reshape(x',dim,nodes)';
elseif Ab.active && ~iter && length(Ab.nodAb)>0
    nx=nodV(Ab.cellAb);
    for n=1:length(nx)
        nv=vor_cell{Ab.cellAb(n)};
        nv(end)=[];
        d=dim*(nx(n)-1)+1:dim*nx(n);
        if ~ismember(d,doc)
            x(d)=sum(V(nv,:))/length(nv);
        end
    end
    X=reshape(x',dim,nodes)';
end
end