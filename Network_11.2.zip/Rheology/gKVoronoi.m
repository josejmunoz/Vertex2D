function [eV,g,K,ln1,stress]=gKVoronoi(Mat,N,lnod,FE,Vor,Vor0,Vorp,X,dt,ld,ln,theta,Ab,Set,edgesize)
ld=zeros(size(lnod,1),1);
Maxwell=abs(Mat.etaA)>eps || abs(Mat.etaB)>eps;
nodes=size(X,1); %node positions
nodesV=size(Vor,1); %vertices - Voronoi nodes
sizet=size(FE,1); %FE = lnodFE = triangles in delaunay triangulation
sizext=length(edgesize); %number of boundary vertex elements
dim=size(X,2); %dimensions of nodes (2D so 2)
nele=size(lnod,1); %number of elements in Voronoi
vdim=(dim+1)*dim;
xidim=dim; 
if Set.sparseM %
    r=zeros(nele*2*(vdim+xidim)*2*(vdim+xidim),1); %?
    c=r;
    v=r;
    s=0;
else
    K=zeros(dim*(nodes+nodesV),dim*(nodes+nodesV));
end
%% Creating all the matrices, lists and variables to later fill (all zeros)
g=zeros(dim*(nodes+nodesV),1); %gvoronoi
ge=zeros(2*(vdim+xidim),1); %gelastic
Ke=zeros(2*(vdim+xidim),2*(vdim+xidim)); %K elastic
KeA=zeros(2*(vdim+xidim),2*(vdim+xidim)); %
KeB=zeros(2*(vdim+xidim),2*(vdim+xidim));
geA=zeros(2*(vdim+xidim),1);
geB=zeros(2*(vdim+xidim),1);
ln1.A.r=zeros(nele,1);
ln1.B.r=zeros(nele,1);
ln1.A.e=zeros(nele,1);
ln1.B.e=zeros(nele,1);
ln1.A.c=zeros(nele,1);
ln1.B.c=zeros(nele,1);
ln1.S.e=zeros(nele,1);
ln1.S.c=zeros(nele,1);
stress.T=zeros(nele,1);
stress.A=stress.T;
stress.B=stress.T;
stress.S=stress.T;
eV=0;
ener1=0;
ener2=0;
ener3=0;
Gs=0;
GA=0;
GB=0;
err=0;

%%
for e=1:nele %loop over all elements
    %Assign material parameters using AssignMat
    [eleGammaA,eleGammaB,eleetaA,eleetaB,elek,elekA,elekB,eleEc,eleEcA,eleEcB]=AssignMat(Ab,e,ln,Mat,Set.t,Set);
    if Set.DispBased && Set.Bcells<0 && e>nele-sizext
        elek =elek*edgesize(e-nele+sizext);
        elekA=elekA*edgesize(e-nele+sizext);
        elekB=elekB*edgesize(e-nele+sizext);
    end
    if Set.Vrel && Ab.active
       VDL=unique([lnod(Ab.eleVorDL,1);lnod(Ab.eleVorDL,2)]); %nodes connection Dead-live cells
    else
       VDL=[];
    end  
    n=[lnod(e,1) lnod(e,2)];
    if Set.Xirel>0 && Set.Vrel
        I=false(2,1);
    else
        I= n<=sizet & (~ismember(n,VDL)  & Set.Vrel);
    end
    ve =[Vor(n(1),:);Vor(n(2),:)]; %element creation between Voronoi nodes
    ve0=[Vor0(n(1),:);Vor0(n(2),:)]; %difference 0?
    vep=[Vorp(n(1),:);Vorp(n(2),:)]; %difference p?
    if I(1)
        xe1=X(FE(n(1),:),:); 
    else
        xe1=[];
    end
    if I(2)
        xe2=X(FE(n(2),:),:);
    else
        xe2=[];
    end
    % Elastic branch
    if abs(elek)>eps
        [ener1,ln1.S.c(e),err,ge,Ke,~,~,ln1.S.e(e),Gs]=gkElemVor(Mat.beta,Mat.nDelay,dt,Mat.Ec,eleEc,0,err,0,elek,ld(e),ln.S.e(e),ln.S.e(e),Maxwell,n,N,Ab.tAb,theta,xe1,xe2,ve,ve0,vep,Set,I);
    end
    % Active,Maxwell,Kelvin branch A
    if abs(elekA)>eps || eleetaA<0                eleEc=Ab.Ec*Mat.Ec;
        [ener2,ln1.A.c(e),err,geA,KeA,ln1.A.r(e),ln1.A.e(e),ln1.S.e(e),GA]=gkElemVor(Mat.betaA,Mat.nDelayA,dt,Mat.EcA,eleEcA,err,eleetaA,eleGammaA,elekA,ld(e),ln.A.e(e),ln.A.r(e),Maxwell,n,N,Ab.tAb,theta,xe1,xe2,ve,ve0,vep,Set,I);
    end
    % Active,Maxwell,Kelvin branch B
    if abs(elekB)>eps || eleetaB<0
        [ener3,ln1.B.c(e),err,geB,KeB,ln1.B.r(e),ln1.B.e(e),ln1.S.e(e),GB]=gkElemVor(Mat.betaB,Mat.nDelayB,dt,Mat.EcB,eleEcB,err,eleetaB,eleGammaB,elekB,ld(e),ln.B.e(e),ln.B.r(e),Maxwell,n,N,Ab.tAb,theta,xe1,xe2,ve,ve0,vep,Set,I);
    end
    G_tot=Gs+GA+GB;
    stress.T(e,:)=G_tot;
    stress.A(e,:)=GA;
    stress.B(e,:)=GB;
    stress.S(e,:)=Gs;
    if I(1)
        vdim1=(dim+1)*dim;
        aux1=zeros(1,vdim);
        aux1([1 3 5])=2*FE(n(1),:)-1;
        aux1([2 4 6])=2*FE(n(1),:);
    else
        aux1=[];
        vdim1=0;
    end
    if I(2)
        vdim2=(dim+1)*dim;
        aux2=zeros(1,vdim);
        aux2([1 3 5])=2*FE(n(2),:)-1;
        aux2([2 4 6])=2*FE(n(2),:);
    else
        vdim2=0;
        aux2=[];
    end
    auxxi1=dim*nodes+(dim*(n(1)-1)+1:dim*n(1));
    auxxi2=dim*nodes+(dim*(n(2)-1)+1:dim*n(2));
    auxxi=[auxxi1 auxxi2];
    aux=[aux1 aux2 auxxi]';
    g(auxxi)=g(auxxi)+ge(end-2*dim+1:end)+geA(end-2*dim+1:end)+geB(end-2*dim+1:end);
    if I(1)
        g(aux1)=g(aux1)+ge(1:vdim1)+geA(1:vdim1)+geB(1:vdim1);
    end
    if I(2)
        g(aux2)=g(aux2)+ge(vdim1+1:vdim1+vdim2)+geA(vdim1+1:vdim1+vdim2)+geB(vdim1+1:vdim1+vdim2);
    end
    if Set.sparseM
        for i=1:(vdim1+vdim2+2*xidim)
            for j=1:(vdim1+vdim2+2*xidim)
                s=s+1;
                r(s)=aux(i);
                c(s)=aux(j);
                v(s)=Ke(i,j)+KeA(i,j)+KeB(i,j);
            end
        end
    else
        for i=1:(vdim1+vdim2+2*xidim)
            for j=1:(vdim1+vdim2+2*xidim)
                K(aux(i),aux(j))=K(aux(i),aux(j))+Ke(i,j)+KeA(i,j)+KeB(i,j);
            end
        end
    end
    eV=eV+ener1+ener2+ener3;
end
if Set.sparseM
    K=sparse(r(1:s),c(1:s),v(1:s),dim*(nodes+nodesV),dim*(nodes+nodesV));
end
end
% Elemental function
function [ener,Ec1,err,ge,Ke,lrn1,ln1_elas,ln1,G]=gkElemVor(beta,Delay,dt,Ec0,Ec,err,eta,Gamma,k,ld,ln_elas,lrn,Maxwell,n,N,tAb,theta,xe1,xe2,ve,ve0,vep,Set,I)
% Ec0   : Material contractility
% Ec    : contractility at previous time-step, or material contractility for non-regulated contractility
output=false; % print agreement of computed and expected nodal force
dim=size(ve,2);
vdim=(dim+1)*dim;
xidim=dim;
%xidim=0;
x =[ve(1,:) ve(2,:)];
x0=[ve0(1,:) ve0(2,:)];
xp=[vep(1,:) vep(2,:)];
l0=norm(ve0(1,:)-ve0(2,:));
if Maxwell
    if eta<0 %Dashpot branch on Voronoi
        [ener,ge,Ke,ln1_elas,~,G]=DashpotLineElem(dt,dim,-eta,x,xp,x0,Set.DispBased);
        ln1=ln1_elas;
    else %Maxwell branch on Voronoi
        [ener,ge,Ke,ln1_elas,~,ln1,G]=MaxwellLineElem(k,eta,dt,Ec,x0,x,xp,ln_elas,Set);
    end
    lrn1=l0;
    Ec1=Ec;
else %Active branch on Voronoi
    [ener,Ec1,err,ge,Ke,lrn1,ln1_elas,ln1,G]=ActiveLineElem(beta,Delay,dt,Ec0,Ec,err,Gamma,k,ld,lrn,tAb,theta,x,xp,x0,Set);
end
Eps=ln1/lrn1-1;
if output
    if abs(k*Eps-G)>100*eps &&  Set.enerM==0 && ~(Maxwell && eta>0)
        fprintf('Elastic error: |k*Eps-g|=%e\n',abs(k*Eps-G));
    elseif abs(k*(ln1_elas/l0-0.5)-G)>100*eps &&  Set.enerM==0  && Maxwell && eta>0% for Maxwell, elastic strain
        Eps=ln1_elas/l0-0.5;
        fprintf('Maxwell error: |k*Eps-g|=%e\n',abs(k*Eps-G));
    elseif abs(k*Eps*(1.5*Eps+1)-G)>100*eps &&  Set.enerM==2 && ~(Maxwell && eta>0)
        fprintf('|k*Eps*(1.5*Eps+1)-g|=%e\n',abs(k*Eps*(1.5*Eps+1)-G));
    end
end
dN=[-1 1 0
   -1 0 1]; %derivative of shape functions
dN1=dN;
dN2=dN;
if I(1) % Vertex 1 not relaxed: transport to nodes
    ee1=kron(N(n(1),:),eye(dim));
    eexi1=[(xe1(2,:)-xe1(1,:))' (xe1(3,:)-xe1(1,:))'];
    dim1=1:dim;
else
    ee1=[];
    eexi1=eye(dim);
    dim1=[];
end
if I(2)
    ee2=kron(N(n(2),:),eye(dim));
    eexi2=[(xe2(2,:)-xe2(1,:))' (xe2(3,:)-xe2(1,:))'];
    dim2=dim+1:2*dim;
else
    ee2=[];
    eexi2=eye(dim);
    dim2=[];
end
if I(1) && I(2)
    ee=[ee1 zeros(dim,vdim)
        zeros(dim,vdim) ee2];
    Mp=[kron(dN1',ge(1:dim)) zeros(vdim,dim)
        zeros(vdim,dim) kron(dN2',ge(dim+1:end))];
elseif I(1)
    ee=ee1;
    Mp=[kron(dN1',ge(1:dim)) zeros(vdim,dim)];
elseif I(2)
    ee=ee2;
    Mp=[zeros(vdim,dim) kron(dN2',ge(dim+1:end))];
else
    ee=[];
    Mp=[];
end
dim12=[dim1 dim2];
eexi=[eexi1 zeros(xidim,xidim)
    zeros(xidim,xidim) eexi2];
Kexx=ee'*Ke(dim12,dim12)*ee;
gex=ee'*ge(dim12);
if I(1) || I(2)
    Kexxi=ee'*Ke(dim12,:)*eexi+Mp;
    Kexix=eexi'*Ke(:,dim12)*ee+Mp';
else
    Kexxi=[];
    Kexix=[];
end
Kexixi=eexi'*Ke*eexi;
gexi=eexi'*ge;
ge=[gex;gexi];
Ke=[Kexx Kexxi;Kexix Kexixi];
end
%% Assign Material properties depending on Dead-Dead, Dead-Live and ablated area membership
function [eleGammaA,eleGammaB,eleetaA,eleetaB,elek,elekA,elekB,eleEc,eleEcA,eleEcB]=AssignMat(Ab,e,ln,Mat,t,Set)
    Timing=~isempty(Ab.eleVorDLt); %Ab.eleVorDLt = Voronoi connectivity between Dead-Live cells (on time t?)
    if Mat.beta<eps
        Ec=Mat.Ec; %Contractility in spring 
    else
        Ec=ln.S.c(e); %length of element in spring branch - contractility
    end
    if Mat.betaA<eps
        EcA=Mat.EcA; %Contractility in branch A 
    else
        EcA=ln.A.c(e); %length of element in branch A - contractility
    end
    if Mat.betaB<eps 
        EcB=Mat.EcB; %Contractility in branch B
    else
        EcB=ln.B.c(e); %length of element in branch B - contractility
    end
    if ismember(e,Ab.eleVorDD) && Ab.active && Ab.Eca %if element is part of Voronoi and active ablation and active first element of ablation
        elekA=Ab.CoK*Mat.kappaA; %element kappa A = ablation coefficient k (dead-dead and dead-alive) * kappa A
        elekB=Ab.CoK*Mat.kappaB; %element kappa B = ablation coefficient k * kappa B
        elek=Ab.CoK*Mat.kappa;   %element kappa = ablation coeffiecient k * kappa 
    elseif ismember(e,Ab.eleVorDD) && Ab.active %if element is part of Voronoi and active ablation
        elekA=Ab.CoVor*Mat.kappaA; %element kappa A = ablation coefficient on Voronoi elements (Dead-Dead) * kappa A
        elekB=Ab.CoVor*Mat.kappaB; %element kappa B = ablation coefficient on Voronoi elements (Dead-Dead) * kappa B
        elek=Ab.CoVor*Mat.kappa;   %element kappa = ablation coefficient on Voronoi elements (Dead-Dead) * kappa 
    else
        elekA=Mat.kappaA; %element kappa A = kappa A ---|
        elekB=Mat.kappaB; %element kappa B = kappa B    |- In my case since in the beginning we don't work with Ablated cells. 
        elek=Mat.kappa;   %element kappa = kappa     ---| 
    end
    if ismember(e,Ab.eleVorDD) && Ab.active %same as statements above only now for gammaA (in case of Active) and etaA (in case of Maxwell)
        eleGammaA=Ab.CoGamm*Mat.GammaA; 
        eleGammaB=Ab.CoGamm*Mat.GammaB;
        eleetaA=Ab.CoVor*Mat.etaA;
        eleetaB=Ab.CoVor*Mat.etaB;
    else
        eleGammaA=Mat.GammaA; %---|
        eleGammaB=Mat.GammaB; %   |_ In my case since in the beginning we don't work with Ablated cells. 
        eleetaA=Mat.etaA;     %   |
        eleetaB=Mat.etaB;     %---|       
    end
    if  ismember(e,Ab.eleVorDLc) && Ab.Eca %&& Ab.active
        if Timing
            tc=Ab.eleVorDLt(Ab.eleVorDLc==e); 
        else
            tc=0;
        end
        if ~Timing || t>tc
            if Set.DispBased
                elekA=Ab.Ec*Mat.kappaA;
                elekB=Ab.Ec*Mat.kappaB;
                elek =Ab.Ec*Mat.kappa;
            end
            if abs(Mat.beta)>eps
                eleEc=ln.S.c(e);
            else
                eleEc=Ab.Ec*Mat.Ec;
            end
            if abs(Mat.betaA)>eps
                eleEcA=ln.A.c(e);
            else
                eleEcA=Ab.Ec*Mat.EcA;
            end
            if abs(Mat.betaB)>eps
                eleEcB=ln.B.c(e);
            else
                eleEcB=Ab.Ec*Mat.EcB;
            end
        else
            eleEc =Ec;
            eleEcA=EcA;
            eleEcB=EcB;
        end
    elseif ismember(e,Ab.eleVorDD) && Ab.active && Ab.Eca % During active closure
        if ln.S.e(e)<Ab.LFilo
            eleEc =Ab.CoEc*Ec;
            eleEcA=Ab.CoEc*EcA;
            eleEcB=Ab.CoEc*EcB;
        else
            eleEc =0;
            eleEcA=0;
            eleEcB=0;
        end
    elseif ismember(e,Ab.eleVorDD) && Ab.active % after wounding before closure
        eleEc =0;
        eleEcA=0;
        eleEcB=0; 
    else
        eleEc =Ec;
        eleEcA=EcA;
        eleEcB=EcB;
    end
    if ismember(e,Ab.eleVorDLc) && Ab.active
        elekA=2;  %% apply constant stiffness at the wound edge
        elekB=0;
        elek=0;
    end
end
