function [dx]=Modifydx(x,xi,dx,ln,dofx,dofxi)
meanl=mean(ln.D.n1.A.r);
ndx=length(dofx);
ndxi=length(dofxi);
nx=length(x);
for i=1:0.5*ndx
    dxmax=norm([dx(2*i-1) dx(2*i)]);
    if dxmax>meanl
        dx(2*i-1)=dx(2*i-1)*meanl/(10*dxmax);
        dx(2*i)=dx(2*i)*meanl/(10*dxmax);
    end
end
for i=1:0.5*ndxi
    xi1=xi(dofxi(2*i-1)-nx);
    dxi1=dx(ndx+2*i-1);
    dxi2=dx(ndx+2*i);
    xi2=xi(dofxi(2*i)-nx);
    if xi1+dxi1<0
        dxi1=0;
    end
    if xi2+dxi2<0
        dxi2=0;
    end
    if xi1+dxi1+xi2+dxi2>1
        l=(dxi1+dxi2)/(1-xi1-xi2);
        dxi1=dxi1/(1.01*l);
        dxi2=dxi2/(1.01*l);
    end
   dx(ndx+2*i-1)=dxi1;
   dx(ndx+2*i)=dxi2;
end
end