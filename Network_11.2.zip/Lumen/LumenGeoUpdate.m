function [lnod, lnodFE,ln,lnod_vor,Lumen,N,nodesV,stress,Vor,Vor0,Vorp,vor_cell,xi,xip]=LumenGeoUpdate(i,ln,lnod,lnodFE,lnodExternal,lnod_vor,Lumen,N,nodesV,num_sh,stress,Vor,Vor0,Vorp,vor_cell,xi,xip)
% Applies splittting of vertices if necessary due to creation of Lumen.
% Updates mesh information due to new vertices created.
% INPUT:
% i  : current increment
% ln : lengths of each vertex and nodal element for current and previous
%       time, and for each branch S (spring),A,B.
% lnodFE : triangular connectivity of nodal network.
%           lnodFE(i,:) nodes forming traingle i, that surround vertex i.
% lnod_vor : vertex network connectivity. 
%           lnod_vor(i,:): vertices connecting bar element i.
% lnod : nodal network connectivity. 
%           lnod(i,:): nodes connecting bar element i.
% Lumen: data structure about lumen geometry and pressure
%      Lumen{w}.P0 = nominal internal pressure at Lumen w
%      Lumen{w}.lnod0 = set of nodes at InputNetwork forming boundary of lumen w.
%      Lumen{w}.V  = vertex that will be divided and form Lumen.
%      Lumen{w}.lnod  = set of nodes forming boundary of lumen w, taken from lnod0 or vertex V.
% num_sh  : number of Step halvings
% ln : rest and apparent lengths for current and previous time-steps, for Vertx and Delaunay neteros. 
% OUTPUT:
% New mesh information
% COMMENTS:
% Transforms connectivity of Vertex network due to triplication of vertex,
% from
%             v2
%             |
%             |
%             V
%            / \
%           /   \
%          v1    v2
% into (V1, V2, V3 same coordinates)
%              v2
%              ||
%              ||
%            V1  V2
%            //V3\\
%           //    \\
%          v1      v2
%--------------------------------------------------------------------------
% Vertex number to be split. Criteria should be included here.
if i>1 || num_sh>0 || length(Lumen)==0
    return; % Only in first time-step
end
Lumen{1}.V=FindSeedLumen(lnod, lnodExternal, lnod_vor,  Vor);
%--------------------------------------------------------------------------
% UPdate connectivity database
[nodesV,ln,lnod,lnodFE,lnod_vor,Lumen,N,stress,Vor,Vor0,Vorp,vor_cell,xi,xip]=SplitVertex(ln,lnod,lnodFE,lnod_vor,Lumen,N,stress,Vor,Vor0,Vorp,vor_cell,xi,xip);
end