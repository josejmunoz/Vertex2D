function [V]=Volume(nodV,Vor,vor_cell)
V=zeros(length(nodV),1);
for k=1:size(nodV)
for j=1:size(vor_cell{k},1)-1
    V(k)=V(k)+0.5*det([Vor(vor_cell{k}(j),:);Vor(vor_cell{k}(j+1),:)]);  %%calculating volume of cell i
end
end
end