function PlotAreaEvolution

load('Sfix');
%cd results
load('Srem');
exp=[100
135.15663
150.269687
158.844681
163.64194
170.330182
173.746219
172.55748
170.782833
169.061066
140.383273
106.389999
92.706813
86.3929606
77.38224
47.29361
28.39013
28.03266
27.08505
11.39666
6.189056
5.560844
2.950695
1.351609
0];
Sfix(1:10)=[];
Srem(1:10)=[];
a=exp(1)/Sfix(1);
Sfix=Sfix*a;
Srem=Srem*a;
b=length(Sfix)/length(exp);
texp=1+b*(0:length(exp)-1);
figure
plot(texp,exp,'k-x',1:length(Sfix),Sfix,'b-o',1:length(Srem),Srem,'r-^','LineWidth',2,'MarkerSize',4)
xlabel('\bf{time-step}','FontSize',12);
ylabel('\bf{Wound Area}','FontSize',12);
h=legend('experimental(141216)','fixed tissue','remodelled tissue','Location','Northeast');
set(h,'FontSize',10);
set(gcf,'units','inches');
set(gcf,'Position',[0 0 6 4.5]);
set(gcf, 'PaperPosition', [0 0 6 4.5]);
set(gcf,'PaperSize',[6 4.5]);
set(gca,'box','off');
title('Wound Area Evolution');
print('WoundArea','-dpdf');
cd ..
end