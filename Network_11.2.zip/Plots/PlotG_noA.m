function PlotG_noA
load('gnomap');
load('gfull_noA');
load('gsplit_noA');
load('nremfull_noA');
load('nremsplit_noA');
load('maperrfull_noA');
load('maperrsplit_noA');
nremsplit=nremsplit_noA;
nremfull=nremfull_noA;
maperrfull=maperrfull_noA;
maperrsplit=maperrsplit_noA;
l=length(gnomap);
s=3;
t=1:s:l;
figure
plot(t,gnomap(t),'k-o',t,gfull_noA(t),'r-^',t,gsplit_noA(t),'b-s','LineWidth',2,'MarkerSize',6);
xlabel('\bf{time-step}','FontSize',12);
ylabel('\bf{reaction}','FontSize',12);
h=legend('nomap','fullmap','splitmap','Location','northwest');
%title('Tissue extension with high K_V, no-remodelling','FontSize',14);
set(h,'FontSize',15);
set(gcf,'units','inches');
set(gcf,'Position',[0 0 6 4.5]);
set(gcf, 'PaperPosition', [0 0 6 4.5]);
set(gcf,'PaperSize',[6 4.5]);
set(gca,'box','off');
print('rem_noA','-dpdf');
figure
t=1:l;
tf=t(nremfull>eps);
ts=t(nremsplit>eps);
plot(tf,nremfull(tf),'ko',ts,nremsplit(ts),'r^','LineWidth',2,'MarkerSize',6);
xlabel('\bf{time-step}','FontSize',12);
ylabel('\bf{# of remodel}','FontSize',12);
h=legend('fullmap','splitmap','Location','northwest');
set(h,'FontSize',15);
set(gca,'Ylim',[0 max([nremfull;nremsplit])]);
set(gcf,'units','inches');
set(gcf,'Position',[0 0 6 4.5]);
set(gcf, 'PaperPosition', [0 0 6 4.5]);
set(gcf,'PaperSize',[6 4.5]);
set(gca,'box','off');
print('nrem_noA','-dpdf');
figure
plot(tf,maperrfull(tf),'ko',ts,maperrsplit(ts),'r^','LineWidth',2,'MarkerSize',6);
xlabel('\bf{time-step}','FontSize',12);
ylabel('\bf{map error}','FontSize',12);
h=legend('fullmap','splitmap','Location','northwest');
set(h,'FontSize',15);
set(gca,'Ylim',[0 max([maperrfull;maperrsplit])]);
set(gcf,'units','inches');
set(gcf,'Position',[0 0 6 4.5]);
set(gcf, 'PaperPosition', [0 0 6 4.5]);
set(gcf,'PaperSize',[6 4.5]);
set(gca,'box','off');
print('maperr_noA','-dpdf');
end